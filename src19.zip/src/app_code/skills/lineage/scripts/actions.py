from __future__ import annotations

import hashlib
import csv
import json
import os
import platform
import sqlite3
import subprocess
from pathlib import Path
from typing import Annotated

from langchain_core.tools import InjectedToolArg, tool

from app_code.runtime_paths import draft_root, repo_root, work_root
from app_code.skills_runtime.structs import NodeNames, WorkflowState
from app_code.skills_runtime.runtime_services import call_skill_llm, emit_skill_status


SQL_EXTENSIONS = {".sql", ".txt"}
_RUNTIME_STATE: WorkflowState | None = None
LINEAGE_ANALYSIS_VERSION = "lineage-v2"
LINEAGE_SYSTEM_PROMPT = """You are a SQL data lineage analyst.

Analyze only the SQL files provided in the prompt. Do not invent scripts, tables, columns, or
business rules that are not supported by the SQL context. Build a complete column-level lineage
tree from deepest available source to final target. If a target column is calculated from multiple
columns, trace each source column as a child branch. If a source is ambiguous because aliases are
missing or joins make ownership unclear, state the ambiguity and list candidate source tables.

Return JSON only:
{
  "target": {"table": "...", "column": "..."},
  "summary": "...",
  "lineage_tree": {
    "nodes": [
      {
        "step": 1,
        "source_table": "...",
        "source_column": "...",
        "target_table": "...",
        "target_column": "...",
        "sql_rule": "exact SQL expression from the script",
        "script": "relative/path.sql",
        "filters": "WHERE/HAVING/JOIN filters or null",
        "confidence": "high|medium|low",
        "explanation": "...",
        "children": []
      }
    ]
  },
  "ambiguities": [],
  "scripts_used": []
}
"""
LINEAGE_STEP_PROMPT = """You are planning a SQL lineage trace one step at a time.

Given the current target table/column and only the SQL files shown, identify:
1. lineage nodes proved by the SQL shown now
2. the next upstream table/column pairs that must be inspected to continue tracing
3. ambiguities that require inspecting parent SQL files

For each SQL file in this step, return only lineage nodes whose target is the current step
target table/column. Do not emit separate top-level nodes for intermediate CTEs, nested
subqueries, temporary aliases, or helper expressions inside the same SQL. Use next_targets to
request deeper upstream inspection instead.

Return JSON only:
{
  "nodes": [
    {
      "source_table": "...",
      "source_column": "...",
      "target_table": "...",
      "target_column": "...",
      "sql_rule": "...",
      "script": "...",
      "filters": null,
      "confidence": "high|medium|low",
      "explanation": "..."
    }
  ],
  "next_targets": [
    {"table": "...", "column": "...", "reason": "..."}
  ],
  "ambiguities": []
}
"""
LINEAGE_FILE_SELECTION_PROMPT = """You select local SQL files for one step of a lineage trace.

You receive only filenames, not file contents. Choose the smallest set of files that are likely to
define or load the current target table/column. Prefer filenames that contain the table name or a
clear short table name. Prefer load/build scripts such as alim_*.sql over output/table definition
files when both exist. Include a paired init/refresh script only when both are likely variants of
the same target.

Return JSON only:
{
  "selected_files": ["relative/path.sql"],
  "reason": "short reason"
}
"""
DEFAULT_FOLLOWUP_DELIVERABLE_TERMS = (
    "ppt",
    "pptx",
    "powerpoint",
    "presentation",
    "slides",
    "slide deck",
    "deck",
    "pdf",
    "docx",
    "document",
    "report",
    "email",
    "mail",
    "jira",
    "ticket",
    "commit",
    "merge request",
    "mr",
)


def _repo_root() -> Path:
    return repo_root()


def _sql_root() -> Path:
    configured = os.getenv("LINEAGE_SQL_ROOT")
    if configured:
        return Path(configured).expanduser().resolve()
    return work_root() / "sql-lineage" / "SQL"


def _cache_path() -> Path:
    configured = os.getenv("LINEAGE_CACHE_PATH")
    if configured:
        path = Path(configured).expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        return path
    base = work_root() / "sql-lineage" / "Cash"
    base.mkdir(parents=True, exist_ok=True)
    return base / "lineage_cache.sqlite3"


def _message_content(message) -> str:
    content = getattr(message, "content", None)
    if content is None and isinstance(message, dict):
        content = message.get("content")
    if isinstance(content, list):
        return "\n".join(str(item.get("text", item)) if isinstance(item, dict) else str(item) for item in content)
    return str(content or "")


def _message_role(message) -> str:
    role = getattr(message, "type", None) or getattr(message, "role", None)
    if role is None and isinstance(message, dict):
        role = message.get("type") or message.get("role")
    return str(role or "").lower()


def _latest_user_request(state: WorkflowState | None) -> str:
    if not state:
        return ""
    preferred_nodes = ("code_agent", "user_input", "bdd_agent", "env_agent", "jira_agent", "email_agent")
    for node_name in preferred_nodes:
        node_state = state.get(node_name) if isinstance(state, dict) else None
        messages = node_state.get("messages", []) if isinstance(node_state, dict) else []
        for message in reversed(messages):
            role = _message_role(message)
            text = _message_content(message).strip()
            if text and (role in {"human", "user"} or message.__class__.__name__ == "HumanMessage"):
                return text
    return ""


def _configured_followup_terms() -> tuple[str, ...]:
    configured = os.getenv("LINEAGE_FOLLOWUP_DELIVERABLE_TERMS", "").strip()
    if not configured:
        return DEFAULT_FOLLOWUP_DELIVERABLE_TERMS
    return tuple(term.strip().lower() for term in configured.split(",") if term.strip())


def _lineage_success_artifact(
    *,
    state: WorkflowState | None,
    table_name: str,
    column_name: str,
    formatted: str,
    cache_status: str,
    lineage_result: str,
    script_paths: list[str],
    context_hash: str | None,
    extra: dict | None = None,
) -> dict:
    context = (
        f"Lineage analysis result for {table_name}.{column_name}.\n"
        f"Use this as verified context for any follow-up deliverable requested by the user.\n\n"
        f"{formatted}"
    )
    artifact = {
        "status": "success",
        "cache_status": cache_status,
        "lineage_result": lineage_result,
        "llm_status_content": formatted,
        "context": context,
        "script_paths": script_paths,
        "context_hash": context_hash,
    }
    if extra:
        artifact.update(extra)
    return _next_artifact(artifact)


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(_cache_path())
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS lineage_cache (
            cache_key TEXT PRIMARY KEY,
            table_name TEXT NOT NULL,
            column_name TEXT NOT NULL,
            context_hash TEXT NOT NULL,
            lineage_result TEXT NOT NULL,
            scripts_used TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS lineage_step_cache (
            cache_key TEXT PRIMARY KEY,
            table_name TEXT NOT NULL,
            column_name TEXT NOT NULL,
            context_hash TEXT NOT NULL,
            step_result TEXT NOT NULL,
            scripts_used TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS lineage_file_index (
            file_path TEXT PRIMARY KEY,
            file_hash TEXT NOT NULL,
            size_bytes INTEGER NOT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    return conn


def _normalize_rel_path(file_path: str) -> str:
    clean = file_path.strip().replace("\\", "/").lstrip("/")
    candidate = (_sql_root() / clean).resolve()
    root = _sql_root().resolve()
    if root not in candidate.parents and candidate != root:
        raise ValueError(f"Path is outside SQL root: {file_path}")
    if not candidate.is_file():
        raise FileNotFoundError(f"SQL file not found: {file_path}")
    return candidate.relative_to(root).as_posix()


def _iter_sql_files() -> list[Path]:
    root = _sql_root()
    if not root.exists():
        return []
    files = _iter_sql_files_with_native_search(root)
    if not files:
        files = _iter_sql_files_native(root)
    return sorted(files, key=lambda path: path.relative_to(root).as_posix().lower())


def _iter_sql_files_with_native_search(root: Path) -> list[Path]:
    """Use OS-native file search commands, similar to fd/rg --files, without extra installs."""

    system = platform.system().lower()
    commands: list[list[str]] = []
    if system == "windows":
        commands.append(
            [
                "powershell",
                "-NoProfile",
                "-Command",
                (
                    "Get-ChildItem -LiteralPath $args[0] -Recurse -File "
                    "| Where-Object { $_.Extension -in '.sql','.txt' -and $_.Name -ne 'readme.txt' } "
                    "| ForEach-Object { $_.FullName }"
                ),
                str(root),
            ]
        )
        commands.append(
            [
                "cmd",
                "/c",
                f'dir /s /b "{root}\\*.sql" "{root}\\*.txt" 2>nul',
            ]
        )
    else:
        commands.append(
            [
                "find",
                str(root),
                "-type",
                "f",
                "(",
                "-name",
                "*.sql",
                "-o",
                "-name",
                "*.txt",
                ")",
                "!",
                "-iname",
                "readme.txt",
            ]
        )

    for command in commands:
        try:
            completed = subprocess.run(
                command,
                check=False,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=15,
            )
        except Exception:
            continue
        if completed.returncode not in (0, 1):
            continue
        paths = _normalize_native_search_output(root, completed.stdout.splitlines())
        if paths:
            return paths
    return []


def _normalize_native_search_output(root: Path, lines: list[str]) -> list[Path]:
    root_resolved = root.resolve()
    paths: list[Path] = []
    for line in lines:
        item = line.strip().strip('"')
        if not item:
            continue
        path = Path(item)
        if not path.is_absolute():
            path = root / path
        try:
            resolved = path.resolve()
        except Exception:
            continue
        if root_resolved not in resolved.parents and resolved != root_resolved:
            continue
        if (
            resolved.is_file()
            and resolved.suffix.lower() in SQL_EXTENSIONS
            and resolved.name.lower() != "readme.txt"
        ):
            paths.append(resolved)
    return list(dict.fromkeys(paths))


def _iter_sql_files_native(root: Path) -> list[Path]:
    """Discover SQL files with Python's native filesystem APIs on macOS and Windows."""

    files: list[Path] = []
    stack = [root]
    while stack:
        current = stack.pop()
        try:
            with os.scandir(current) as entries:
                for entry in entries:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            stack.append(Path(entry.path))
                        elif (
                            entry.is_file(follow_symlinks=False)
                            and Path(entry.name).suffix.lower() in SQL_EXTENSIONS
                            and entry.name.lower() != "readme.txt"
                        ):
                            files.append(Path(entry.path))
                    except OSError:
                        continue
        except OSError:
            continue
    return files


def _read_rel(file_path: str) -> tuple[str, str]:
    rel = _normalize_rel_path(file_path)
    full = _sql_root() / rel
    return rel, full.read_text(encoding="utf-8", errors="replace")


def _hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()


def _context_hash(script_paths: list[str]) -> tuple[str, list[str]]:
    normalized = sorted({_normalize_rel_path(path) for path in script_paths})
    chunks = [LINEAGE_ANALYSIS_VERSION]
    for rel in normalized:
        content = (_sql_root() / rel).read_text(encoding="utf-8", errors="replace")
        chunks.append(f"--- {rel} ---\n{content}")
    return hashlib.sha256("\n".join(chunks).encode("utf-8", errors="replace")).hexdigest()[:16], normalized


def _search_matches(query_terms: list[str], limit: int) -> list[dict]:
    terms = [term.strip().lower() for term in query_terms if str(term).strip()]
    if not terms:
        return []

    root = _sql_root()
    matches = []
    for path in _iter_sql_files():
        rel = path.relative_to(root).as_posix()
        text = path.read_text(encoding="utf-8", errors="replace")
        lower_rel = rel.lower()
        lower_text = text.lower()
        matched_terms = [term for term in terms if term in lower_rel or term in lower_text]
        if not matched_terms:
            continue
        path_hits = sum(1 for term in matched_terms if term in lower_rel)
        content_hits = sum(lower_text.count(term) for term in matched_terms)
        score = path_hits * 10 + content_hits
        first_pos = min(
            [lower_text.find(term) for term in matched_terms if lower_text.find(term) >= 0] or [0]
        )
        matches.append(
            {
                "file_path": rel,
                "score": score,
                "matched_terms": matched_terms,
                "first_pos": first_pos,
            }
        )
    matches.sort(key=lambda item: (-item["score"], item["file_path"]))
    return matches[: max(limit, 0)]


def _table_like_terms(sql_text: str) -> list[str]:
    terms: list[str] = []

    # Backtick-quoted identifiers are common in BigQuery project SQL and are useful candidates.
    parts = sql_text.split("`")
    for idx in range(1, len(parts), 2):
        item = parts[idx].strip()
        if "." in item and len(item) <= 160:
            terms.append(item)
            terms.append(item.split(".")[-1])

    # Also look at tokens following FROM/JOIN without using a SQL parser.
    separators = "\n\r\t(),;"
    normalized = sql_text
    for char in separators:
        normalized = normalized.replace(char, " ")
    tokens = normalized.split()
    for idx, token in enumerate(tokens[:-1]):
        upper = token.upper()
        if upper in {"FROM", "JOIN", "INTO", "UPDATE", "MERGE"}:
            candidate = tokens[idx + 1].strip("`\"'")
            if candidate and not candidate.startswith("(") and len(candidate) <= 160:
                terms.append(candidate)
                if "." in candidate:
                    terms.append(candidate.split(".")[-1])

    seen = set()
    result = []
    for term in terms:
        lower = term.lower()
        if lower in seen:
            continue
        seen.add(lower)
        result.append(term)
    return result


def _next_artifact(extra: dict | None = None) -> dict:
    artifact = {"next_agent": NodeNames.CODE_AGENT}
    if extra:
        artifact.update(extra)
    return artifact


def _call_openai_lineage(user_prompt: str, state: WorkflowState | None = None) -> str:
    return _call_runtime_llm(LINEAGE_SYSTEM_PROMPT, user_prompt, state, "lineage_finalize")


def _call_openai_step(user_prompt: str, state: WorkflowState | None = None) -> str:
    return _call_runtime_llm(LINEAGE_STEP_PROMPT, user_prompt, state, "lineage_step")


def _call_openai_file_selection(user_prompt: str, state: WorkflowState | None = None) -> str:
    return _call_runtime_llm(LINEAGE_FILE_SELECTION_PROMPT, user_prompt, state, "lineage_file_selection")


def _call_runtime_llm(
    system_prompt: str,
    user_prompt: str,
    state: WorkflowState | None,
    purpose: str,
) -> str:
    return call_skill_llm(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        session_id=str(state.get("session_id")) if state else None,
        skill_name="lineage",
        purpose=purpose,
    )


def _extract_json_text(text: str) -> str:
    stripped = text.strip()
    if stripped.startswith("```"):
        parts = stripped.split("```")
        for idx in range(1, len(parts), 2):
            block = parts[idx].strip()
            if block.lower().startswith("json"):
                block = block[4:].strip()
            if block.startswith("{") and block.endswith("}"):
                return json.dumps(json.loads(block), ensure_ascii=False)
    if stripped.startswith("{") and stripped.endswith("}"):
        return json.dumps(json.loads(stripped), ensure_ascii=False)
    return json.dumps({"summary": stripped, "lineage_tree": {"nodes": []}}, ensure_ascii=False)


def _format_lineage_result(table_name: str, column_name: str, result_text: str, cache_status: str) -> str:
    try:
        result = json.loads(result_text)
    except Exception:
        return result_text

    lines = [f"## Lineage: `{table_name}.{column_name}`", "", f"Cache: {cache_status}", ""]
    summary = result.get("summary")
    if summary:
        lines.extend(["### Summary", str(summary), ""])
    nodes = ((result.get("lineage_tree") or {}).get("nodes") or [])
    if nodes:
        lines.append("### Lineage Tree")
        for idx, node in enumerate(nodes, 1):
            source = f"{node.get('source_table')}.{node.get('source_column')}"
            target = f"{node.get('target_table')}.{node.get('target_column')}"
            lines.append(f"{idx}. `{source}` -> `{target}`")
            if node.get("script"):
                lines.append(f"   - Script: `{node['script']}`")
            if node.get("sql_rule"):
                lines.append(f"   - SQL rule: `{node['sql_rule']}`")
            if node.get("filters"):
                lines.append(f"   - Filters: `{node['filters']}`")
            if node.get("explanation"):
                lines.append(f"   - Notes: {node['explanation']}")
        lines.append("")
    ambiguities = result.get("ambiguities") or []
    if ambiguities:
        lines.append("### Ambiguities")
        for item in ambiguities:
            lines.append(f"- {item}")
        lines.append("")
    scripts = result.get("scripts_used") or []
    if scripts:
        lines.append("### Scripts Used")
        for script in scripts:
            lines.append(f"- `{script}`")
    return "\n".join(lines).strip()


def _lineage_nodes_from_text(lineage_result: str) -> list[dict]:
    try:
        result = json.loads(_extract_json_text(lineage_result))
    except Exception:
        return []
    return ((result.get("lineage_tree") or {}).get("nodes") or [])


def _lineage_node_count(lineage_result: str) -> int:
    return len(_lineage_nodes_from_text(lineage_result))


def _flatten_text(value) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return "; ".join(_flatten_text(item) for item in value if _flatten_text(item))
    if isinstance(value, dict):
        return "; ".join(f"{key}: {_flatten_text(val)}" for key, val in value.items())
    return str(value).replace("\r", " ").replace("\n", " ").strip()


def _lineage_export_rows(nodes: list[dict]) -> list[list[str]]:
    rows: list[list[str]] = []
    for node in nodes:
        source = f"{node.get('source_table') or ''}.{node.get('source_column') or ''}".strip(".")
        target = f"{node.get('target_table') or ''}.{node.get('target_column') or ''}".strip(".")
        rows.append(
            [
                source,
                target,
                _flatten_text(node.get("sql_rule")),
                _flatten_text(node.get("script")),
                _flatten_text(node.get("filters")),
                _flatten_text(node.get("explanation") or node.get("notes")),
            ]
        )
    return rows


def _safe_export_name(table_name: str, column_name: str) -> str:
    raw = f"lineage_{table_name}_{column_name}".lower()
    safe = "".join(char if char.isalnum() or char in {"-", "_"} else "_" for char in raw)
    while "__" in safe:
        safe = safe.replace("__", "_")
    return safe.strip("_") or "lineage_export"


def _session_draft_dir(state: WorkflowState | None) -> Path:
    session_id = str(state.get("session_id")) if state else "unknown"
    path = draft_root() / session_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def _parse_json_object(text: str) -> dict:
    try:
        return json.loads(_extract_json_text(text))
    except Exception:
        return {"summary": text.strip(), "lineage_tree": {"nodes": []}, "ambiguities": []}


def _target_terms(table_name: str, column_name: str) -> list[str]:
    terms = [table_name, table_name.split(".")[-1]]
    if column_name and column_name != "*":
        terms.append(column_name)
    return terms


def _all_relative_sql_files() -> list[str]:
    root = _sql_root()
    return [path.relative_to(root).as_posix() for path in _iter_sql_files()]


def _compact_identifier(value: str) -> str:
    return "".join(char for char in value.lower() if char.isalnum())


def _table_variants(table_name: str) -> dict[str, str]:
    clean = table_name.strip().strip("`\"'").lower()
    short = clean.split(".")[-1]
    return {
        "full": clean,
        "short": short,
        "full_underscore": clean.replace(".", "_"),
        "full_slash": clean.replace(".", "/"),
        "compact_short": _compact_identifier(short),
    }


def _score_candidate_file(
    rel: str,
    table_name: str,
    column_name: str,
    *,
    read_content: bool,
) -> tuple[int, list[str]]:
    variants = _table_variants(table_name)
    lower = rel.lower()
    basename = Path(rel).name.lower()
    stem = Path(rel).stem.lower()
    compact_name = _compact_identifier(basename)
    score = 0
    reasons: list[str] = []

    if variants["full"] and variants["full"] in lower:
        score += 90
        reasons.append("path contains full table name")
    if variants["full_underscore"] and variants["full_underscore"] in lower:
        score += 80
        reasons.append("path contains dotted table as underscores")
    if variants["full_slash"] and variants["full_slash"] in lower:
        score += 80
        reasons.append("path contains schema/table path")
    if variants["short"] and variants["short"] in lower:
        score += 55
        reasons.append("path contains short table name")
    if variants["compact_short"] and variants["compact_short"] in compact_name:
        score += 35
        reasons.append("path contains compact short table name")
    if stem == variants["short"]:
        score += 30
        reasons.append("file stem equals short table name")

    column = column_name.strip().lower()
    if score and column and column != "*" and column in lower:
        score += 8
        reasons.append("path contains target column")
    if score and basename.startswith("alim_"):
        score += 12
        reasons.append("producer-style alim_ file")
    if score and "init" in basename:
        score += 4
        reasons.append("init variant")

    if read_content:
        try:
            text = (_sql_root() / rel).read_text(encoding="utf-8", errors="replace").lower()
        except Exception:
            text = ""
        if text:
            table_hits = 0
            for value, weight, label in (
                (variants["full"], 60, "content contains full table name"),
                (variants["full_underscore"], 45, "content contains dotted table as underscores"),
                (variants["short"], 25, "content contains short table name"),
            ):
                if value and value in text:
                    table_hits += 1
                    score += weight
                    reasons.append(label)
            if column and column != "*" and column in text:
                # Column is an assistive signal only. It boosts table candidates, but does not
                # replace table evidence because SELECT * can hide target columns.
                if table_hits or score:
                    score += 18 if table_hits else 5
                    reasons.append("content contains target column")
            if score and any(keyword in text for keyword in ("insert into", "create table", "create or replace", "merge into")):
                score += 10
                reasons.append("content looks like producer SQL")
    return score, reasons


def _shortlist_step_files(table_name: str, column_name: str, max_files: int) -> list[dict]:
    files = _all_relative_sql_files()
    if not files:
        return []

    scored: list[dict] = []
    for rel in _all_relative_sql_files():
        score, reasons = _score_candidate_file(rel, table_name, column_name, read_content=False)
        if score:
            scored.append({"file_path": rel, "score": score, "reasons": reasons})

    # If filename matching is weak or absent, inspect content deterministically before involving the LLM.
    # This is still a code-side search pass, not a full SQL-content prompt.
    if len(scored) < max(max_files, 4):
        seen = {item["file_path"] for item in scored}
        for rel in files:
            score, reasons = _score_candidate_file(rel, table_name, column_name, read_content=True)
            if score and rel not in seen:
                scored.append({"file_path": rel, "score": score, "reasons": reasons})
                seen.add(rel)
            elif score:
                for item in scored:
                    if item["file_path"] == rel and score > item["score"]:
                        item["score"] = score
                        item["reasons"] = reasons
                        break

    scored.sort(key=lambda item: (-int(item["score"]), item["file_path"]))
    shortlist_limit = max(max_files * 4, max_files, 12)
    return scored[:shortlist_limit]


def _select_step_files_with_llm(
    table_name: str,
    column_name: str,
    max_files: int,
    state: WorkflowState | None = None,
) -> list[str]:
    candidates = _shortlist_step_files(table_name, column_name, max_files)
    if not candidates:
        return []
    files = [item["file_path"] for item in candidates]
    prompt = (
        f"Current lineage step target table: `{table_name}`\n"
        f"Current lineage step target column: `{column_name}`\n"
        f"Select at most {max_files} files to read for this step.\n"
        "The list below is a deterministic shortlist produced by searching table names first and "
        "using column names only as an assistive ranking signal. Do not assume a missing column "
        "name rules out a file because SELECT * or positional INSERTs can hide target columns.\n\n"
        "Candidate SQL files:\n"
        + "\n".join(
            f"- {item['file_path']} | score={item['score']} | reasons={'; '.join(item['reasons'])}"
            for item in candidates
        )
    )
    try:
        result = _parse_json_object(_call_openai_file_selection(prompt, state))
        selected = result.get("selected_files") or []
    except Exception:
        selected = []
    valid = []
    available = set(files)
    for item in selected:
        rel = str(item).strip().replace("\\", "/")
        if rel in available and rel not in valid:
            valid.append(rel)
        if len(valid) >= max_files:
            break
    if valid:
        return valid
    return files[:max_files]


def _find_step_files(table_name: str, column_name: str, max_files: int) -> list[str]:
    matches = _search_matches(_target_terms(table_name, column_name), limit=max_files * 4)
    chosen = []
    for item in matches:
        rel = item["file_path"]
        # Prefer producer/load scripts first. Table definition files can help later but usually do
        # not contain the transformation rule.
        basename = Path(rel).name.lower()
        if basename.startswith("alim_") or "insert" in item.get("preview", "").lower():
            chosen.append(rel)
        elif len(chosen) < max_files // 2:
            chosen.append(rel)
        if len(chosen) >= max_files:
            break
    if not chosen:
        chosen = [item["file_path"] for item in matches[:max_files]]
    return list(dict.fromkeys(chosen))


def _build_step_prompt(
    root_table: str,
    root_column: str,
    current_table: str,
    current_column: str,
    file_paths: list[str],
    max_chars_per_file: int,
) -> str:
    blocks = []
    for rel in file_paths:
        content = (_sql_root() / rel).read_text(encoding="utf-8", errors="replace")
        blocks.append(
            f"--- SQL File: {rel} ---\n{content[:max_chars_per_file]}"
            + ("\n...[truncated]..." if len(content) > max_chars_per_file else "")
        )
    return (
        f"Root lineage target: `{root_table}.{root_column}`\n"
        f"Current step target to inspect: `{current_table}.{current_column}`\n"
        "Use only these files for this step. Identify proven nodes and next upstream targets.\n\n"
        + "\n\n".join(blocks)
    )


def _find_target_expression_line(current_column: str, file_paths: list[str]) -> tuple[str, str] | None:
    column = current_column.strip().lower()
    if not column or column == "*":
        return None
    best: tuple[int, str, str] | None = None
    for rel in file_paths:
        try:
            lines = (_sql_root() / rel).read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception:
            continue
        for line in lines:
            clean = line.strip()
            lower = clean.lower()
            if column not in lower:
                continue
            score = 1
            if f" as {column}" in lower or lower.endswith(f" {column}") or lower.endswith(f" {column},"):
                score += 20
            if any(keyword in lower for keyword in ("case ", "count(", "coalesce(", "safe_cast(", "min(", "max(", "sum(")):
                score += 8
            if best is None or score > best[0]:
                best = (score, rel, clean.rstrip(","))
    if best is None:
        return None
    return best[1], best[2]


def _node_key(node: dict) -> tuple[str, str, str, str]:
    return (
        str(node.get("source_table") or "").lower(),
        str(node.get("source_column") or "").lower(),
        str(node.get("target_table") or "").lower(),
        str(node.get("target_column") or "").lower(),
    )


def _augment_direct_dependency_nodes(
    step_result: dict,
    current_table: str,
    current_column: str,
    file_paths: list[str],
) -> dict:
    """Fill obvious direct edges when the LLM listed them only as next_targets."""

    nodes = list(step_result.get("nodes") or [])
    next_targets = list(step_result.get("next_targets") or [])
    expression = _find_target_expression_line(current_column, file_paths)
    if not expression or not next_targets:
        step_result["nodes"] = nodes
        return step_result

    script, sql_rule = expression
    lower_rule = sql_rule.lower()
    existing = {_node_key(node) for node in nodes}
    added = []
    for nxt in next_targets:
        source_table = str(nxt.get("table") or "").strip()
        source_column = str(nxt.get("column") or "").strip()
        if not source_table or not source_column or source_column == "*":
            continue
        if source_column.lower() not in lower_rule:
            continue
        candidate = {
            "source_table": source_table,
            "source_column": source_column,
            "target_table": current_table,
            "target_column": current_column,
            "sql_rule": sql_rule,
            "script": script,
            "filters": None,
            "confidence": "medium",
            "explanation": (
                "Added by lineage runtime because this upstream target appears directly in the "
                "SQL expression for the current target but was omitted from the LLM node list."
            ),
        }
        key = _node_key(candidate)
        if key not in existing:
            nodes.append(candidate)
            added.append(candidate)
            existing.add(key)

    if added:
        step_result.setdefault("runtime_augmented_nodes", []).extend(added)
    step_result["nodes"] = nodes
    return step_result


def _node_matches_target(node: dict, table_name: str, column_name: str) -> bool:
    return (
        str(node.get("target_table") or "").strip().lower() == table_name.strip().lower()
        and str(node.get("target_column") or "").strip().lower() == column_name.strip().lower()
    )


def _final_step_nodes_only(step_result: dict, table_name: str, column_name: str) -> list[dict]:
    """Keep only the final output nodes for this SQL step."""

    nodes = [node for node in step_result.get("nodes") or [] if isinstance(node, dict)]
    final_nodes = [node for node in nodes if _node_matches_target(node, table_name, column_name)]
    return final_nodes or nodes


def _step_cache_key(table_name: str, column_name: str, context_hash: str) -> str:
    return f"step:{table_name.lower()}:{column_name.lower()}:{context_hash}"


def _get_cached_step(table_name: str, column_name: str, script_paths: list[str]) -> tuple[dict | None, str, list[str]]:
    ctx_hash, normalized = _context_hash(script_paths)
    key = _step_cache_key(table_name, column_name, ctx_hash)
    with _connect() as conn:
        row = conn.execute(
            """
            SELECT step_result, scripts_used, created_at
            FROM lineage_step_cache
            WHERE cache_key = ?
            """,
            (key,),
        ).fetchone()
    if not row:
        return None, ctx_hash, normalized
    result = json.loads(row[0])
    result["_cache_created_at"] = row[2]
    result["_scripts_used"] = json.loads(row[1])
    return result, ctx_hash, normalized


def _get_current_cached_step(table_name: str, column_name: str) -> tuple[dict, list[str], str] | None:
    with _connect() as conn:
        rows = conn.execute(
            """
            SELECT step_result, scripts_used, context_hash, created_at
            FROM lineage_step_cache
            WHERE table_name = ? AND column_name = ?
            ORDER BY created_at DESC
            """,
            (table_name.lower(), column_name.lower()),
        ).fetchall()
    for result_text, scripts_json, cached_hash, created_at in rows:
        try:
            scripts = json.loads(scripts_json)
            current_hash, normalized = _context_hash(scripts)
        except Exception:
            continue
        if current_hash == cached_hash:
            result = json.loads(result_text)
            result["_cache_created_at"] = created_at
            result["_scripts_used"] = normalized
            return result, normalized, current_hash
    return None


def _save_step_cache(
    table_name: str,
    column_name: str,
    context_hash: str,
    step_result: dict,
    script_paths: list[str],
) -> None:
    with _connect() as conn:
        conn.execute(
            """
            INSERT OR REPLACE INTO lineage_step_cache
                (cache_key, table_name, column_name, context_hash, step_result, scripts_used, created_at)
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """,
            (
                _step_cache_key(table_name, column_name, context_hash),
                table_name.lower(),
                column_name.lower(),
                context_hash,
                json.dumps(step_result, ensure_ascii=False),
                json.dumps(script_paths),
            ),
        )


def _get_current_cached_lineage(table_name: str, column_name: str) -> tuple[str, list[str], str] | None:
    with _connect() as conn:
        rows = conn.execute(
            """
            SELECT lineage_result, scripts_used, context_hash, created_at
            FROM lineage_cache
            WHERE table_name = ? AND column_name = ?
            ORDER BY created_at DESC
            """,
            (table_name.lower(), column_name.lower()),
        ).fetchall()
    valid: list[tuple[int, str, str, list[str], str]] = []
    for result_text, scripts_json, cached_hash, created_at in rows:
        try:
            scripts = json.loads(scripts_json)
            current_hash, normalized = _context_hash(scripts)
        except Exception:
            continue
        if current_hash == cached_hash:
            valid.append((_lineage_node_count(result_text), str(created_at), result_text, normalized, current_hash))
    if not valid:
        return None
    valid.sort(key=lambda item: (item[0], item[1]), reverse=True)
    _, _created_at, result_text, normalized, current_hash = valid[0]
    return result_text, normalized, current_hash


@tool("lineage_list_sql_files", parse_docstring=True, response_format="content_and_artifact")
def lineage_list_sql_files(limit: int = 250) -> tuple[str, dict]:
    """List local SQL lineage source files under runtime/work/sql-lineage/SQL.

    Args:
        limit: Maximum number of file paths to return.

    Returns:
        A compact file list and scan statistics.
    """
    files = _iter_sql_files()
    root = _sql_root()
    rels = [path.relative_to(root).as_posix() for path in files]
    with _connect() as conn:
        for path in files:
            rel = path.relative_to(root).as_posix()
            content = path.read_text(encoding="utf-8", errors="replace")
            conn.execute(
                """
                INSERT OR REPLACE INTO lineage_file_index
                    (file_path, file_hash, size_bytes, updated_at)
                VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                """,
                (rel, _hash_text(content), path.stat().st_size),
            )
    shown = rels[: max(limit, 0)]
    message = (
        f"SQL lineage root: {root}\n"
        f"Found {len(rels)} SQL/text files. Showing {len(shown)}.\n"
        + "\n".join(f"- {item}" for item in shown)
    )
    return message, _next_artifact({"files": shown, "total_files": len(rels)})


@tool("lineage_search_sql_files", parse_docstring=True, response_format="content_and_artifact")
def lineage_search_sql_files(
    query_terms: list[str],
    limit: int = 25,
    max_preview_chars: int = 500,
) -> tuple[str, dict]:
    """Search local SQL files by literal terms in path or content.

    Args:
        query_terms: Table names, column names, layer names, or other literal terms to search.
        limit: Maximum number of candidate files to return.
        max_preview_chars: Maximum preview characters per matched file.

    Returns:
        Ranked candidate files with matching terms and small text previews.
    """
    terms = [term.strip().lower() for term in query_terms if str(term).strip()]
    if not terms:
        return "No query terms provided.", _next_artifact({"matches": []})

    matches = []
    for item in _search_matches(query_terms, limit=10_000):
        path = _sql_root() / item["file_path"]
        text = path.read_text(encoding="utf-8", errors="replace")
        first_pos = int(item["first_pos"])
        start = max(first_pos - 120, 0)
        preview = text[start : start + max_preview_chars].replace("\x00", "")
        matches.append({**item, "preview": preview})

    limited = matches[: max(limit, 0)]
    lines = [f"Found {len(matches)} candidate files. Showing {len(limited)}."]
    for item in limited:
        lines.append(
            f"- {item['file_path']} | score={item['score']} | terms={item['matched_terms']}"
        )
    return "\n".join(lines), _next_artifact({"matches": limited, "total_matches": len(matches)})


@tool("lineage_collect_analysis_context", parse_docstring=True, response_format="content_and_artifact")
def lineage_collect_analysis_context(
    table_name: str,
    column_name: str,
    extra_terms: list[str] | None = None,
    max_files: int = 40,
    max_chars_per_file: int = 20000,
) -> tuple[str, dict]:
    """Collect target and likely upstream SQL files for a lineage analysis.

    Args:
        table_name: Target table name understood by the LLM.
        column_name: Target column name understood by the LLM.
        extra_terms: Optional additional table, column, or layer names to search.
        max_files: Maximum SQL files to include in the analysis package.
        max_chars_per_file: Maximum characters to include for each file.

    Returns:
        A lineage analysis package with candidate SQL contents and cache status.
    """
    if not table_name.strip() or not column_name.strip():
        return "Missing table_name or column_name.", _next_artifact({"status": "error"})

    seed_terms = [table_name, table_name.split(".")[-1], column_name]
    seed_terms.extend(extra_terms or [])
    selected: dict[str, dict] = {}
    initial_limit = min(max(max_files // 3, 4), max_files)
    frontier = _search_matches(seed_terms, limit=initial_limit)

    for match in frontier:
        selected.setdefault(match["file_path"], match)

    # Expand once or twice from table-like identifiers in the files already selected.
    for _ in range(3):
        if len(selected) >= max_files:
            break
        expansion_terms: list[str] = []
        for rel in list(selected):
            content = (_sql_root() / rel).read_text(encoding="utf-8", errors="replace")
            expansion_terms.extend(_table_like_terms(content))
        if not expansion_terms:
            break
        for term in expansion_terms:
            if len(selected) >= max_files:
                break
            term_group = [term]
            if "." in term:
                term_group.append(term.split(".")[-1])
            for match in _search_matches(term_group, limit=3):
                selected.setdefault(match["file_path"], match)
                if len(selected) >= max_files:
                    break
        for match in _search_matches(expansion_terms, limit=max_files * 3):
            selected.setdefault(match["file_path"], match)
            if len(selected) >= max_files:
                break

    chosen = sorted(selected.values(), key=lambda item: (-item["score"], item["file_path"]))[
        : max(max_files, 0)
    ]
    script_paths = [item["file_path"] for item in chosen]

    cache_status = "miss"
    cached_result = None
    context_hash = None
    if script_paths:
        context_hash, normalized = _context_hash(script_paths)
        script_paths = normalized
        key = f"{table_name.lower()}:{column_name.lower()}:{context_hash}"
        with _connect() as conn:
            row = conn.execute(
                """
                SELECT lineage_result, scripts_used, created_at
                FROM lineage_cache
                WHERE cache_key = ?
                """,
                (key,),
            ).fetchone()
        if row:
            cache_status = "hit"
            cached_result = {
                "lineage_result": row[0],
                "scripts_used": json.loads(row[1]),
                "created_at": row[2],
            }

    file_blocks = []
    files = []
    for rel in script_paths:
        content = (_sql_root() / rel).read_text(encoding="utf-8", errors="replace")
        truncated = len(content) > max_chars_per_file
        files.append(
            {
                "file_path": rel,
                "size_chars": len(content),
                "truncated": truncated,
                "sha256": _hash_text(content),
            }
        )
        file_blocks.append(
            f"--- SQL File: {rel} ---\n{content[:max_chars_per_file]}"
            + ("\n...[truncated]..." if truncated else "")
        )

    lines = [
        f"Lineage analysis package for {table_name}.{column_name}",
        f"Cache status: {cache_status}",
        f"Context hash: {context_hash or 'none'}",
        f"Files included: {len(files)}",
    ]
    lines.extend(f"- {item['file_path']}" for item in files)
    if cached_result:
        lines.append("\nCached lineage result:")
        lines.append(cached_result["lineage_result"])
    else:
        lines.append("\nSQL context:")
        lines.append("\n\n".join(file_blocks))

    return "\n".join(lines), _next_artifact(
        {
            "status": "success",
            "cache_status": cache_status,
            "cached_result": cached_result,
            "context_hash": context_hash,
            "script_paths": script_paths,
            "files": files,
        }
    )


@tool("lineage_analyze_column", parse_docstring=True, response_format="content_and_artifact")
def lineage_analyze_column(
    table_name: str,
    column_name: str,
    extra_terms: list[str] | None = None,
    max_files: int = 6,
    max_chars_per_file: int = 20000,
    max_depth: int = 10,
) -> tuple[str, dict]:
    """Analyze a target column lineage end-to-end and enforce cache handling in Python.

    This action collects target and upstream SQL context, checks SQLite cache, calls the configured
    OpenAI-compatible LLM only when cache misses, saves the result, and returns the final lineage.

    Args:
        table_name: Target table name understood from the user's request.
        column_name: Target column name understood from the user's request.
        extra_terms: Optional extra table, column, or layer names to improve context collection.
        max_files: Maximum local SQL files to read per lineage step.
        max_chars_per_file: Maximum characters per SQL file sent to the lineage LLM.
        max_depth: Maximum upstream steps to inspect.

    Returns:
        Final lineage answer with cache status and scripts used.
    """
    state = _RUNTIME_STATE
    max_depth = max(max_depth, 10)
    emit_skill_status(
        state,
        f"Checking lineage cache for `{table_name}.{column_name}`",
        skill_name="lineage",
    )
    whole_cache = _get_current_cached_lineage(table_name, column_name)
    if whole_cache:
        result_text, scripts, context_hash = whole_cache
        formatted = _format_lineage_result(table_name, column_name, result_text, "hit")
        emit_skill_status(
            state,
            f"Cache hit for `{table_name}.{column_name}`",
            skill_name="lineage",
        )
        return formatted, _lineage_success_artifact(
            state=state,
            table_name=table_name,
            column_name=column_name,
            formatted=formatted,
            cache_status="hit",
            lineage_result=result_text,
            script_paths=scripts,
            context_hash=context_hash,
        )

    queue: list[dict[str, str]] = [{"table": table_name, "column": column_name, "reason": "root"}]
    seen_targets: set[tuple[str, str]] = set()
    script_paths: list[str] = []
    nodes: list[dict] = []
    ambiguities: list = []
    step_records: list[dict] = []

    for depth in range(max_depth):
        if not queue:
            break
        current = queue.pop(0)
        current_table = str(current.get("table") or "").strip()
        current_column = str(current.get("column") or "").strip() or "*"
        key = (current_table.lower(), current_column.lower())
        if not current_table or key in seen_targets:
            continue
        seen_targets.add(key)

        cached_current_step = _get_current_cached_step(current_table, current_column)
        if cached_current_step:
            step_result, cached_step_files, _cached_hash = cached_current_step
            step_result = _augment_direct_dependency_nodes(
                step_result,
                current_table,
                current_column,
                cached_step_files,
            )
            for step_file in cached_step_files:
                if step_file not in script_paths:
                    script_paths.append(step_file)
            emit_skill_status(
                state,
                f"Step cache hit for `{current_table}.{current_column}`",
                skill_name="lineage",
            )
            step_nodes = _final_step_nodes_only(step_result, current_table, current_column)
            step_result["nodes"] = step_nodes
            nodes.extend(step_nodes)
            ambiguities.extend(step_result.get("ambiguities") or [])
            step_records.append(
                {
                    "depth": depth,
                    "target": {"table": current_table, "column": current_column},
                    "files": cached_step_files,
                    "nodes": step_nodes,
                    "next_targets": step_result.get("next_targets") or [],
                    "cache_status": "hit",
                }
            )
            for nxt in step_result.get("next_targets") or []:
                next_table = str(nxt.get("table") or "").strip()
                next_column = str(nxt.get("column") or "").strip() or "*"
                next_key = (next_table.lower(), next_column.lower())
                if next_table and next_key not in seen_targets:
                    queue.append({"table": next_table, "column": next_column, "reason": str(nxt.get("reason") or "")})
            continue

        emit_skill_status(
            state,
            f"Selecting SQL files for `{current_table}.{current_column}`",
            skill_name="lineage",
        )
        step_files = _select_step_files_with_llm(
            current_table,
            current_column,
            max_files=max_files,
            state=state,
        )
        if not step_files and "." in current_table:
            step_files = _select_step_files_with_llm(
                current_table.split(".")[-1],
                current_column,
                max_files=max_files,
                state=state,
            )
        if not step_files:
            ambiguities.append(
                {
                    "target": f"{current_table}.{current_column}",
                    "reason": "No local SQL producer file found for this upstream target.",
                }
            )
            continue

        for step_file in step_files:
            if step_file not in script_paths:
                script_paths.append(step_file)
        emit_skill_status(
            state,
            f"Analyzing `{current_table}.{current_column}` from {len(step_files)} SQL file(s)",
            skill_name="lineage",
            detail={
                "type": "code",
                "tool": "lineage_analyze_column",
                "label": "SQL files",
                "query": "\n".join(step_files),
                "result": "",
            },
        )
        cached_step, step_ctx_hash, normalized_step_files = _get_cached_step(
            current_table,
            current_column,
            step_files,
        )
        if cached_step:
            step_result = cached_step
            step_result = _augment_direct_dependency_nodes(
                step_result,
                current_table,
                current_column,
                normalized_step_files,
            )
            emit_skill_status(
                state,
                f"Step cache hit for `{current_table}.{current_column}`",
                skill_name="lineage",
            )
        else:
            step_prompt = _build_step_prompt(
                table_name,
                column_name,
                current_table,
                current_column,
                step_files,
                max_chars_per_file,
            )
            step_text = _call_openai_step(step_prompt, state)
            step_result = _parse_json_object(step_text)
            step_result = _augment_direct_dependency_nodes(
                step_result,
                current_table,
                current_column,
                normalized_step_files,
            )
            _save_step_cache(
                current_table,
                current_column,
                step_ctx_hash,
                step_result,
                normalized_step_files,
            )
        step_nodes = _final_step_nodes_only(step_result, current_table, current_column)
        step_result["nodes"] = step_nodes
        nodes.extend(step_nodes)
        ambiguities.extend(step_result.get("ambiguities") or [])
        step_records.append(
            {
                "depth": depth,
                "target": {"table": current_table, "column": current_column},
                "files": step_files,
                "nodes": step_nodes,
                "next_targets": step_result.get("next_targets") or [],
            }
        )

        for nxt in step_result.get("next_targets") or []:
            next_table = str(nxt.get("table") or "").strip()
            next_column = str(nxt.get("column") or "").strip() or "*"
            next_key = (next_table.lower(), next_column.lower())
            if next_table and next_key not in seen_targets:
                queue.append({"table": next_table, "column": next_column, "reason": str(nxt.get("reason") or "")})

    script_paths = list(dict.fromkeys(script_paths))
    if not script_paths:
        return (
            f"No local SQL files were found for {table_name}.{column_name}. "
            "Ask the user to add SQL files under runtime/work/sql-lineage/SQL or clarify the target name.",
            _next_artifact({"status": "error", "cache_status": "miss", "script_paths": []}),
        )

    ctx_hash, normalized = _context_hash(script_paths)
    cached = None
    key = f"{table_name.lower()}:{column_name.lower()}:{ctx_hash}"
    with _connect() as conn:
        row = conn.execute(
            """
            SELECT lineage_result, scripts_used, created_at
            FROM lineage_cache
            WHERE cache_key = ?
            """,
            (key,),
        ).fetchone()
        if row:
            cached = {
                "lineage_result": row[0],
                "scripts_used": json.loads(row[1]),
                "created_at": row[2],
            }
    if cached:
        result_text = str(cached["lineage_result"])
        formatted_hit = _format_lineage_result(table_name, column_name, result_text, "hit")
        return formatted_hit, _lineage_success_artifact(
            state=state,
            table_name=table_name,
            column_name=column_name,
            formatted=formatted_hit,
            cache_status="hit",
            lineage_result=result_text,
            script_paths=cached["scripts_used"],
            context_hash=ctx_hash,
        )

    result = {
        "target": {"table": table_name, "column": column_name},
        "summary": (
            f"Lineage was traced step by step from {table_name}.{column_name} using "
            f"{len(normalized)} local SQL files."
        ),
        "lineage_tree": {"nodes": nodes},
        "ambiguities": ambiguities,
        "scripts_used": normalized,
        "analysis_steps": step_records,
    }
    result_text = json.dumps(result, ensure_ascii=False)

    save_text, save_artifact = lineage_save_cache.func(
        table_name=table_name,
        column_name=column_name,
        lineage_result=result_text,
        script_paths=normalized,
    )
    formatted = _format_lineage_result(table_name, column_name, result_text, "miss then saved")
    formatted_saved = formatted + f"\n\nCache saved: {save_artifact.get('context_hash')}"
    return (
        formatted_saved,
        _lineage_success_artifact(
            state=state,
            table_name=table_name,
            column_name=column_name,
            formatted=formatted_saved,
            cache_status="saved",
            lineage_result=result_text,
            script_paths=normalized,
            context_hash=save_artifact.get("context_hash"),
            extra={"save_message": save_text},
        ),
    )


@tool("lineage_read_sql_files", parse_docstring=True, response_format="content_and_artifact")
def lineage_read_sql_files(
    file_paths: list[str],
    max_chars_per_file: int = 30000,
) -> tuple[str, dict]:
    """Read selected SQL lineage files.

    Args:
        file_paths: Relative paths under runtime/work/sql-lineage/SQL.
        max_chars_per_file: Maximum characters to return for each file.

    Returns:
        File contents, truncated only when a file exceeds the requested limit.
    """
    if not file_paths:
        return "No file paths provided.", _next_artifact({"files": []})

    files = []
    blocks = []
    for file_path in file_paths:
        rel, content = _read_rel(file_path)
        truncated = len(content) > max_chars_per_file
        shown = content[:max_chars_per_file]
        files.append(
            {
                "file_path": rel,
                "size_chars": len(content),
                "truncated": truncated,
                "sha256": _hash_text(content),
            }
        )
        suffix = "\n...[truncated]..." if truncated else ""
        blocks.append(f"--- SQL File: {rel} ---\n{shown}{suffix}")

    return "\n\n".join(blocks), _next_artifact({"files": files})


@tool("lineage_check_cache", parse_docstring=True, response_format="content_and_artifact")
def lineage_check_cache(
    table_name: str,
    column_name: str,
    script_paths: list[str],
) -> tuple[str, dict]:
    """Check whether lineage for a table column and script context is already cached.

    Args:
        table_name: Target table name understood by the LLM.
        column_name: Target column name understood by the LLM.
        script_paths: SQL files that define the current analysis context.

    Returns:
        Cache hit or miss with cached result when available.
    """
    if not table_name.strip() or not column_name.strip():
        return "Missing table_name or column_name.", _next_artifact({"cache_status": "error"})
    if not script_paths:
        return "No script paths provided for cache context.", _next_artifact({"cache_status": "miss"})

    ctx_hash, normalized = _context_hash(script_paths)
    key = f"{table_name.lower()}:{column_name.lower()}:{ctx_hash}"
    with _connect() as conn:
        row = conn.execute(
            """
            SELECT lineage_result, scripts_used, created_at
            FROM lineage_cache
            WHERE cache_key = ?
            """,
            (key,),
        ).fetchone()
    if not row:
        return (
            f"Cache miss for {table_name}.{column_name} with context hash {ctx_hash}.",
            _next_artifact(
                {
                    "cache_status": "miss",
                    "context_hash": ctx_hash,
                    "script_paths": normalized,
                }
            ),
        )

    result = {
        "cache_status": "hit",
        "context_hash": ctx_hash,
        "lineage_result": row[0],
        "scripts_used": json.loads(row[1]),
        "created_at": row[2],
    }
    return (
        f"Cache hit for {table_name}.{column_name} created at {row[2]}.\n{row[0]}",
        _next_artifact(result),
    )


@tool("lineage_save_cache", parse_docstring=True, response_format="content_and_artifact")
def lineage_save_cache(
    table_name: str,
    column_name: str,
    lineage_result: str,
    script_paths: list[str],
) -> tuple[str, dict]:
    """Save a completed lineage analysis to SQLite cache.

    Args:
        table_name: Target table name.
        column_name: Target column name.
        lineage_result: Final lineage result as JSON text or Markdown text.
        script_paths: SQL files used to produce the result.

    Returns:
        Cache key, context hash, and saved script list.
    """
    if not table_name.strip() or not column_name.strip():
        return "Missing table_name or column_name.", _next_artifact({"cache_status": "error"})
    if not lineage_result.strip():
        return "Missing lineage_result.", _next_artifact({"cache_status": "error"})
    if not script_paths:
        return "No script paths provided.", _next_artifact({"cache_status": "error"})

    ctx_hash, normalized = _context_hash(script_paths)
    key = f"{table_name.lower()}:{column_name.lower()}:{ctx_hash}"
    with _connect() as conn:
        conn.execute(
            """
            INSERT OR REPLACE INTO lineage_cache
                (cache_key, table_name, column_name, context_hash, lineage_result, scripts_used, created_at)
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """,
            (
                key,
                table_name.lower(),
                column_name.lower(),
                ctx_hash,
                lineage_result,
                json.dumps(normalized),
            ),
        )
    return (
        f"Saved lineage cache for {table_name}.{column_name} with context hash {ctx_hash}.",
        _next_artifact(
            {
                "cache_status": "saved",
                "cache_key": key,
                "context_hash": ctx_hash,
                "script_paths": normalized,
            }
        ),
    )


def _load_lineage_result_for_export(
    table_name: str,
    column_name: str,
    lineage_result: str = "",
) -> tuple[str, list[dict], list[str], str | None, str | None]:
    if not table_name.strip() or not column_name.strip():
        return "Missing table_name or column_name.", [], [], None, "error"

    result_text = lineage_result.strip()
    scripts: list[str] = []
    context_hash = None
    if not result_text:
        cached = _get_current_cached_lineage(table_name, column_name)
        if not cached:
            return f"No cached lineage found for {table_name}.{column_name}. Run lineage_analyze_column first.", [], [], None, "cache_miss"
        result_text, scripts, context_hash = cached

    nodes = _lineage_nodes_from_text(result_text)
    if not nodes:
        return "No lineage nodes found to export.", [], scripts, context_hash, "empty"
    return result_text, nodes, scripts, context_hash, None


@tool("lineage_export_csv", parse_docstring=True, response_format="content_and_artifact")
def lineage_export_csv(
    table_name: str,
    column_name: str,
    lineage_result: str = "",
    delimiter: str = ",",
    state: Annotated[WorkflowState | None, InjectedToolArg] = None,
) -> tuple[str, dict]:
    """Export a cached or provided lineage result to a session draft CSV file.

    Args:
        table_name: Target table name for the lineage result.
        column_name: Target column name for the lineage result.
        lineage_result: Optional lineage JSON text. When empty, the best valid cache is used.
        delimiter: CSV field separator. Defaults to comma; semicolon is also supported.
        state: Runtime state injected by the app.

    Returns:
        Draft file path and exported row count.
    """
    result_text, nodes, scripts, context_hash, error_status = _load_lineage_result_for_export(
        table_name,
        column_name,
        lineage_result,
    )
    if error_status:
        return result_text, _next_artifact({"status": error_status})

    chosen_delimiter = delimiter or "\t"
    if chosen_delimiter.lower() in {"tab", "\\t"}:
        chosen_delimiter = "\t"
    elif len(chosen_delimiter) > 1:
        chosen_delimiter = chosen_delimiter[0]

    output_name = f"{_safe_export_name(table_name, column_name)}.csv"
    output_path = _session_draft_dir(state) / output_name

    headers = ["Source", "Target", "SQL rule", "Script", "Filters", "Notes"]
    with output_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle, delimiter=chosen_delimiter)
        writer.writerow(headers)
        writer.writerows(_lineage_export_rows(nodes))

    relative = f"draft/{output_path.parent.name}/{output_path.name}"
    message = f"Exported {len(nodes)} lineage rows to {relative}."
    return (
        message,
        _next_artifact(
            {
                "status": "success",
                "file_path": str(output_path),
                "relative_path": relative,
                "rows": len(nodes),
                "delimiter": "\\t" if chosen_delimiter == "\t" else chosen_delimiter,
                "context_hash": context_hash,
                "scripts_used": scripts,
            }
        ),
    )


@tool("lineage_export_excel", parse_docstring=True, response_format="content_and_artifact")
def lineage_export_excel(
    table_name: str,
    column_name: str,
    lineage_result: str = "",
    state: Annotated[WorkflowState | None, InjectedToolArg] = None,
) -> tuple[str, dict]:
    """Export a cached or provided lineage result to a session draft Excel workbook.

    Args:
        table_name: Target table name for the lineage result.
        column_name: Target column name for the lineage result.
        lineage_result: Optional lineage JSON text. When empty, the best valid cache is used.
        state: Runtime state injected by the app.

    Returns:
        Draft Excel file path and exported row count.
    """
    result_text, nodes, scripts, context_hash, error_status = _load_lineage_result_for_export(
        table_name,
        column_name,
        lineage_result,
    )
    if error_status:
        return result_text, _next_artifact({"status": error_status})

    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter
    except Exception as exc:
        return (
            f"Excel export requires openpyxl, but it is not available: {exc}",
            _next_artifact({"status": "dependency_missing"}),
        )

    output_name = f"{_safe_export_name(table_name, column_name)}.xlsx"
    output_path = _session_draft_dir(state) / output_name
    headers = ["Source", "Target", "SQL rule", "Script", "Filters", "Notes"]
    rows = _lineage_export_rows(nodes)

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Lineage"
    for col_idx, header in enumerate(headers, start=1):
        cell = sheet.cell(row=1, column=col_idx, value=header)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F4E78")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for row_idx, row in enumerate(rows, start=2):
        for col_idx, value in enumerate(row, start=1):
            cell = sheet.cell(row=row_idx, column=col_idx, value=value)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    widths = [42, 42, 72, 36, 44, 60]
    for col_idx, width in enumerate(widths, start=1):
        sheet.column_dimensions[get_column_letter(col_idx)].width = width
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = f"A1:F{len(rows) + 1}"

    summary = workbook.create_sheet("Summary")
    summary["A1"] = f"Lineage export: {table_name}.{column_name}"
    summary["A1"].font = Font(bold=True, size=14)
    summary["A3"] = f"Rows: {len(rows)}"
    summary["A4"] = f"Context hash: {context_hash or 'provided result'}"
    summary["A5"] = f"Scripts used: {len(scripts)}"
    summary.column_dimensions["A"].width = 120
    workbook.save(output_path)

    relative = f"draft/{output_path.parent.name}/{output_path.name}"
    message = f"Exported {len(nodes)} lineage rows to {relative}."
    return (
        message,
        _next_artifact(
            {
                "status": "success",
                "file_path": str(output_path),
                "relative_path": relative,
                "rows": len(nodes),
                "context_hash": context_hash,
                "scripts_used": scripts,
            }
        ),
    )


@tool("lineage_list_cached_columns", parse_docstring=True, response_format="content_and_artifact")
def lineage_list_cached_columns(limit: int = 100) -> tuple[str, dict]:
    """List cached lineage analyses.

    Args:
        limit: Maximum cached rows to return.

    Returns:
        Cached table/column pairs and script counts.
    """
    with _connect() as conn:
        rows = conn.execute(
            """
            SELECT table_name, column_name, scripts_used, created_at
            FROM lineage_cache
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (max(limit, 0),),
        ).fetchall()
    cached = [
        {
            "table": row[0],
            "column": row[1],
            "scripts_count": len(json.loads(row[2] or "[]")),
            "created_at": row[3],
        }
        for row in rows
    ]
    lines = [f"Cached lineage analyses: {len(cached)}"]
    lines.extend(
        f"- {item['table']}.{item['column']} | scripts={item['scripts_count']} | {item['created_at']}"
        for item in cached
    )
    return "\n".join(lines), _next_artifact({"cached_columns": cached})


@tool("lineage_cache_stats", parse_docstring=True, response_format="content_and_artifact")
def lineage_cache_stats() -> tuple[str, dict]:
    """Return SQL lineage file and cache statistics.

    Returns:
        Number of local SQL files and cached lineage analyses.
    """
    files = _iter_sql_files()
    with _connect() as conn:
        cached = conn.execute("SELECT COUNT(*) FROM lineage_cache").fetchone()[0]
        indexed = conn.execute("SELECT COUNT(*) FROM lineage_file_index").fetchone()[0]
    message = (
        f"SQL files available: {len(files)}\n"
        f"Indexed files in cache DB: {indexed}\n"
        f"Cached lineage analyses: {cached}\n"
        f"Cache path: {_cache_path()}"
    )
    return message, _next_artifact(
        {
            "sql_files": len(files),
            "indexed_files": indexed,
            "cached_lineage": cached,
            "cache_path": str(_cache_path()),
        }
    )


@tool("lineage_clear_cache", parse_docstring=True, response_format="content_and_artifact")
def lineage_clear_cache(
    confirm: bool,
    state: Annotated[WorkflowState | None, InjectedToolArg] = None,
) -> tuple[str, dict]:
    """Clear lineage result cache when the user explicitly asks for it.

    Args:
        confirm: Must be true only after the user explicitly requested cache clearing.
        state: Injected runtime state.

    Returns:
        Cache clearing result.
    """
    if not confirm:
        return "Cache was not cleared because confirm=false.", _next_artifact({"cache_status": "kept"})
    with _connect() as conn:
        conn.execute("DELETE FROM lineage_cache")
    return "Lineage cache cleared.", _next_artifact({"cache_status": "cleared"})


skill_actions = {
    "lineage_analyze_column": lineage_analyze_column,
    "lineage_collect_analysis_context": lineage_collect_analysis_context,
    "lineage_list_sql_files": lineage_list_sql_files,
    "lineage_search_sql_files": lineage_search_sql_files,
    "lineage_read_sql_files": lineage_read_sql_files,
    "lineage_check_cache": lineage_check_cache,
    "lineage_save_cache": lineage_save_cache,
    "lineage_export_csv": lineage_export_csv,
    "lineage_export_excel": lineage_export_excel,
    "lineage_list_cached_columns": lineage_list_cached_columns,
    "lineage_cache_stats": lineage_cache_stats,
    "lineage_clear_cache": lineage_clear_cache,
}
