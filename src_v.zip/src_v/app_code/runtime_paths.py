"""Central paths for mutable runtime data.

Code under src/ should be treated as immutable during normal app execution. Runtime state, logs,
draft artifacts, working files, and local configuration live under the repository-level runtime/
directory by default.
"""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv


def repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def runtime_root() -> Path:
    configured = os.getenv("AGENT_RUNTIME_DIR")
    if configured:
        path = Path(configured).expanduser()
        if not path.is_absolute():
            path = repo_root() / path
        return path.resolve()
    return repo_root() / "runtime"


def runtime_path(*parts: str) -> Path:
    return runtime_root().joinpath(*parts)


def env_path() -> Path:
    return runtime_path("env")


def bd_env_path() -> Path:
    return runtime_path("bd_env")


def work_root() -> Path:
    return runtime_path("work")


def draft_root() -> Path:
    return runtime_path("draft")


def logs_root() -> Path:
    return runtime_path("logs")


def runtime_data_root() -> Path:
    return runtime_path("runtime_data")


def mcp_root() -> Path:
    return runtime_path("MCP")


def mcp_json_root() -> Path:
    return mcp_root() / "json"


def mcp_runtime_dir() -> Path:
    return mcp_root() / "mcp_runtime"


def onboarding_prompt_path() -> Path:
    return runtime_path("onbording.md")


def load_runtime_env(*, override: bool = False) -> None:
    """Load runtime env and bd_env files.

    Legacy root-level environment files are intentionally not loaded here; after migration the
    runtime directory is the single mutable configuration location.
    """

    load_dotenv(env_path(), override=override)
    load_dotenv(bd_env_path(), override=True)
