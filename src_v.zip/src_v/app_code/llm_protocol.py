"""LLM tool-calling protocol selection.

Some OpenAI-compatible gateways only allow plain chat requests and reject the native
OpenAI `tools` payload. In that case the runtime can ask the model to return a JSON
action envelope, then execute the selected tool locally.
"""

from __future__ import annotations

import os


def llm_tools_mode() -> str:
    """Return `native` or `json`."""

    raw = os.getenv("LLM_TOOLS_MODE", "native").strip().lower()
    if raw in {"native", "openai", "tools", "tool"}:
        return "native"
    if raw in {"json", "chat", "text", "none", "disabled", "disable"}:
        return "json"
    return "native"


def use_native_llm_tools() -> bool:
    return llm_tools_mode() == "native"
