"""HTTPS verification switches for private-network deployments."""

from __future__ import annotations

import json
import logging
import os
from typing import Any


def env_flag(name: str, default: str = "false") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "on"}


def disable_https_verify() -> bool:
    return env_flag("DISABLE_HTTPS_VERIFY")


def https_verify_enabled() -> bool:
    return not disable_https_verify()


def warn_if_https_verify_disabled() -> None:
    if disable_https_verify():
        logging.warning(
            "DISABLE_HTTPS_VERIFY=true: HTTPS certificate verification is disabled for this runtime."
        )


def openai_http_client_kwargs() -> dict[str, Any]:
    """Return ChatOpenAI kwargs for custom headers and httpx TLS verification."""

    kwargs: dict[str, Any] = {}
    headers = openai_default_headers()
    if headers:
        kwargs["default_headers"] = headers
    if https_verify_enabled():
        return kwargs

    import httpx

    warn_if_https_verify_disabled()
    kwargs.update(
        {
            "http_client": httpx.Client(verify=False),
            "http_async_client": httpx.AsyncClient(verify=False),
        }
    )
    return kwargs


def openai_default_headers() -> dict[str, str]:
    """Build custom headers for OpenAI-compatible gateways."""

    headers: dict[str, str] = {}
    if env_flag("DEV_STUDIO_COMPAT_HEADERS"):
        headers.update(
            {
                "Accept": "*/*",
                "Connection": "close",
                "User-Agent": "node-fetch",
            }
        )

    raw_json = os.getenv("OPENAI_DEFAULT_HEADERS_JSON", "").strip()
    if raw_json:
        try:
            parsed = json.loads(raw_json)
            if not isinstance(parsed, dict):
                raise ValueError("OPENAI_DEFAULT_HEADERS_JSON must be a JSON object")
            headers.update({str(key): str(value) for key, value in parsed.items()})
        except Exception:
            logging.exception("Failed to parse OPENAI_DEFAULT_HEADERS_JSON")

    raw_pairs = os.getenv("OPENAI_DEFAULT_HEADERS", "").strip()
    if raw_pairs:
        for item in raw_pairs.replace("\n", ";").split(";"):
            if not item.strip():
                continue
            if ":" not in item:
                logging.warning("Ignoring malformed OPENAI_DEFAULT_HEADERS item: %s", item)
                continue
            key, value = item.split(":", 1)
            headers[key.strip()] = value.strip()

    return headers


def mcp_child_https_env() -> dict[str, str]:
    """Best-effort TLS-disable environment for MCP child processes."""

    if https_verify_enabled():
        return {}

    return {
        "DISABLE_HTTPS_VERIFY": "true",
        "PYTHONHTTPSVERIFY": "0",
        "NODE_TLS_REJECT_UNAUTHORIZED": "0",
        "SSL_VERIFY": "false",
        "REQUESTS_VERIFY": "false",
        "HTTPX_VERIFY": "false",
        "JIRA_SSL_VERIFY": "false",
        "CONFLUENCE_SSL_VERIFY": "false",
    }
