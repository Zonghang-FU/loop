"""MCP (Model Context Protocol) integration for the skill runtime.

Treats each MCP server as a pseudo-skill whose tools are automatically
discovered and wrapped as LangChain tools.

Environment variables:
  MCP_ENABLED          - Set to "true" to enable MCP support (default: false).
  ENABLED_MCP_SERVERS  - Comma-separated server names to load from runtime/MCP/.
                         If empty, all discovered servers are loaded.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field, create_model

from app_code.runtime_paths import mcp_json_root, mcp_runtime_dir, load_runtime_env
from app_code.https_config import mcp_child_https_env, warn_if_https_verify_disabled

load_runtime_env()

_MCP_CONNECTED = False
_MCP_TOOLS_BY_SERVER: dict[str, dict[str, StructuredTool]] = {}
_MCP_SESSIONS: dict[str, dict[str, Any]] = {}
_MCP_SKILL_METADATA_CACHE: dict[str, dict] | None = None
_MCP_CLEANUP_TASKS: list[tuple[Any, Any, Any]] = []

_logger = logging.getLogger(__name__)


def _mcp_enabled() -> bool:
    raw = os.getenv("MCP_ENABLED", "false")
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _split_server_list(raw_value: str) -> set[str]:
    normalized = raw_value.replace("\n", ",").replace(";", ",").split(",")
    return {item.strip().lower().replace("_", "-") for item in normalized if item.strip()}


def _enabled_mcp_server_names() -> set[str] | None:
    """Return the allowlist of MCP server names. None means load all."""
    raw = os.getenv("ENABLED_MCP_SERVERS")
    if raw is None:
        return None
    names = _split_server_list(raw)
    return names if names else None


def _json_type_to_python(json_type: str) -> type:
    mapping = {
        "string": str,
        "integer": int,
        "number": float,
        "boolean": bool,
    }
    return mapping.get(json_type, str)


def _json_schema_to_pydantic(schema: dict, model_name: str) -> type[BaseModel]:
    properties = schema.get("properties", {})
    required = set(schema.get("required", []))

    fields: dict[str, Any] = {}
    for prop_name, prop_schema in properties.items():
        prop_type = prop_schema.get("type", "string")
        description = prop_schema.get("description", "")
        python_type = _json_type_to_python(prop_type)

        if prop_name in required:
            fields[prop_name] = (python_type, Field(description=description))
        else:
            fields[prop_name] = (python_type, Field(default=None, description=description))

    if not fields:
        return create_model(model_name)

    return create_model(model_name, **fields)


def _discover_mcp_configs() -> list[dict]:
    if not _mcp_enabled():
        return []
    root = mcp_json_root()
    if not root.exists():
        return []
    allowlist = _enabled_mcp_server_names()
    configs: list[dict] = []
    for json_file in sorted(root.glob("*.json")):
        try:
            data = json.loads(json_file.read_text(encoding="utf-8"))
        except Exception:
            _logger.error("Failed to parse MCP config %s", json_file, exc_info=True)
            continue
        servers = data.get("mcpServers", {})
        for name, config in servers.items():
            normalized = name.strip().lower().replace("_", "-")
            if allowlist is not None and normalized not in allowlist:
                _logger.debug("MCP server '%s' not in ENABLED_MCP_SERVERS, skipping", name)
                continue
            config["_name"] = name
            config["_source"] = str(json_file)
            configs.append(config)
    return configs


def _build_mcp_skill_metadata() -> dict[str, dict]:
    metadata: dict[str, dict] = {}
    for config in _discover_mcp_configs():
        name = config["_name"]
        metadata[name] = {
            "name": name,
            "description": config.get("description", f"MCP server: {name}"),
            "directory": mcp_json_root(),
            "command": config.get("command", ""),
            "args": " ".join(config.get("args", [])),
        }
    return metadata


def get_mcp_skill_metadata() -> dict[str, dict]:
    global _MCP_SKILL_METADATA_CACHE
    if _MCP_SKILL_METADATA_CACHE is None:
        _MCP_SKILL_METADATA_CACHE = _build_mcp_skill_metadata()
    return _MCP_SKILL_METADATA_CACHE


def _refresh_mcp_skill_descriptions() -> None:
    """After MCP tools are discovered, update skill metadata with richer descriptions."""
    meta = get_mcp_skill_metadata()
    for server_name, tools in _MCP_TOOLS_BY_SERVER.items():
        if server_name not in meta:
            continue
        if tools:
            meta[server_name]["description"] = (
                f"I am {server_name}, I can perform {str(list(tools.keys()))} operations ({len(tools)} tools)"
            )


def list_mcp_skill_names() -> list[str]:
    return sorted(get_mcp_skill_metadata().keys())


def is_mcp_skill(skill_name: str) -> bool:
    return skill_name.strip().lower().replace("_", "-") in get_mcp_skill_metadata()


async def ensure_mcp_connected() -> None:
    global _MCP_CONNECTED, _MCP_CLEANUP_TASKS
    if _MCP_CONNECTED:
        return

    if not _mcp_enabled():
        _logger.debug("MCP_ENABLED is not true; MCP support is disabled")
        _MCP_CONNECTED = True
        return

    try:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import get_default_environment, stdio_client
    except ImportError:
        _logger.warning("MCP SDK not installed; MCP servers will not be available")
        _MCP_CONNECTED = True
        return

    configs = _discover_mcp_configs()
    _MCP_CLEANUP_TASKS = []

    sandbox_dir = mcp_runtime_dir()
    sandbox_dir.mkdir(parents=True, exist_ok=True)
    uv_cache_dir = sandbox_dir / "uv_cache"
    uv_tool_dir = sandbox_dir / "uv_tools"
    uv_cache_dir.mkdir(parents=True, exist_ok=True)
    uv_tool_dir.mkdir(parents=True, exist_ok=True)
    warn_if_https_verify_disabled()

    for config in configs:
        name = config["_name"]
        _MCP_TOOLS_BY_SERVER.setdefault(name, {})
        try:
            merged_env = {
                **get_default_environment(),
                "UV_CACHE_DIR": str(uv_cache_dir.resolve()),
                "UV_TOOL_DIR": str(uv_tool_dir.resolve()),
                **mcp_child_https_env(),
                **(config.get("env") or {}),
            }
            server_params = StdioServerParameters(
                command=config["command"],
                args=config.get("args", []),
                env=merged_env,
            )

            timeout = int(os.getenv("MCP_CONNECT_TIMEOUT", "30"))

            transport_ctx = stdio_client(server_params)
            read_stream, write_stream = await transport_ctx.__aenter__()
            session = ClientSession(read_stream, write_stream)
            await session.__aenter__()
            try:
                await asyncio.wait_for(session.initialize(), timeout=timeout)
                tools_response = await asyncio.wait_for(session.list_tools(), timeout=timeout)
            except Exception:
                await session.__aexit__(None, None, None)
                await transport_ctx.__aexit__(None, None, None)
                raise

            _MCP_SESSIONS[name] = {
                "session": session,
            }
            _MCP_CLEANUP_TASKS.append((name, session, transport_ctx))

            await _wrap_mcp_tools(name, tools_response)

        except asyncio.TimeoutError:
            _logger.error("MCP server '%s' connection timed out after %ds", name, timeout)
        except Exception:
            _logger.exception("Failed to connect MCP server '%s'", name)

    _refresh_mcp_skill_descriptions()
    _MCP_CONNECTED = True


async def _wrap_mcp_tools(server_name: str, tools_response) -> None:
    for mcp_tool in tools_response.tools:
        tool_name = mcp_tool.name
        qualified_name = f"mcp__{server_name}__{tool_name}"

        input_schema = getattr(mcp_tool, "inputSchema", None) or {}
        if isinstance(input_schema, dict) and input_schema.get("properties"):
            args_schema = _json_schema_to_pydantic(input_schema, qualified_name)
        else:
            args_schema = create_model(qualified_name)

        srv = server_name
        inner_name = mcp_tool.name

        async def _make_callable(server=srv, tool=inner_name):
            async def _call(**kwargs):
                s = _MCP_SESSIONS[server]["session"]
                result = await s.call_tool(tool, kwargs)
                texts: list[str] = []
                for c in result.content:
                    if hasattr(c, "text"):
                        texts.append(c.text)
                return "\n".join(texts) if texts else str(result.content)
            return _call

        langchain_tool = StructuredTool(
            name=qualified_name,
            description=mcp_tool.description or f"MCP tool '{tool_name}' from server '{server_name}'",
            args_schema=args_schema,
            coroutine=await _make_callable(),
        )

        _MCP_TOOLS_BY_SERVER[server_name][qualified_name] = langchain_tool

    _logger.info(
        "MCP server '%s' connected with %d tools: %s",
        server_name,
        len(tools_response.tools),
        [t.name for t in tools_response.tools],
    )


async def close_mcp_connections() -> None:
    global _MCP_CONNECTED, _MCP_CLEANUP_TASKS
    for name, session, _transport_ctx in reversed(_MCP_CLEANUP_TASKS):
        try:
            await session.__aexit__(None, None, None)
        except BaseException:
            pass
        try:
            await _transport_ctx.__aexit__(None, None, None)
        except BaseException:
            pass
    _MCP_CONNECTED = False
    _MCP_SESSIONS.clear()
    _MCP_TOOLS_BY_SERVER.clear()
    _MCP_CLEANUP_TASKS.clear()


def get_mcp_tools_by_server() -> dict[str, dict[str, StructuredTool]]:
    return dict(_MCP_TOOLS_BY_SERVER)


def get_all_mcp_tools() -> dict[str, StructuredTool]:
    all_tools: dict[str, StructuredTool] = {}
    for server_tools in _MCP_TOOLS_BY_SERVER.values():
        all_tools.update(server_tools)
    return all_tools


def get_mcp_tool_owners() -> dict[str, str]:
    owners: dict[str, str] = {}
    for server_name, tools in _MCP_TOOLS_BY_SERVER.items():
        for tool_name in tools:
            owners[tool_name] = server_name
    return owners


def get_mcp_skill_prompt(skill_name: str) -> str:
    """Generate SKILL.md-like prompt for an MCP server."""
    meta = get_mcp_skill_metadata().get(skill_name)
    if not meta:
        return f"Unknown MCP skill: {skill_name}"

    tools = _MCP_TOOLS_BY_SERVER.get(skill_name, {})
    tool_descriptions = []
    for qualified_name, tool in tools.items():
        original_name = qualified_name.split("__", 2)[-1]
        tool_descriptions.append(f"- **{original_name}**: {tool.description}")

    return (
        "[Skill Context]\n"
        f"Skill: {skill_name}\n"
        f"Skill directory: {meta['directory']}\n"
        f"Description: {meta['description']}\n"
        f"MCP Command: {meta['command']} {meta.get('args', '')}\n\n"
        + ("## Available MCP Tools\n\n" + "\n".join(tool_descriptions)
           if tool_descriptions
           else "No tools discovered yet.")
    )


@dataclass(frozen=True)
class MCPSkill:
    name: str
    description: str
    directory: Path
    body: str
    metadata: dict[str, Any]

    @property
    def prompt(self) -> str:
        return (
            "[Skill Context]\n"
            f"Skill: {self.name}\n"
            f"Skill directory: {self.directory}\n"
            f"Description: {self.description}\n\n"
            f"{self.body}"
        )
