"""Structured runtime trace logging for prompts, LLM calls, and tool execution."""

from __future__ import annotations

import json
import logging
from datetime import datetime
from typing import Any

from app_code.runtime_paths import logs_root


def log_dir() -> Path:
    """Return today's log directory under runtime/logs."""

    today = datetime.now()
    path = logs_root() / str(today.year) / f"{today.month:02d}" / f"{today.day:02d}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def setup_file_logging(level: str = "INFO") -> Path:
    """Configure root logging to both stdout caller handlers and the daily log file."""

    return log_dir() / "agentic_log.log"


def raw_events_path() -> Path:
    return log_dir() / "raw_events.jsonl"


def _safe_json(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _safe_json(val) for key, val in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_safe_json(item) for item in value]
    if hasattr(value, "model_dump"):
        try:
            return _safe_json(value.model_dump())
        except Exception:
            pass
    if hasattr(value, "dict"):
        try:
            return _safe_json(value.dict())
        except Exception:
            pass
    if hasattr(value, "value"):
        return _safe_json(value.value)
    return repr(value)


def log_raw_event(event_type: str, session_id: str | None = None, **payload: Any) -> None:
    """Append a full-fidelity JSONL event for debugging and replay."""

    event = {
        "timestamp": datetime.now().isoformat(timespec="milliseconds"),
        "event_type": event_type,
        "session_id": session_id,
        **payload,
    }
    line = json.dumps(_safe_json(event), ensure_ascii=False, default=repr)
    try:
        with raw_events_path().open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")
    except Exception:
        logging.exception("[trace_logging] Failed to write raw event: %s", event_type)
