from enum import Enum
from typing import Any
from uuid import UUID

from langgraph.graph import MessagesState
from typing_extensions import NotRequired, TypedDict

from app_code.runtime_paths import load_runtime_env

load_runtime_env()


class StrEnum(str, Enum):
    """Python 3.10 compatible replacement for enum.StrEnum."""


class NodeNames(StrEnum):
    """Names used by the single-agent runtime state machine."""

    USER_INPUT = "user_input"
    JIRA_AGENT = "jira_agent"
    EMAIL_AGENT = "email_agent"
    CODE_AGENT = "code_agent"
    BDD_AGENT = "bdd_agent"
    ENV_AGENT = "env_agent"


class WorkflowState(TypedDict):
    """Graph state."""

    next_agent: NodeNames
    prev_agent: NodeNames
    caller_agent: NodeNames
    active_skill: NotRequired[str | None]
    task_plan_enabled: NotRequired[bool]
    error_counters: NotRequired[dict[str, int]]
    session_id: UUID
    pool: Any | None

    # --- Agent Memories ---
    email_agent: MessagesState
    jira_agent: MessagesState
    code_agent: MessagesState
    bdd_agent: MessagesState
    env_agent: MessagesState
    user_input: MessagesState
    activity_context: Any | None


# Definnig the workflow state by user
WORKFLOW_STATE_BY_USER: dict[str, WorkflowState] = {}


# Runtime state is stored by `skills_runtime.storage`.
# This placeholder keeps older app wiring simple without coupling runtime state to the BDD database.
GLOBAL_DB_POOL = None


class ToolNames(StrEnum):
    """Names of script actions exposed by skills."""

    HANDOFF_TO_USER = "handoff_to_user"
    LOAD_SKILL = "load_skill"
    ACTIVATE_SKILL = "activate_skill"

    # Gitlab/code agent specific tools
    CONNECT_TO_PROJECT = "connect_to_project"
    LIST_PROJECTS = "list_projects"
    LIST_BRANCHES = "list_branches"
    SELECT_PROJECT = "select_project"
    SELECT_BRANCH = "select_branch"
    CREATE_BRANCH = "create_branch"
    DELETE_BRANCH = "delete_branch"
    CREATE_MERGE_REQUEST = "create_merge_request"
    LIST_MERGE_REQUESTS = "list_merge_requests"
    LIST_FILES_IN_BRANCH = "list_files_in_branch"
    RETRIEVE_FILE_FULL_PATH = "retrieve_file_full_path"
    RETRIEVE_FILE_CONTENT = "retrieve_file_content"
    RECEIVE_FILE_AND_COMMIT = "receive_file_and_commit"
    MERGE_REQUEST = "merge_request"
    GET_MERGE_REQUESTS = "get_merge_requests"
    LAUNCH_PIPELINE = "launch_pipeline"
    LOAD_PROJECT_ONBOARDING_PROMPT = "load_project_onboarding_prompt"

    # Jira Tools
    GET_JIRA_ISSUE = "get_jira_issue"
    LIST_JIRA_ISSUES = "list_jira_issues"
    CREATE_JIRA_ISSUE = "create_jira_issue"
    UPDATE_JIRA_ISSUE_STATUS = "update_jira_issue_status"
    UPDATE_JIRA_ISSUE_FIELD = "update_jira_issue_field"
    ADD_JIRA_COMMENT = "add_jira_comment"
    SEARCH_JIRA_ISSUES = "search_jira_issues"
    DELETE_JIRA_ISSUE = "delete_jira_issue"

    # Email Tools
    SEND_EMAIL = "send_email"
    VERIFICATION_ASK = "verification_ask"

    # --- User and prompt memory actions ---
    EDIT_ONBOARDING_PROMPT = "edit_onboarding_prompt"
    SAVE_USER_FEEDBACK = "save_user_feedback"
    UPDATE_USER_FEEDBACK_SUMMARY = "update_user_feedback_summary"

    # --- BDD Agent Tools ---
    LIST_AVAILABLE_DATABASES = "list_available_databases"
    LIST_AVAILABLE_SCHEMAS = "list_available_schemas"
    LIST_AVAILABLE_TABLES = "list_available_tables"
    VERIFY_SQL_SYNTAX = "verify_sql_syntax"
    TEST_SQL_MODIFICATION_DRY_RUN = "test_sql_modification_dry_run"
    EXECUTE_SQL_MODIFICATION = "execute_sql_modification"
    GENERATE_SQL_SCRIPT = "generate_sql_script"
    GET_TABLE_STRUCTURE = "get_table_structure"
    EXECUTE_READ_QUERY = "execute_read_query"
    WRITE_SQL_FILE = "write_sql_file"
    READ_SQL_FILE = "read_sql_file"

    # --- ENV Agent Tools ---
    READ_FILE = "read_file"
    WRITE_FILE = "write_file"
    SEARCH_FILES = "search_files"
    EDIT_FILE = "edit_file"
    EXECUTE_SCRIPT = "execute_script"
    READ_LOGS = "read_logs"
    INSTALL_DEPENDENCIES = "install_dependencies"
    RUN_TESTS = "run_tests"
    LINT_CODE = "lint_code"
    RUN_COMMAND = "run_command"
    EXECUTE_CLI_COMMAND = "execute_cli_command"
    GREP_SEARCH = "grep_search"
    MODIFY_CODE_SCRIPT = "modify_code_script"
    GET_DB_CONNECTION_INFO = "get_db_connection_info"
    LIST_DRAFT_FILES = "list_draft_files"
    DELETE_CURRENT_SESSION_FILE = "delete_current_session_file"
    CLEANUP_OLD_DRAFT_FILES = "cleanup_old_draft_files"
    GET_DRAFT_FILE_FOR_COMMIT = "get_draft_file_for_commit"
