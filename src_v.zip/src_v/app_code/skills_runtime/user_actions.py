"""User-facing actions for the single-agent skill runtime."""

import logging
from typing import Annotated

from langchain_core.tools import InjectedToolArg, tool

from app_code.skills_runtime.storage import (
    get_prompt_value,
    get_user_feedbacks,
    save_prompt_value,
    save_user_feedback_func,
    save_user_value,
)
from app_code.skills_runtime.structs import NodeNames, ToolNames, WorkflowState


def _logging_action_error():
    logging.exception("[user_action] An error occurred:")
    return "Technical Error", {"next_agent": NodeNames.CODE_AGENT}


@tool(
    ToolNames.HANDOFF_TO_USER,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def handoff_to_user(user_prompt: str) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Respond to the user or ask a free-form follow-up question.

    Use this action only when the task is complete, blocked by missing information, or requires
    a human decision that cannot be inferred from the current request and loaded skill context.
    If the user has already explicitly authorized a concrete operation, continue with the relevant
    skill action instead of asking for another confirmation.

    Args:
        user_prompt (str): The prompt to send to the user.

    Returns:
        str: a message indicating the status of the handoff to the user.
    """
    logging.info(f"[handoff_to_user] Asking user: {user_prompt[:100]}...")

    return f"Successfully handed off control to {NodeNames.USER_INPUT}", {
        "next_agent": NodeNames.USER_INPUT,
        "context": user_prompt,
    }


@tool(
    ToolNames.EDIT_ONBOARDING_PROMPT,
    parse_docstring=True,
    response_format="content_and_artifact",
)
async def edit_onboarding_prompt(
    new_onboarding_rules: str,
    new_onboarding_prompt: str,
    state: Annotated[dict, InjectedToolArg],
):
    """
    You are in an onboarding phase where your behavior can be improved over time.

    This action updates the dynamic onboarding prompt used by the single runtime
    by adding or refining rules, preferences, or behavioral instructions.

    The rules can come from:
    1. An expert user providing explicit guidance (e.g., conventions, behavior patterns, etc.)
    2. Your own reasoning, when you identify a reusable pattern that improves
    efficiency, consistency, or decision-making across multiple tasks.

    Use this tool ONLY when the rule is:
    - general and reusable across multiple tasks (e.g., conventions, process standards).
    - not specific to a single request or temporary decision.
    - improving how the runtime behaves (not what it answers)
    - The user may not use the words like (e.g., "always follow", "ensure that") but the context
    may mean that the rule is meant to be a general instruction. Use your judgement to identify
    reusable rules even if they are not explicitly presented as such.


    Examples of valid rules:
    - "Use the terminal skill for Python execution tasks."
    - "Use the bdd skill for SQL queries."
    - "Always read README.md before modifying files."
    - "Prefer modifying a file before creating a feature branch."

    Do NOT use this tool for:
    - executing a task
    - switching runtime architecture
    - storing temporary context
    - storing one-time decisions
    - repeating information already present in the prompt

    Guidelines when creating rules:
    - Rewrite the rules to be clear, concise, and generic.
    - Avoid duplicates or contradictions with existing rules.
    - Prefer short and actionable instructions.
    - Focus on improving long-term behavior.
    - Do not require strict formatting (e.g., it’s okay if the rule is written in a more
    descriptive or conversational tone, as long as it conveys a reusable pattern).

    Important:
    - Do NOT overuse this tool
    - Only store rules that bring real long-term value
    - If unsure, do not store the rule

    This tool updates the long-term behavior of the current environment.

    Args:
        new_onboarding_rules (str): new rules to add
        new_onboarding_prompt (str): modifiyed onboarding prompt to save
        state: the workflow state.

    Returns:
        str: The full modified dynamic prompt content saved with no extra explanations or comments.
    """

    old_onboarding_prompt = await get_prompt_value(state, "prompts", "onboarding_current")
    logging.info(f"[tool: edit_onboarding_prompt] Old onboarding prompt:\n {old_onboarding_prompt}")
    logging.info(f"[tool: edit_onboarding_prompt] New onboarding rules:\n {new_onboarding_rules}")
    logging.info(f"[tool: edit_onboarding_prompt] New onboarding prompt:\n {new_onboarding_prompt}")

    try:
        await save_prompt_value(state, "prompts", "onboarding_current", new_onboarding_prompt)

        return f"Successfully saved onboarding prompt for runtime {state['next_agent'].value}", {
            "next_agent": NodeNames.CODE_AGENT,
            "context": new_onboarding_prompt,
        }
    except Exception:
        return _logging_action_error()


@tool(
    ToolNames.SAVE_USER_FEEDBACK,
    parse_docstring=True,
    response_format="content_and_artifact",
)
async def save_user_feedback(
    feedback: str,
    state: Annotated[dict, InjectedToolArg],
):
    """
    This tool allows you to store user-specific preferences or instructions
    that should persist across conversations.

    These preferences are tied to a specific user and will be automatically
    injected into future prompts to personalize your behavior.

    call the tool update_user_feedback_summary right after saving new feedback to
    ensure the feedback summary is up to date.

    Use this tool when the user expresses:
    - a language preference (e.g., "I prefer French")
    - coding style preferences (e.g., formatting rules, tools like ruff, etc.)
    - response style preferences (e.g., concise, detailed)
    - personal conventions or habits

    Examples:
    - "I prefer speaking in French"
    - "I use ruff with a line length of 120 for Python formatting"
    - "I prefer short and direct answers"

    Do NOT use this tool for:
    - temporary requests
    - one-time instructions
    - general rules that apply to all users

    Important constraints:
    - The stored feedback MUST be concise and under 200 characters
    - Rewrite the feedback to be clear and reusable
    - Avoid duplicates or redundant information

    When using this tool:
    - extract the user's preference
    - rewrite it clearly
    - store it for future interactions

    This helps personalize your responses for each user.

    Args:
        feedback: user-specific preferences or instructions
        state: the workflow state.

    Returns:
        User feedbacks extracted from the database.
    """
    logging.info(f"[tool: save_user_feedback] saving user feedback: {feedback}")

    try:
        await save_user_feedback_func(state, feedback)
        user_feedbacks = await get_user_feedbacks(state)
        return "Successfully saved feedback to database", {
            "next_agent": NodeNames.CODE_AGENT,
            "context": str(user_feedbacks),
        }
    except Exception:
        return _logging_action_error()


@tool(
    ToolNames.UPDATE_USER_FEEDBACK_SUMMARY,
    parse_docstring=True,
    response_format="content_and_artifact",
)
async def update_user_feedback_summary(
    user_feedbacks: str,
    updated_summary: str,
    state: Annotated[dict, InjectedToolArg],
):
    """
    This tool allows you to update the summary of user feedback stored in the database.

    Use this tool to keep an updated summary of user feedback that can be injected into prompts
    to personalize your behavior based on user preferences.

    This tool should be used right after saving new user feedback to ensure the feedback summary
    reflects the latest user preferences.

    Args:
        user_feedbacks: the string of user feedbacks to summarize.
        updated_summary: the new summary of user feedback to save.
        state: the workflow state.

    Returns:
        str: Updated feedback summary with no extra explanations or comments.
    """
    # TODO: add to prompt des regles raisonable qui n'impact pas la securité du system
    logging.info(
        "[tool: update_user_feedback_summary] Updating user feedback summary from this list ...\n"
        f"{user_feedbacks}"
    )

    try:
        await save_user_value(state, "feedback_summary", "summary", updated_summary)
        return "Successfully updated user feedback summary", {
            "next_agent": NodeNames.CODE_AGENT,
            "context": "",
        }
    except Exception:
        return _logging_action_error()
