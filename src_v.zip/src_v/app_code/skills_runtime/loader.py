"""Utilities for loading local skill packages."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from importlib import import_module
from pathlib import Path
from typing import Any, Callable

from langchain_core.tools.base import BaseTool

from app_code.runtime_paths import load_runtime_env, mcp_root

load_runtime_env()

from app_code.skills_runtime.mcp_loader import (
    get_mcp_skill_metadata,
    get_mcp_skill_prompt,
    get_mcp_tools_by_server,
    get_mcp_tool_owners,
    is_mcp_skill,
    list_mcp_skill_names,
)


@dataclass(frozen=True)
class Skill:
    """Loaded skill metadata and prompt text."""

    name: str
    description: str
    directory: Path
    body: str
    metadata: dict[str, Any]

    @property
    def prompt(self) -> str:
        return (
            "[Skill Context]\n"
            f"Skill: {self.name}\n"
            f"Skill directory: {self.directory}\n"
            f"Description: {self.description}\n\n"
            f"{self.body}"
        )


def skills_root() -> Path:
    """Return the configured skills root."""

    configured = os.getenv("PATH_SKILLS_DIR")
    if configured:
        return Path(configured)
    return Path(__file__).resolve().parents[1] / "skills"


def _split_skill_list(raw_value: str) -> set[str]:
    normalized_items = raw_value.replace("\n", ",").replace(";", ",").split(",")
    return {
        item.strip().lower().replace("_", "-")
        for item in normalized_items
        if item.strip()
    }


def enabled_skill_names() -> set[str] | None:
    """Return configured skill allowlist.

    Skills are plugin-like and must be explicitly enabled. A missing or empty ENABLED_SKILLS value
    means no filesystem skill is available to the runtime.
    """

    raw_value = os.getenv("ENABLED_SKILLS")
    if raw_value is None:
        return set()
    names = _split_skill_list(raw_value)
    return names if names else set()


def is_skill_enabled(skill_name: str) -> bool:
    """Return whether a skill package is allowed to load in this runtime."""

    normalized = skill_name.strip().lower().replace("_", "-")
    if is_mcp_skill(normalized):
        return True
    allowlist = enabled_skill_names()
    return normalized in allowlist


def list_skills() -> list[Skill]:
    """Load all valid local skills, including MCP pseudo-skills."""

    root = skills_root()
    skills: list[Skill] = []
    if root.exists():
        for path in sorted(root.iterdir()):
            if (path / "SKILL.md").exists() and is_skill_enabled(path.name):
                skills.append(load_skill(path.name))

    for mcp_skill_name in list_mcp_skill_names():
        meta = get_mcp_skill_metadata().get(mcp_skill_name, {})
        skills.append(
            Skill(
                name=mcp_skill_name,
                description=meta.get("description", f"MCP server: {mcp_skill_name}"),
                directory=meta.get("directory", mcp_root()),
                body=meta.get("body", f"MCP server providing external tools."),
                metadata={"kind": "mcp", **meta},
            )
        )

    return skills


def list_skill_names() -> tuple[str, ...]:
    """Return available skill package names."""

    return tuple(skill.name for skill in list_skills())


def resolve_skill_name(skill_name: str) -> str | None:
    """Resolve a skill package name to an enabled skill name."""

    normalized = skill_name.strip().lower().replace("_", "-")
    available = set(list_skill_names())
    if normalized in available:
        return normalized
    return None


def action_name(action_key: Any, action_value: Any = None) -> str:
    """Normalize a skill action registry key to the LangChain tool name."""

    if hasattr(action_key, "value"):
        return str(action_key.value)
    if isinstance(action_key, str):
        return action_key
    if action_value is not None and hasattr(action_value, "name"):
        return str(action_value.name)
    return str(action_key)


def load_skill_actions(skill_name: str) -> dict[str, BaseTool | Callable]:
    """Load a skill's callable actions from `<skill>/scripts/actions.py` or MCP."""

    resolved_name = skill_name.strip().lower().replace("_", "-")

    if is_mcp_skill(resolved_name):
        mcp_tools = get_mcp_tools_by_server()
        return dict(mcp_tools.get(resolved_name, {}))

    if not is_skill_enabled(resolved_name):
        return {}

    skill_dir = skills_root() / resolved_name
    actions_file = skill_dir / "scripts" / "actions.py"
    if not actions_file.exists():
        return {}

    root_parent = skills_root().parent.parent
    root_parent_str = str(root_parent)
    if root_parent_str not in sys.path:
        sys.path.insert(0, root_parent_str)

    module = import_module(f"app_code.skills.{resolved_name}.scripts.actions")
    raw_actions = dict(getattr(module, "skill_actions", {}))
    return {action_name(key, value): value for key, value in raw_actions.items()}


def load_all_skill_actions(skill_names: tuple[str, ...] | None = None) -> dict[str, BaseTool | Callable]:
    """Load and merge callable actions from all configured skills, including MCP."""

    if skill_names is None:
        skill_names = list_skill_names()
    merged_actions: dict[str, BaseTool | Callable] = {}
    for skill_name in skill_names:
        merged_actions.update(load_skill_actions(skill_name))
    return merged_actions


def load_skill_action_owners(skill_names: tuple[str, ...] | None = None) -> dict[str, str]:
    """Return the discovered owner skill for every loaded action, including MCP."""

    if skill_names is None:
        skill_names = list_skill_names()
    owners: dict[str, str] = {}

    for skill_name in skill_names:
        for name in load_skill_actions(skill_name):
            owners[name] = skill_name

    mcp_owners = get_mcp_tool_owners()
    owners.update(mcp_owners)

    return owners


def load_skill(skill_name: str) -> Skill:
    """Load a skill from `<skills_root>/<skill_name>/SKILL.md` or an MCP config."""

    resolved_name = skill_name.strip().lower().replace("_", "-")

    if is_mcp_skill(resolved_name):
        meta = get_mcp_skill_metadata().get(resolved_name, {})
        return Skill(
            name=resolved_name,
            description=meta.get("description", f"MCP server: {resolved_name}"),
            directory=meta.get("directory", mcp_root()),
            body=get_mcp_skill_prompt(resolved_name),
            metadata={"kind": "mcp", **meta},
        )

    if not is_skill_enabled(resolved_name):
        raise FileNotFoundError(f"Skill is not enabled: {skill_name}")

    skill_dir = skills_root() / resolved_name
    skill_file = skill_dir / "SKILL.md"
    if not skill_file.exists():
        raise FileNotFoundError(f"Skill file not found: {skill_file}")

    raw = skill_file.read_text(encoding="utf-8")
    metadata, body = _split_frontmatter(raw)
    instructions_file = metadata.get("instructions_file")
    if instructions_file:
        instructions_path = (skill_dir / str(instructions_file)).resolve()
        if not instructions_path.is_file():
            raise FileNotFoundError(
                f"Skill '{resolved_name}' references missing instructions file: {instructions_path}"
            )
        instructions = instructions_path.read_text(encoding="utf-8")
        body = f"{body.rstrip()}\n\n[Loaded Skill Instructions]\n{instructions}"

    return Skill(
        name=str(metadata.get("name") or resolved_name),
        description=str(metadata.get("description") or ""),
        directory=skill_dir,
        body=body.strip(),
        metadata=metadata,
    )


def _split_frontmatter(raw: str) -> tuple[dict[str, Any], str]:
    if not raw.startswith("---\n"):
        return {}, raw
    _, frontmatter, body = raw.split("---", 2)
    return _parse_simple_yaml(frontmatter), body.lstrip()


def _parse_simple_yaml(frontmatter: str) -> dict[str, Any]:
    """Parse the small YAML subset used by SKILL.md frontmatter."""

    result: dict[str, Any] = {}
    current_list_key: str | None = None
    for line in frontmatter.splitlines():
        if not line.strip():
            continue
        if line.startswith("  - ") and current_list_key:
            result[current_list_key].append(line[4:].strip().strip("\"'"))
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip()
        if value == "[]":
            result[key] = []
            current_list_key = None
        elif value:
            result[key] = value.strip("\"'")
            current_list_key = None
        else:
            result[key] = []
            current_list_key = key
    return result
