"""Runtime services available to skill actions."""

from __future__ import annotations

import logging
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from app_code.https_config import openai_http_client_kwargs
from app_code.llm_protocol import llm_tools_mode
from app_code.skills_runtime.trace_logging import log_raw_event


def env_flag(name: str, default: str = "false") -> bool:
    import os

    return os.getenv(name, default).lower() in {"1", "true", "yes", "on"}


def emit_skill_status(
    state: dict | None,
    message: str,
    *,
    skill_name: str = "skill",
    kind: str = "agent_status",
    detail: dict[str, Any] | None = None,
) -> None:
    """Emit a browser status event from sync skill code when the runtime supports it."""

    if not state or not env_flag("ENABLE_SKILL_RUNTIME_NOTIFICATIONS", "true"):
        return
    context = state.get("activity_context")
    if not context:
        return
    content = f"[skill:{skill_name}] {message}"
    try:
        if hasattr(context, "send_progress_event_sync"):
            context.send_progress_event_sync(content, kind=kind, detail=detail)
        elif hasattr(context, "send_progress_event"):
            logging.debug("Activity context has no sync status bridge; skipping status: %s", content)
    except Exception:
        logging.exception("Failed to emit skill status")


def _skill_llm_request_messages(messages: list) -> list:
    if llm_tools_mode() != "json":
        return messages
    normalized = []
    for message in messages:
        if isinstance(message, dict):
            if message.get("content") is None:
                copy = dict(message)
                copy["content"] = ""
                normalized.append(copy)
            else:
                normalized.append(message)
            continue
        if getattr(message, "content", "") is None:
            if hasattr(message, "model_copy"):
                normalized.append(message.model_copy(update={"content": ""}))
            else:
                message.content = ""
                normalized.append(message)
            continue
        normalized.append(message)
    return normalized


def call_skill_llm(
    *,
    system_prompt: str,
    user_prompt: str,
    session_id: str | None,
    skill_name: str,
    purpose: str,
) -> str:
    """Call the runtime OpenAI-compatible LLM and log raw request/response data."""

    messages = _skill_llm_request_messages([
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt),
    ])
    log_raw_event(
        "skill_llm_request",
        session_id,
        skill=skill_name,
        purpose=purpose,
        llm_tools_mode=llm_tools_mode(),
        native_tools_payload=False,
        messages=messages,
    )
    import os

    base_url = (
        os.getenv("CUSTOMCONNSTR_OPENAI_BASE_URL")
        or os.getenv("OPENAI_BASE_URL")
        or os.getenv("OPENAI_ENDPOINT")
        or os.getenv("AZURE_OPENAI_ENDPOINT")
        or ""
    ).strip().rstrip("/")
    for suffix in ("/chat/completions", "/responses"):
        if base_url.endswith(suffix):
            base_url = base_url[: -len(suffix)]
    api_key = (
        os.getenv("CUSTOMCONNSTR_OPENAI_API_KEY")
        or os.getenv("OPENAI_API_KEY")
        or os.getenv("AZURE_OPENAI_API_KEY")
        or ""
    )
    model = os.getenv("OPENAI_MODEL") or os.getenv("AZURE_OPENAI_MODEL") or ""
    llm = ChatOpenAI(
        model=model,
        api_key=api_key,
        base_url=base_url,
        temperature=0,
        **openai_http_client_kwargs(),
    )
    response = llm.invoke(messages)
    log_raw_event(
        "skill_llm_response",
        session_id,
        skill=skill_name,
        purpose=purpose,
        response=response,
    )
    return str(response.content or "")
