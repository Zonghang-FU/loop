"""Single skill runtime node."""

from langchain_core.language_models import BaseChatModel

from app_code.skills_runtime.loader import load_all_skill_actions, load_skill_action_owners
from app_code.skills_runtime.node import build_skill_node


def get_skill_runtime_node(
    llm: BaseChatModel,
    skill_actions: dict | None = None,
    skill_action_owners: dict[str, str] | None = None,
):
    """Build the single runtime node from callable actions embedded in skill packages."""

    return build_skill_node(
        llm,
        skill_actions or load_all_skill_actions(),
        skill_action_owners or load_skill_action_owners(),
    )
