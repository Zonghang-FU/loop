"""Common LangGraph node factory for skill-backed nodes."""

from __future__ import annotations

import json
import logging
import os
from collections.abc import Callable

from langchain_core.language_models import BaseChatModel
from langchain_core.tools.base import BaseTool
from langgraph.types import Command

from app_code.skills_runtime.agent_loop import agent_node
from app_code.skills_runtime.skill_actions import load_skill
from app_code.skills_runtime.user_actions import (
    edit_onboarding_prompt,
    save_user_feedback,
    update_user_feedback_summary,
)
from app_code.skills_runtime.storage import compose_prompt, retrieve_llm_messages
from app_code.skills_runtime.structs import NodeNames, ToolNames, WorkflowState
from app_code.skills_runtime.mcp_loader import (
    ensure_mcp_connected,
    get_all_mcp_tools,
    get_mcp_tool_owners,
)
from app_code.llm_protocol import llm_tools_mode, use_native_llm_tools


def _actions_for_state(
    state: WorkflowState,
    all_actions: dict[str, BaseTool | Callable],
    action_owners: dict[str, str],
) -> tuple[dict[str, BaseTool | Callable], dict[str, str]]:
    """Return the action set visible for the current progressive-disclosure level."""

    active_skill = state.get("active_skill")
    visible_actions: dict[str, BaseTool | Callable] = {
        ToolNames.LOAD_SKILL.value: all_actions[ToolNames.LOAD_SKILL.value]
    }
    visible_owners: dict[str, str] = {ToolNames.LOAD_SKILL.value: "system"}

    if os.getenv("ENABLE_PROMPT_O_AGENT_TOOL", "False").lower() == "true":
        visible_actions[ToolNames.EDIT_ONBOARDING_PROMPT.value] = all_actions[
            ToolNames.EDIT_ONBOARDING_PROMPT.value
        ]
        visible_owners[ToolNames.EDIT_ONBOARDING_PROMPT.value] = "system"

    if os.getenv("USER_FEEDBACK", "False").lower() == "true":
        for name in (ToolNames.SAVE_USER_FEEDBACK.value, ToolNames.UPDATE_USER_FEEDBACK_SUMMARY.value):
            visible_actions[name] = all_actions[name]
            visible_owners[name] = "system"

    if not active_skill:
        return visible_actions, visible_owners

    active_action_names = [
        name for name, owner in action_owners.items() if owner == active_skill and name in all_actions
    ]
    for name in active_action_names:
        visible_actions[name] = all_actions[name]
        visible_owners[name] = active_skill

    # Official filesystem skills often ship only SKILL.md + scripts/resources. In that case the
    # terminal skill, when enabled, acts as the execution substrate for bundled scripts and files.
    if not active_action_names:
        for name, owner in action_owners.items():
            if owner == "terminal" and name in all_actions:
                visible_actions[name] = all_actions[name]
                visible_owners[name] = "terminal"

    return visible_actions, visible_owners


def _tool_schema_for_prompt(tool: BaseTool | Callable) -> dict:
    name = getattr(tool, "name", None) or getattr(tool, "__name__", str(tool))
    description = getattr(tool, "description", "") or ""
    parameters: dict = {}
    args_schema = getattr(tool, "args_schema", None)
    if args_schema is not None and hasattr(args_schema, "model_json_schema"):
        schema = args_schema.model_json_schema()
        parameters = {
            "properties": schema.get("properties", {}),
            "required": schema.get("required", []),
        }
    elif hasattr(tool, "args"):
        parameters = {"properties": getattr(tool, "args", {})}

    return {
        "name": str(name),
        "description": str(description)[:700],
        "parameters": parameters,
    }


def _json_tool_protocol_prompt(
    visible_actions: dict[str, BaseTool | Callable],
    active_skill: str | None,
) -> str:
    tools = [_tool_schema_for_prompt(tool) for tool in visible_actions.values()]
    tools_json = json.dumps(tools, ensure_ascii=False, default=str)
    return (
        "\n\n[JSON LLM Protocol]\n"
        "The current LLM endpoint only supports normal chat completions. Native OpenAI "
        "`tools` / function-calling is disabled by configuration.\n"
        "You MUST respond with exactly one valid JSON object and no markdown fences.\n\n"
        "To call a tool, return:\n"
        '{"type":"tool_call","name":"tool_name","args":{"arg_name":"value"}}\n\n'
        "To answer the user directly, return:\n"
        '{"type":"final","content":"user-facing answer"}\n\n'
        "Use only one tool call per response. Use only the action names below.\n"
        f"Current active skill: {active_skill or 'system'}.\n"
        "If the requested skill is already active and no further tool action is needed, "
        "return a final JSON response instead of calling load_skill again.\n"
        f"Available actions:\n{tools_json}\n"
    )


def build_skill_node(
    llm: BaseChatModel,
    skill_actions: dict[str, BaseTool | Callable] | None = None,
    skill_action_owners: dict[str, str] | None = None,
):
    """Build a LangGraph node backed by the skill for `state["next_agent"]`."""

    node_actions = dict(skill_actions or {})
    node_actions[ToolNames.LOAD_SKILL.value] = load_skill
    node_action_owners = dict(skill_action_owners or {})
    node_action_owners[ToolNames.LOAD_SKILL.value] = "system"

    if os.getenv("ENABLE_PROMPT_O_AGENT_TOOL", "False").lower() == "true":
        node_actions[ToolNames.EDIT_ONBOARDING_PROMPT.value] = edit_onboarding_prompt

    if os.getenv("USER_FEEDBACK", "False").lower() == "true":
        node_actions[ToolNames.SAVE_USER_FEEDBACK.value] = save_user_feedback
        node_actions[ToolNames.UPDATE_USER_FEEDBACK_SUMMARY.value] = update_user_feedback_summary

    async def skill_node(state: WorkflowState) -> Command[NodeNames]:
        current_agent = state["next_agent"].value

        await ensure_mcp_connected()
        mcp_tools = get_all_mcp_tools()
        mcp_owners = get_mcp_tool_owners()
        for name, tool in mcp_tools.items():
            if name not in node_actions:
                node_actions[name] = tool
        for name, owner in mcp_owners.items():
            if name not in node_action_owners:
                node_action_owners[name] = owner

        visible_actions, visible_action_owners = _actions_for_state(
            state,
            node_actions,
            node_action_owners,
        )
        if use_native_llm_tools():
            tool_choice = os.getenv("OPENAI_TOOL_CHOICE", "auto")
            llm_for_runtime = llm.bind_tools(
                tools=list(visible_actions.values()),
                tool_choice=tool_choice,
            )
        else:
            logging.warning(
                "LLM_TOOLS_MODE=%s: native OpenAI tools are disabled; using JSON protocol.",
                llm_tools_mode(),
            )
            llm_for_runtime = llm

        system_prompt = await compose_prompt(state)
        if not use_native_llm_tools():
            system_prompt += _json_tool_protocol_prompt(
                visible_actions,
                str(state.get("active_skill") or "") or None,
            )

        state[current_agent] = await retrieve_llm_messages(
            state["pool"],
            state["session_id"],
            current_agent,
            system_prompt,
        )
        return await agent_node(
            state,
            llm_with_tools=llm_for_runtime,
            skill_actions_by_name=visible_actions,
            skill_action_owners=visible_action_owners,
        )

    return skill_node
