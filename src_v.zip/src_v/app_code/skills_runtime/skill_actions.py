"""Runtime-level actions for official-style skill loading."""

from langchain_core.tools import tool
from langchain_core.tools import InjectedToolArg
from typing import Annotated

from app_code.skills_runtime.loader import list_skill_names, load_skill as load_skill_package
from app_code.skills_runtime.loader import resolve_skill_name
from app_code.skills_runtime.storage import (
    load_project_onboarding_prompt as load_project_onboarding_prompt_value,
    save_prompt_value,
)
from app_code.skills_runtime.structs import NodeNames, ToolNames


@tool(
    ToolNames.LOAD_SKILL,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def load_skill(
    skill_name: str,
    context: str = "",
) -> tuple[str, dict[str, str | NodeNames]]:
    """Load an enabled skill's full SKILL.md instructions after metadata-level routing.

    Args:
        skill_name: Enabled skill name from the Level 1 metadata list.
        context: Optional task context to preserve after loading the skill.

    Returns:
        Loaded skill instructions and task context.
    """
    canonical_skill = resolve_skill_name(skill_name)
    if canonical_skill is None:
        supported = ", ".join(sorted(list_skill_names()))
        return "Unsupported skill.", {
            "next_agent": NodeNames.CODE_AGENT,
            "context": f"Unsupported skill '{skill_name}'. Supported skills: {supported}.",
        }

    skill = load_skill_package(canonical_skill)
    loaded_context = skill.prompt
    if context:
        loaded_context += f"\n\n[Task Context]\n{context}"
    return f"Loaded skill {canonical_skill}.", {
        "next_agent": NodeNames.CODE_AGENT,
        "caller_agent": NodeNames.CODE_AGENT,
        "active_skill": canonical_skill,
        "context": loaded_context,
    }


@tool(
    ToolNames.LOAD_PROJECT_ONBOARDING_PROMPT,
    parse_docstring=True,
    response_format="content_and_artifact",
)
async def load_project_onboarding_prompt(
    state: Annotated[dict, InjectedToolArg],
) -> tuple[str, dict[str, str | NodeNames]]:
    """Load the project onboarding prompt into runtime prompt state.

    This runtime action is deliberately not owned by the Git skill. It first reads the repository
    root onboarding file from the local project, then falls back to the selected GitLab project's
    root onboarding file only when local onboarding is absent.

    Args:
        state: Workflow state injected by the runtime.

    Returns:
        The loaded onboarding status and routing artifact.
    """
    onboarding_prompt = await load_project_onboarding_prompt_value(state)
    if not onboarding_prompt:
        return "Onboarding file not found.", {
            "next_agent": NodeNames.USER_INPUT,
            "context": (
                "I could not find root onboarding.md/onbording.md context. "
                "Please add it to the project root or provide the onboarding prompt directly."
            ),
        }
    await save_prompt_value(state, "prompts", "onboarding_current", onboarding_prompt)
    return "Loaded project onboarding prompt.", {
        "next_agent": NodeNames.CODE_AGENT,
        "context": "Loaded onboarding instructions into runtime prompt state.",
    }
