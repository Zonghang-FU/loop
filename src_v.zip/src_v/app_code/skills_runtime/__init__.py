"""Skill loading and skill-node helpers."""
