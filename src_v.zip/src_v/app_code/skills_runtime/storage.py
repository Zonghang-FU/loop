import asyncio
import base64
import json
import logging
import os
import re
import sqlite3
import subprocess
from collections import defaultdict
from pathlib import Path
from typing import Any, Optional
from uuid import UUID

import psycopg
import gitlab
from langchain_core.messages import (
    AIMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
    messages_from_dict,
    messages_to_dict,
)
from langchain_postgres import PostgresChatMessageHistory
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.graph import MessagesState
from psycopg_pool import AsyncConnectionPool

from app_code.skills_runtime.loader import (
    list_skills,
)
from app_code.skills_runtime.trace_logging import log_raw_event
from app_code.runtime_paths import (
    draft_root,
    load_runtime_env,
    onboarding_prompt_path,
    repo_root as project_repo_root,
    runtime_data_root,
)

load_runtime_env()

from app_code.skills.bdd.scripts import db_tools
from .structs import NodeNames, WorkflowState

AGENT_RUNTIME_STORAGE = os.getenv("AGENT_RUNTIME_STORAGE", "sqlite").strip().lower()
USE_IN_MEMORY_STORAGE = AGENT_RUNTIME_STORAGE == "memory" or (
    os.getenv("LOCAL_RUN_IN_MEMORY_STATE", "").lower()
    in {
        "1",
        "true",
        "yes",
        "on",
    }
)
USE_SQLITE_STORAGE = not USE_IN_MEMORY_STORAGE and AGENT_RUNTIME_STORAGE != "postgres"
_runtime_db_path = Path(
    os.getenv(
        "AGENT_RUNTIME_DB_PATH",
        str(runtime_data_root() / "agent_runtime.sqlite3"),
    )
)
if not _runtime_db_path.is_absolute():
    _runtime_db_path = project_repo_root() / _runtime_db_path
AGENT_RUNTIME_DB_PATH = _runtime_db_path

IN_MEMORY_AGENT_MESSAGES: dict[str, dict[str, list[Any]]] = defaultdict(lambda: defaultdict(list))
IN_MEMORY_USER_VALUES: dict[str, dict[str, dict[str, Any]]] = defaultdict(
    lambda: {
        "state_data": {"project_path": None, "branch_name": None},
        "feedback_summary": {"summary": None},
    }
)
IN_MEMORY_PROMPTS: dict[str, dict[str, Any]] = {
    "prompts": {
        "environment_specific": None,
        "onboarding_current": None,
        "onboarding_valide": None,
    }
}
IN_MEMORY_USER_FEEDBACKS: dict[str, list[tuple[int, str]]] = defaultdict(list)


def _sqlite_connect() -> sqlite3.Connection:
    AGENT_RUNTIME_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(AGENT_RUNTIME_DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _sqlite_init() -> None:
    with _sqlite_connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS agent_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                agent_name TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_agent_messages_session_agent_id
                ON agent_messages (session_id, agent_name, id DESC);

            CREATE TABLE IF NOT EXISTS response_metadata (
                id TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                agent_name TEXT,
                input_tokens INTEGER,
                output_tokens INTEGER,
                total_tokens INTEGER,
                model_name TEXT,
                model TEXT,
                finish_reason TEXT
            );

            CREATE TABLE IF NOT EXISTS state_data (
                id TEXT PRIMARY KEY,
                project_path TEXT,
                branch_name TEXT
            );

            CREATE TABLE IF NOT EXISTS prompts (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                environment_specific TEXT,
                e_s_update TEXT,
                onboarding_current TEXT,
                o_c_update TEXT,
                onboarding_valide TEXT,
                o_v_update TEXT
            );

            CREATE TABLE IF NOT EXISTS user_feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                user_id TEXT,
                feedback TEXT
            );

            CREATE TABLE IF NOT EXISTS feedback_summary (
                id TEXT PRIMARY KEY,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                summary TEXT
            );
            INSERT OR IGNORE INTO prompts (id) VALUES (1);
            """
        )


def _message_to_json(message: HumanMessage | AIMessage | SystemMessage | ToolMessage) -> str:
    return json.dumps(messages_to_dict([message])[0], ensure_ascii=False, default=str)


def _message_from_json(raw: str) -> HumanMessage | AIMessage | SystemMessage | ToolMessage:
    return messages_from_dict([json.loads(raw)])[0]


def _sqlite_add_message(
    session_id: UUID | str,
    agent_name: Any,
    message: HumanMessage | AIMessage | SystemMessage | ToolMessage,
) -> None:
    _sqlite_init()
    with _sqlite_connect() as conn:
        conn.execute(
            """
            INSERT INTO agent_messages (session_id, agent_name, message)
            VALUES (?, ?, ?)
            """,
            (_session_key(session_id), _agent_key(agent_name), _message_to_json(message)),
        )


def _sqlite_get_messages(
    session_id: UUID | str, agent_name: Any, limit: int | None = None
) -> list[HumanMessage | AIMessage | SystemMessage | ToolMessage]:
    _sqlite_init()
    params: list[Any] = [_session_key(session_id), _agent_key(agent_name)]
    query = """
        SELECT message
        FROM agent_messages
        WHERE session_id = ? AND agent_name = ?
        ORDER BY id DESC
    """
    if limit:
        query += " LIMIT ?"
        params.append(limit)
    with _sqlite_connect() as conn:
        rows = conn.execute(query, params).fetchall()
    return [_message_from_json(row["message"]) for row in reversed(rows)]


def is_complex_task_request(message: str) -> bool:
    """Heuristic for enabling live checklist progress on multi-step tasks."""

    text = (message or "").lower()
    if len(text) > 180:
        return True
    markers = [
        "jira",
        "ticket",
        "gitlab",
        "merge request",
        "database",
        "sql",
        "script",
        "email",
        "test",
        "commit",
        "run",
    ]
    marker_count = sum(1 for marker in markers if marker in text)
    return marker_count >= 3 or bool(re.search(r"\b(and|then|after|ensuite|puis)\b", text))


def _session_key(session_id: UUID | str) -> str:
    return str(session_id)


def _agent_key(agent_name: Any) -> str:
    return getattr(agent_name, "value", str(agent_name))


def _infer_local_gitlab_project_path() -> str | None:
    try:
        repo_root = Path(__file__).resolve().parents[3]
        remote_url = subprocess.check_output(
            ["git", "-C", str(repo_root), "remote", "get-url", "origin"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        return None

    for marker in ("gitlab.com:", "gitlab.com/"):
        if marker in remote_url:
            project_path = remote_url.split(marker, 1)[1]
            if project_path.endswith(".git"):
                project_path = project_path[:-4]
            return project_path.strip("/") or None
    return None


def repo_root() -> Path:
    """Return the repository root for project-level skill resources."""

    return project_repo_root()


def root_onboarding_prompt_path() -> Path:
    """Return the canonical root Prompt O file path."""

    return onboarding_prompt_path()


def load_root_onboarding_prompt() -> str | None:
    """Load Prompt O from the runtime directory."""

    for path in (
        onboarding_prompt_path(),
        repo_root() / "onbording.md",
        repo_root() / "onboarding.md",
        repo_root() / "ONBOARDING.md",
    ):
        if path.is_file():
            content = path.read_text(encoding="utf-8").strip()
            return content or None
    return None


def save_root_onboarding_prompt(value: str) -> Path:
    """Persist Prompt O to the runtime onbording.md file used by app.py."""

    path = root_onboarding_prompt_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding="utf-8")
    return path


DOWNLOADABLE_ARTIFACT_SUFFIXES = {
    ".html",
    ".htm",
    ".ppt",
    ".pptx",
    ".doc",
    ".docx",
    ".xls",
    ".xlsx",
    ".csv",
}


def _session_draft_dir(session_id: str) -> Path:
    return draft_root() / str(session_id)


def list_session_downloadable_artifacts(session_id: str, since_ms: float = 0) -> list[dict[str, Any]]:
    """List recently generated downloadable artifacts in the session draft directory."""

    session_dir = _session_draft_dir(session_id).resolve()
    if not session_dir.exists():
        return []
    since_seconds = since_ms / 1000 if since_ms else 0
    artifacts: list[dict[str, Any]] = []
    for path in sorted(session_dir.rglob("*"), key=lambda item: item.stat().st_mtime, reverse=True):
        if not path.is_file() or path.suffix.lower() not in DOWNLOADABLE_ARTIFACT_SUFFIXES:
            continue
        stat = path.stat()
        if since_seconds and stat.st_mtime < since_seconds:
            continue
        relative = path.relative_to(session_dir).as_posix()
        artifacts.append(
            {
                "name": path.name,
                "path": relative,
                "size": stat.st_size,
                "mtime_ms": int(stat.st_mtime * 1000),
                "url": f"/api/web/artifact?session_id={session_id}&path={relative}",
            }
        )
    return artifacts


def session_artifact_path(session_id: str, relative_path: str) -> Path:
    """Resolve a downloadable artifact path scoped to the current session draft directory."""

    session_dir = _session_draft_dir(session_id).resolve()
    target = (session_dir / relative_path).resolve()
    try:
        target.relative_to(session_dir)
    except ValueError as exc:
        raise PermissionError("Artifact path escapes the session draft directory.") from exc
    if not target.is_file() or target.suffix.lower() not in DOWNLOADABLE_ARTIFACT_SUFFIXES:
        raise FileNotFoundError("Downloadable artifact not found.")
    return target


async def init_workflow_state(
    session_id: UUID,
    pool: AsyncConnectionPool | None,
    local: bool,
    activity_context: Any | None,
) -> WorkflowState:
    """Initialize the workflow state with default values."""
    state_base = {
        "session_id": session_id,
        "pool": pool,
        "email_agent": {"messages": []},
        "jira_agent": {"messages": []},
        "code_agent": {"messages": []},
        "bdd_agent": {"messages": []},
        "env_agent": {"messages": []},
        "user_input": {"messages": []},
        "error_counters": {agent: 0 for agent in NodeNames},
    }

    if local:
        state: WorkflowState = {
            **state_base,
            "next_agent": NodeNames.USER_INPUT,
            "prev_agent": NodeNames.USER_INPUT,
            "caller_agent": NodeNames.CODE_AGENT,
            "active_skill": None,
            "session_id": session_id,
            "pool": pool,
            "activity_context": activity_context,
        }

    else:
        state: WorkflowState = {
            **state_base,
            "next_agent": NodeNames.CODE_AGENT,
            "prev_agent": NodeNames.USER_INPUT,
            "caller_agent": NodeNames.USER_INPUT,
            "active_skill": None,
            "session_id": session_id,
            "pool": pool,
            "activity_context": activity_context,
        }
    if USE_IN_MEMORY_STORAGE:
        session_key = _session_key(session_id)
        _ = IN_MEMORY_AGENT_MESSAGES[session_key]
        user_values = IN_MEMORY_USER_VALUES[session_key]
        if not user_values["state_data"].get("project_path"):
            inferred_project = _infer_local_gitlab_project_path()
            if inferred_project:
                user_values["state_data"]["project_path"] = inferred_project
        return state
    if USE_SQLITE_STORAGE:
        _sqlite_init()
        session_key = _session_key(session_id)
        inferred_project = _infer_local_gitlab_project_path()
        with _sqlite_connect() as conn:
            conn.execute("INSERT OR IGNORE INTO state_data (id) VALUES (?)", (session_key,))
            conn.execute("INSERT OR IGNORE INTO feedback_summary (id) VALUES (?)", (session_key,))
            if inferred_project:
                conn.execute(
                    """
                    UPDATE state_data
                    SET project_path = COALESCE(project_path, ?)
                    WHERE id = ?
                    """,
                    (inferred_project, session_key),
                )
        return state
    try:
        async with pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    """
                    INSERT INTO state_data (id) VALUES (%s) ON CONFLICT (id) DO NOTHING;
                    """,
                    (session_id,),
                )
                await cur.execute(
                    """
                    INSERT INTO feedback_summary (id) VALUES (%s) ON CONFLICT (id) DO NOTHING;
                    """,
                    (session_id,),
                )
                await cur.execute(
                    """
                    DO $$
                    BEGIN
                        IF NOT EXISTS (SELECT 1 FROM prompts LIMIT 1) THEN
                            INSERT INTO prompts DEFAULT VALUES;
                        END IF;
                    END $$;
                    """
                )
    except Exception:
        logging.exception("[init_workflow_state] Inserting to DB error:\n")
    return state


def setup_postgres_saver(DB_URI: str) -> PostgresSaver:
    """
    This function setup the checkpointer by automaticaly creating its tables.
    It requires a sync connection so we pass DB_URI rather than 'pool'.
    """
    try:
        conn = psycopg.Connection.connect(
            DB_URI,
            autocommit=True,
            prepare_threshold=0,
        )
        checkpointer = PostgresSaver(conn)
        checkpointer.setup()
        return checkpointer
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[setup_postgres_saver] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[setup_postgres_saver] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[setup_postgres_saver] Error setting up PostgresSaver: {e}")
        raise


async def create_metadata_table(pool: AsyncConnectionPool) -> None:
    """This function is used to create the metadata table that store tokens-related informations."""
    try:
        async with pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    """
                        create table if not exists response_metadata (
                            id varchar,
                            created_at timestamptz NOT NULL DEFAULT NOW(),
                            agent_name varchar,
                            input_tokens integer,
                            output_tokens integer,
                            total_tokens integer,
                            model_name varchar,
                            model varchar,
                            finish_reason varchar
                        );
                        create table if not exists state_data (
                            id varchar PRIMARY KEY,
                            project_path varchar,
                            branch_name varchar
                        );
                        CREATE TABLE IF NOT EXISTS prompts (
                            id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                            environment_specific  VARCHAR,
                            e_s_update TIMESTAMPTZ,
                            onboarding_current VARCHAR,
                            o_c_update TIMESTAMPTZ,
                            onboarding_valide VARCHAR,
                            o_v_update TIMESTAMPTZ
                        );
                        CREATE TABLE IF NOT EXISTS user_feedback (
                            id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                            user_id VARCHAR,
                            feedback VARCHAR
                        );
                        CREATE TABLE IF NOT EXISTS feedback_summary (
                            id VARCHAR PRIMARY KEY,
                            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                            summary VARCHAR
                        );
                    """
                )
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[create_metadata_table] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[create_metadata_table] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[create_metadata_table]: {e}")
        raise


async def create_memory_tables(pool: AsyncConnectionPool, agent: str) -> None:
    """
    This function is used to create a memory table for a specific agent.
    It create the tables schemas (as in columns) automaticaly.
    """
    try:
        async with pool.connection() as conn:
            await PostgresChatMessageHistory.acreate_tables(conn, agent)
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[create_metadata_table] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[create_metadata_table] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[create_metadata_table]: {e}")
        raise


async def create_tables(pool: AsyncConnectionPool) -> None:
    """
    This function is called to create the tables in parallel.
    This function create a tasks list of coroutine functions to be executed in parallel.
    Each function in the list creates its own connection from the pool.
    Each function in the list creates a table for a specific agent.
    """
    if USE_SQLITE_STORAGE:
        _sqlite_init()
        logging.info("[create_tables] SQLite runtime tables are ready at %s", AGENT_RUNTIME_DB_PATH)
        return
    try:
        agents = [node.value for node in NodeNames]
        tasks = [create_memory_tables(pool, agent) for agent in agents] + [
            create_metadata_table(pool)
        ]
        await asyncio.gather(*tasks)
        logging.info("[create_tables] Successfuly creating memory tables")
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[create_tables] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[create_tables] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[create_tables]: {e}")
        raise


async def create_composite_index(pool: AsyncConnectionPool, agent: str) -> None:
    """
    This function create a composite index for a specific agent table.
    It uses the 'id' and 'session_id' columns for the index.
    This composite index is base on the 'where session_id' and 'order by id'
    clauses used to retrieve the messages.
    """
    try:
        async with pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"create index if not exists idx_{agent}_session_id__id_desc "
                    f"ON public.{agent} (session_id, id DESC);"
                )
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[create_composite_index] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[create_composite_index] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[create_composite_index] Error creating index for table {agent}: {e}")
        raise


async def create_index(pool: AsyncConnectionPool) -> None:
    """This function creates the index for tables in parallel."""
    if USE_SQLITE_STORAGE:
        _sqlite_init()
        return
    try:
        agents = [node.value for node in NodeNames]
        tasks = [create_composite_index(pool, agent) for agent in agents]
        await asyncio.gather(*tasks)
        logging.info("Successfuly creating tables index")
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[create_index] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[create_index] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[create_index]: {e}")
        raise


def deserialize_message(
    msg_dict: dict[str, Any],
) -> HumanMessage | AIMessage | SystemMessage | ToolMessage:
    """
    This function converts LangGraph internal messages dict to a real LangChain Message object.
    The messages are loaded from the PostgreSQL DB.
    """
    try:
        data = msg_dict.get("data", {})
        msg_type = data.get("type") or msg_dict.get("type")
        content = data.get("content", "")
        if msg_type == "human":
            return HumanMessage(content=content)
        elif msg_type == "ai":
            return AIMessage(content=content, tool_calls=data.get("tool_calls", []))
        elif msg_type == "system":
            return SystemMessage(content=content)
        elif msg_type == "tool":
            return ToolMessage(content=content, tool_call_id=data.get("tool_call_id"))
        else:
            raise ValueError(f"Unknown message type: {msg_type}")
    except Exception as e:
        logging.error(f"[deserialize_message]: {e}")
        raise


async def retrieve_llm_messages(
    pool: AsyncConnectionPool | None, session_id: str, current_agent: str, system_prompt: str
) -> MessagesState:
    """
    This function retrieves the messages from the specific agent table.
    It is called each time right before invoking the LLM.
    It also appends the System Message (as first message) of the specified agent dynamically.
    """
    if USE_IN_MEMORY_STORAGE:
        rows = list(IN_MEMORY_AGENT_MESSAGES[_session_key(session_id)].get(_agent_key(current_agent), []))
        if current_agent == NodeNames.USER_INPUT.value:
            return MessagesState(messages=rows)
        while rows and isinstance(rows[0], ToolMessage):
            rows.pop(0)
        messages = [SystemMessage(content=system_prompt)]
        messages.extend(rows)
        return MessagesState(messages=messages)
    if USE_SQLITE_STORAGE:
        rows = _sqlite_get_messages(session_id, current_agent, int(os.getenv("MESSAGES_LIMIT", 10)))
        if current_agent == NodeNames.USER_INPUT.value:
            return MessagesState(messages=rows)
        while rows and isinstance(rows[0], ToolMessage):
            rows.pop(0)
        messages = [SystemMessage(content=system_prompt)]
        messages.extend(rows)
        return MessagesState(messages=messages)
    try:
        messages_limit = int(os.getenv("MESSAGES_LIMIT", 10))
        async with pool.connection() as conn:
            async with conn.cursor() as cur:
                # TODO: perform summaries of messages and store those in aiven
                # instead of truncating list of messages.
                await cur.execute(
                    f"""
                    SELECT message
                    FROM (
                        SELECT message, id
                        FROM {current_agent}
                        WHERE session_id = '{session_id}'
                        ORDER BY id DESC
                        LIMIT {messages_limit}
                    ) AS last_15_rows
                    ORDER BY id ASC;
                """
                )
                rows = await cur.fetchall()
                rows = [row[0] for row in rows]
                rows = [deserialize_message(m) for m in rows]
        if current_agent == NodeNames.USER_INPUT.value:
            return MessagesState(messages=rows)
        else:
            while rows and isinstance(rows[0], ToolMessage):
                rows.pop(0)
            messages = [SystemMessage(content=system_prompt)]
            messages.extend(rows)
            return MessagesState(messages=messages)
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[retrieve_llm_messages] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[retrieve_llm_messages] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[retrieve_llm_messages] error with the agent {current_agent}: {repr(e)}")
        raise


async def save_prompt_value(state, table: str, col: str, value: str):
    """This function is used to save a prompt value to DB"""
    logging.info(f"[save_prompt_value] Table *{table}* _ Col *{col}* _ Value: {value}")
    allowed_cols = {
        "environment_specific",
        "onboarding_current",
        "onboarding_valide",
    }
    timestamp_map = {
        "environment_specific": "e_s_update",
        "onboarding_current": "o_c_update",
        "onboarding_valide": "o_v_update",
    }
    ts_col = timestamp_map[col]
    if col not in allowed_cols:
        logging.exception(f"[save_prompt_value] Invalid column name: *{col}*")
        raise ValueError(f"[save_prompt_value] Invalid column name: *{col}*")
    if USE_IN_MEMORY_STORAGE:
        IN_MEMORY_PROMPTS.setdefault(table, {})[col] = value
        return
    if USE_SQLITE_STORAGE:
        _sqlite_init()
        with _sqlite_connect() as conn:
            conn.execute(
                f"UPDATE prompts SET {col} = ?, {ts_col} = CURRENT_TIMESTAMP WHERE id = 1",
                (value,),
            )
        return
    try:
        async with state["pool"].connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"""
                        UPDATE {table}
                        SET {col} = %s,
                            {ts_col} = NOW()
                    """,
                    (value,),
                )
    except Exception:
        logging.exception("[Func: save_prompt_value] An error occurred:\n")
        raise


async def get_prompt_value(state, table, col):
    """This function is used to get prmpt value from DB"""
    logging.info(f"[get_prompt_value] Table *{table}* _ Col *{col}*")
    allowed_cols = {
        "environment_specific",
        "onboarding_current",
    }
    if col not in allowed_cols:
        logging.exception(f"[get_prompt_value] Invalid column name: *{col}*")
        raise ValueError(f"[get_prompt_value] Invalid column name: *{col}*")
    if USE_IN_MEMORY_STORAGE:
        return IN_MEMORY_PROMPTS.get(table, {}).get(col)
    if USE_SQLITE_STORAGE:
        _sqlite_init()
        with _sqlite_connect() as conn:
            row = conn.execute(f"SELECT {col} FROM prompts WHERE id = 1").fetchone()
        return row[col] if row else None
    try:
        async with state["pool"].connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"""
                        SELECT {col}
                        FROM {table}
                        WHERE id = 1;
                    """,
                )
                row = await cur.fetchone()
                return row[0] if row else None
    except Exception:
        logging.exception("[Func: get_prompt_value] An error occurred:\n")
        raise


async def load_project_onboarding_prompt(state: WorkflowState) -> str | None:
    """
    Load onboarding instructions from the current GitLab project's root onboarding file.

    The project file is the source of truth. The database prompt remains a fallback/cache for
    projects that do not expose an onboarding file yet.
    """
    root_prompt = load_root_onboarding_prompt()
    if root_prompt is not None:
        return root_prompt

    project_path = await get_user_value(state, "state_data", "project_path")
    if not project_path:
        logging.info("[load_project_onboarding_prompt] No project selected.")
        return None

    token = os.getenv("CUSTOMCONNSTR_GITLAB_JAP", os.getenv("GITLAB_JAP", ""))
    if not token:
        logging.warning("[load_project_onboarding_prompt] Missing GitLab token.")
        return None

    try:
        gl = gitlab.Gitlab(private_token=token)
        project = gl.projects.get(project_path)
        ref = await get_user_value(state, "state_data", "branch_name")
        ref = ref or getattr(project, "default_branch", None)
        if not ref:
            logging.warning("[load_project_onboarding_prompt] No branch/default branch found.")
            return None

        for filename in ("onboarding.md", "onbording.md", "ONBOARDING.md"):
            try:
                project_file = project.files.get(file_path=filename, ref=ref)
            except gitlab.exceptions.GitlabGetError as exc:
                if getattr(exc, "response_code", None) == 404:
                    continue
                raise

            content = project_file.content
            if isinstance(content, str):
                return base64.b64decode(content).decode("utf-8")
            return base64.b64decode(content).decode("utf-8")
    except Exception:
        logging.exception("[load_project_onboarding_prompt] Failed to load onboarding file.")
        return None
    return None


async def save_user_feedback_func(state, summary):
    """This function is used to save user feedback to DB"""
    logging.info(
        f"[save_user_feedback_func] saving user ({state['session_id']}) feedback: {summary}"
    )
    if USE_IN_MEMORY_STORAGE:
        session_key = _session_key(state["session_id"])
        next_idx = len(IN_MEMORY_USER_FEEDBACKS[session_key]) + 1
        IN_MEMORY_USER_FEEDBACKS[session_key].append((next_idx, summary))
        return
    if USE_SQLITE_STORAGE:
        _sqlite_init()
        with _sqlite_connect() as conn:
            conn.execute(
                "INSERT INTO user_feedback (user_id, feedback) VALUES (?, ?)",
                (_session_key(state["session_id"]), summary),
            )
        return
    try:
        async with state["pool"].connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    """
                        INSERT INTO user_feedback (user_id, feedback)
                        VALUES (%s, %s);
                    """,
                    (state["session_id"], summary),
                )
    except Exception:
        logging.exception("[save_user_feedback_func] An error occurred:\n")
        raise


async def get_user_feedbacks(state: WorkflowState):
    """
    This function retrieves the user feedbacks

    Args:
        state: WorkflowState - the current workflow state.

    Returns:
        list of feedbacks for the current user.
    """
    logging.info(
        "[func: get_user_feedbacks] Getting feedbacks for user_id: %s", state["session_id"]
    )
    feedbacks_limit = int(os.getenv("FEEDBACKS_LIMIT", 15))
    if USE_IN_MEMORY_STORAGE:
        session_key = _session_key(state["session_id"])
        rows = IN_MEMORY_USER_FEEDBACKS[session_key][-feedbacks_limit:]
        return {idx: feedback for idx, feedback in rows}
    if USE_SQLITE_STORAGE:
        _sqlite_init()
        with _sqlite_connect() as conn:
            rows = conn.execute(
                """
                SELECT id, feedback
                FROM (
                    SELECT id, feedback
                    FROM user_feedback
                    WHERE user_id = ?
                    ORDER BY id DESC
                    LIMIT ?
                )
                ORDER BY id ASC
                """,
                (_session_key(state["session_id"]), feedbacks_limit),
            ).fetchall()
        return {row["id"]: row["feedback"] for row in rows}
    try:
        async with state["pool"].connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"""
                    SELECT id, feedback
                    FROM (
                        SELECT feedback, id
                        FROM user_feedback
                        WHERE user_id = '{state['session_id']}'
                        ORDER BY id DESC
                        LIMIT {feedbacks_limit}
                    ) AS last_15_rows
                    ORDER BY id ASC;
                """
                )
                rows = await cur.fetchall()
                rows = {row[0]: row[1] for row in rows}
                # rows = [row[0] for row in rows]
        return rows
    except Exception:
        logging.exception("[func: get_user_feedbacks] An error occurred:\n")
        raise


async def save_user_value(state, table: str, col: str, value: str):
    """This function is used to sve a state value to DB"""
    logging.info(
        f"[save_user_value] Saving user value - table: {table} - col: {col} - value: {value}"
    )
    allowed_cols = {"project_path", "branch_name", "summary"}
    if col not in allowed_cols:
        raise ValueError(f"[save_user_value] Invalid column name: *{col}*")
    if USE_IN_MEMORY_STORAGE:
        session_key = _session_key(state["session_id"])
        IN_MEMORY_USER_VALUES[session_key].setdefault(table, {})[col] = value
        return
    if USE_SQLITE_STORAGE:
        _sqlite_init()
        session_key = _session_key(state["session_id"])
        if table == "state_data":
            with _sqlite_connect() as conn:
                conn.execute("INSERT OR IGNORE INTO state_data (id) VALUES (?)", (session_key,))
                conn.execute(f"UPDATE state_data SET {col} = ? WHERE id = ?", (value, session_key))
            return
        if table == "feedback_summary":
            with _sqlite_connect() as conn:
                conn.execute(
                    "INSERT OR IGNORE INTO feedback_summary (id) VALUES (?)",
                    (session_key,),
                )
                conn.execute(
                    "UPDATE feedback_summary SET summary = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                    (value, session_key),
                )
            return
        raise ValueError(f"[save_user_value] Unsupported SQLite table: {table}")
    try:
        async with state["pool"].connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"""
                        UPDATE {table}
                        SET {col} = %s
                        WHERE id = %s;
                    """,
                    (value, state["session_id"]),
                )
    except Exception:
        logging.exception("[save_user_value] An error occurred:\n")
        raise


async def get_user_value(state: WorkflowState, table: str, col: str):
    """
    This function is used to get a value from DB for a specific table, user and column.

    Args:
        state: the current workflow state.
        table: the name of the table to query.
        col: the name of the column to retrieve.

    Returns:
        The value of the specified table and column for the current session_id.
    """
    allowed_cols = {"project_path", "branch_name", "summary"}
    if col not in allowed_cols:
        logging.exception(f"[get_user_value] Invalid column name: *{col}*")
        raise ValueError(f"[get_user_value] Invalid column name: *{col}*")
    if USE_IN_MEMORY_STORAGE:
        session_key = _session_key(state["session_id"])
        return IN_MEMORY_USER_VALUES[session_key].get(table, {}).get(col)
    if USE_SQLITE_STORAGE:
        _sqlite_init()
        session_key = _session_key(state["session_id"])
        if table not in {"state_data", "feedback_summary"}:
            raise ValueError(f"[get_user_value] Unsupported SQLite table: {table}")
        with _sqlite_connect() as conn:
            row = conn.execute(f"SELECT {col} FROM {table} WHERE id = ?", (session_key,)).fetchone()
        return row[col] if row else None
    try:
        async with state["pool"].connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"""
                        SELECT {col}
                        FROM {table}
                        WHERE id = %s;
                    """,
                    (state["session_id"],),
                )
                row = await cur.fetchone()
                return row[0] if row else None
    except Exception:
        logging.exception("[Func: get_user_value] An error occurred:\n")
        raise


async def compose_prompt(state: WorkflowState) -> str:
    """
    this function compose the prompt for the code agent by getting the different parts of the prompt

    Args:
        state: the current workflow state.

    Returns:
        the system prompt for the specified agent
    """
    current_agent = state["next_agent"].value
    active_skill = state.get("active_skill")
    prompt_base_dir = os.getenv("PATH_GENERIC_PROMPT")
    if prompt_base_dir:
        prompt_file = Path(prompt_base_dir) / f"{current_agent}.txt"
        with open(prompt_file, "r", encoding="utf-8") as file:
            GENERIC_PROMPT = file.read()
    else:
        GENERIC_PROMPT = (
            "Use the available skill metadata to decide whether a task needs a skill. "
            "Load a skill's full SKILL.md only when the task matches that skill. "
            "If required information is missing or materially ambiguous, ask the user directly. "
            "When the user asks what you can do, answer only from [Available Skills] and any "
            "currently loaded skill instructions. Do not claim capabilities from disabled or "
            "absent skills. For multi-step work, keep the user's requested deliverable as the "
            "primary skill. If another skill is needed only to gather supporting context, use it "
            "for that context and then return to the primary deliverable skill before creating "
            "the final artifact."
        )

    AVAILABLE_SKILLS_CONTEXT = ""
    if current_agent == NodeNames.CODE_AGENT.value:
        available_skills = [f"- {skill.name}: {skill.description}" for skill in list_skills()]
        AVAILABLE_SKILLS_CONTEXT = (
            "[Available Skills]\n"
            "Level 1 metadata loaded from enabled skill folders:\n"
            + "\n".join(available_skills)
            + "\n\n"
            if available_skills
            else "[Available Skills]\nNo skills are enabled for this runtime.\n\n"
        )

    GENERIC_PROMPT = (
        "[Skill Runtime]\n"
        + GENERIC_PROMPT
        + "\n\n"
        + AVAILABLE_SKILLS_CONTEXT
        + "\n\n\n"
        + (
            "[Context Priority Rules]\n"
            "When instructions conflict, apply them in the following priority order "
            "(highest to lowest):\n"
            "1. User Feedback\n"
            "2. Onboarding Instructions\n"
            "3. Environment Specific/ Domain Rules\n"
            "\n\n\n"
        )
    )

    SPECIFIC_PROMPT = await get_prompt_value(state, "prompts", "environment_specific")
    if SPECIFIC_PROMPT:
        SPECIFIC_PROMPT = (
            "[Environment / Domain Specific Prompt Context]\n"
            "This section defines constraints, standards, and expectations specific to the user's "
            "working environment (e.g., finance, industry, engineering practices).\n"
            "These rules reflect domain-specific requirements such as compliance, terminology, "
            "best practices, and risk considerations.\n"
            "You must consistently apply this context when reasoning, generating responses, "
            "or making decisions.\n"
            "This context is persistent and applies across all interactions, not just a "
            "specific phase.\n" + SPECIFIC_PROMPT
        )
    else:
        SPECIFIC_PROMPT = ""

    ONBOARDING_PROMPT = load_root_onboarding_prompt()
    if ONBOARDING_PROMPT:
        ONBOARDING_PROMPT = (
            "[Onboarding Prompt Context]\n"
            "This section contains instructions and preferences defined during the onboarding "
            "phase.\n"
            "These instructions are persistent and must be applied to all interactions.\n"
            "You must treat all onboarding instructions as strict behavioral rules. They define "
            "how you should behave, structure responses, and make decisions.\n"
            "You must consistently and actively apply them in every response.\n"
            "These rules override default model behaviors when applicable.\n"
            "However, they do not override explicit user feedback preferences when those are more "
            "specific.\n"
            "If any instruction here contradicts a system or higher-priority rule, you must follow "
            "the higher-priority rule.\n\n" + ONBOARDING_PROMPT + "\n\n\n"
        )
    else:
        ONBOARDING_PROMPT = ""

    FEEDBACK_SUMMARY = await get_user_value(state, "feedback_summary", "summary")
    if FEEDBACK_SUMMARY:
        FEEDBACK_SUMMARY = (
            "[User Feedback Prompt Context]\n"
            "This section contains a summary of feedbacks provided by the user during previous "
            "interactions.\n"
            "You must treat all feedbacks in this section as strict behavioral constraints, even "
            "if they are phrased as preferences.\n"
            "Any statement describing what the user prefers, expects, or likes must be interpreted "
            "as a requirement that you must follow in your responses.\n"
            "These constraints take precedence over default model behaviors (such as matching the "
            "user's tone, language, or style).\n"
            "When there is a conflict between these feedbacks and implicit behaviors, you must "
            "follow the feedbacks.\n\n" + FEEDBACK_SUMMARY + "\n\n\n"
        )
    else:
        FEEDBACK_SUMMARY = ""

    # logging.info(f"[{current_agent}] - GENERIC_PROMPT: \n{GENERIC_PROMPT}")
    logging.info(
        "[%s] prompt context lengths: environment=%d onboarding=%d feedback=%d",
        current_agent,
        len(SPECIFIC_PROMPT),
        len(ONBOARDING_PROMPT),
        len(FEEDBACK_SUMMARY),
    )
    logging.debug("[%s] SPECIFIC_PROMPT:\n%s", current_agent, SPECIFIC_PROMPT)
    logging.debug("[%s] ONBOARDING_PROMPT:\n%s", current_agent, ONBOARDING_PROMPT)
    logging.debug("[%s] FEEDBACK_SUMMARY:\n%s", current_agent, FEEDBACK_SUMMARY)

    BDD_DATABASE_CONTEXT = ""
    FAST_SCHEMA_CONTEXT = ""
    if current_agent == NodeNames.BDD_AGENT.value or active_skill == "bdd":
        database_context = db_tools.get_database_context()
        BDD_DATABASE_CONTEXT = (
            "\n\n[BDD Database Context]\n"
            f"Business database engine: {database_context.get('type')}\n"
            f"SQL language: {database_context.get('dialect')}\n"
            f"Default database/project: {database_context.get('database') or 'not configured'}\n"
            f"Default schema/dataset: {database_context.get('schema') or 'not configured'}\n"
            "Use this SQL language for all SQL generation, validation, and draft files in this turn.\n"
        )
        fast_schema_context = db_tools.build_fast_schema_context()
        if fast_schema_context["status"] == "success":
            FAST_SCHEMA_CONTEXT = (
                "\n\n"
                + fast_schema_context["context"]
                + "\n\n[BDD Schema Instruction]\n"
                "The injected schema map is enabled and current for this turn. Use it directly "
                "for table and column names. Do not call get_table_structure for objects already "
                "listed in the injected schema map."
            )
        elif fast_schema_context["status"] == "error":
            logging.warning(
                "[%s] Fast schema context could not be built: %s",
                current_agent,
                fast_schema_context.get("message", "Unknown error."),
            )
            FAST_SCHEMA_CONTEXT = (
                "\n\n[Fast Schema Mode]\n"
                "Fast schema mode is enabled but the quick pre-scan could not be built.\n"
                f"Reason: {fast_schema_context.get('message', 'Unknown error.')}"
            )

    composed_prompt = (
        GENERIC_PROMPT
        + SPECIFIC_PROMPT
        + ONBOARDING_PROMPT
        + FEEDBACK_SUMMARY
        + BDD_DATABASE_CONTEXT
        + FAST_SCHEMA_CONTEXT
    )
    log_raw_event(
        "composed_prompt",
        str(state.get("session_id")),
        node=current_agent,
        active_skill=active_skill,
        prompt=composed_prompt,
        available_skills=[skill.metadata for skill in list_skills()],
    )
    return composed_prompt


async def retrieve_next_agent(
    pool: AsyncConnectionPool, session_id: str, next_agent: str
) -> Optional[dict[str, Any]]:
    """
    This function retrieves the last message from the next agent
    table in response to a condition in agent_node function.
    it can be combined with the next function as they perform basically the same task.
    """
    # TODO this is not used anymore, ok?
    if USE_SQLITE_STORAGE:
        messages = _sqlite_get_messages(session_id, next_agent, 1)
        return messages[-1].model_dump() if messages else None
    try:
        async with pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"""
                    SELECT message
                    FROM {next_agent}
                    WHERE session_id = '{session_id}'
                    ORDER BY id DESC
                    LIMIT 1
                    """
                )
                row = await cur.fetchone()
        if row:
            return row[0]
        return None
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[retrieve_next_agent] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[retrieve_next_agent] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[retrieve_next_agent] error with the agent {next_agent}: {repr(e)}")
        raise


async def retrieve_last_input(
    pool: AsyncConnectionPool | None, session_id: str, input_table: str
) -> Optional[str]:
    """
    This function retrieves the last message from the user_input table
    to print the content of the last message. It is called in the user_node function.
    """
    if USE_IN_MEMORY_STORAGE:
        messages = IN_MEMORY_AGENT_MESSAGES[_session_key(session_id)].get(_agent_key(input_table), [])
        for message in reversed(messages):
            if isinstance(message, HumanMessage):
                return message.content
        return None
    if USE_SQLITE_STORAGE:
        messages = _sqlite_get_messages(session_id, input_table, 1)
        for message in reversed(messages):
            if isinstance(message, HumanMessage):
                return str(message.content)
        return None
    try:
        async with pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"""
                    SELECT message
                    FROM {input_table}
                    WHERE session_id = '{session_id}'
                    ORDER BY id DESC
                    LIMIT 1
                    """
                )
                row = await cur.fetchone()
        if row:
            return row[0]["data"]["content"]
        return None
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[retrieve_last_input] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[retrieve_last_input] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[retrieve_last_input] error with the agent {input_table}: {repr(e)}")
        raise


async def clear_agent_messages(
    pool: AsyncConnectionPool | None, session_id: str, agent_name: str
) -> None:
    """This function clears all the messages of a specific agent from PostgreSQL."""
    if USE_IN_MEMORY_STORAGE:
        IN_MEMORY_AGENT_MESSAGES[_session_key(session_id)][_agent_key(agent_name)] = []
        return
    if USE_SQLITE_STORAGE:
        _sqlite_init()
        with _sqlite_connect() as conn:
            conn.execute(
                "DELETE FROM agent_messages WHERE session_id = ? AND agent_name = ?",
                (_session_key(session_id), _agent_key(agent_name)),
            )
        return
    try:
        async with pool.connection() as conn:
            chat_history = PostgresChatMessageHistory(agent_name, session_id, async_connection=conn)
            await chat_history.aclear()
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[clear_agent_messages] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[clear_agent_messages] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[clear_agent_messages]: {e}")
        raise


async def clear_messages(pool: AsyncConnectionPool | None, session_id: str) -> None:
    """This function clears messages for all agents for a specific session(user)."""
    if USE_IN_MEMORY_STORAGE:
        IN_MEMORY_AGENT_MESSAGES[_session_key(session_id)] = defaultdict(list)
        return
    if USE_SQLITE_STORAGE:
        _sqlite_init()
        with _sqlite_connect() as conn:
            conn.execute("DELETE FROM agent_messages WHERE session_id = ?", (_session_key(session_id),))
        return
    try:
        agents = [node.value for node in NodeNames]
        tasks = [clear_agent_messages(pool, session_id, agent) for agent in agents]
        await asyncio.gather(*tasks)
        logging.info("Successfuly clearing all agents messages")
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[clear_messages] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[clear_messages] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[clear_messages]: {e}")
        raise


async def append_messages_tool(
    agent_name: str,
    pool: AsyncConnectionPool | None,
    session_id: str,
    res_tool_call: ToolMessage,
    content_to_use: str,
) -> None:
    """This function stores the Tool Messages to PostgreSQL."""
    if USE_IN_MEMORY_STORAGE:
        IN_MEMORY_AGENT_MESSAGES[_session_key(session_id)][_agent_key(agent_name)].append(
            ToolMessage(
                content=content_to_use,
                tool_call_id=res_tool_call.tool_call_id,
            )
        )
        return
    if USE_SQLITE_STORAGE:
        _sqlite_add_message(
            session_id,
            agent_name,
            ToolMessage(content=content_to_use, tool_call_id=res_tool_call.tool_call_id),
        )
        return
    try:
        async with pool.connection() as conn:
            msg_store = PostgresChatMessageHistory(agent_name, session_id, async_connection=conn)
            await msg_store.aadd_messages(
                [
                    ToolMessage(
                        content=content_to_use,
                        tool_call_id=res_tool_call.tool_call_id,
                    ),
                ]
            )
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[append_messages_tool] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[append_messages_tool] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[append_messages_tool]: {repr(e)}")
        raise


async def append_messages_ia(
    agent_name: str,
    pool: AsyncConnectionPool | None,
    session_id: str,
    resp: AIMessage,
):
    """This function stores the AI (assistant) Messages to PostgreSQL."""
    if USE_IN_MEMORY_STORAGE:
        target = IN_MEMORY_AGENT_MESSAGES[_session_key(session_id)][_agent_key(agent_name)]
        if not isinstance(resp, str):
            target.append(
                AIMessage(
                    id=resp.id,
                    tool_calls=resp.tool_calls,
                    content=resp.content,
                    response_metadata=resp.response_metadata,
                )
            )
        else:
            target.append(AIMessage(content=resp))
        return
    if USE_SQLITE_STORAGE:
        if not isinstance(resp, str):
            message = AIMessage(
                id=resp.id,
                tool_calls=resp.tool_calls,
                content=resp.content,
                response_metadata=resp.response_metadata,
            )
            _sqlite_add_message(session_id, agent_name, message)
            token_usage = resp.response_metadata.get("token_usage", {})
            with _sqlite_connect() as conn:
                conn.execute(
                    """
                    INSERT INTO response_metadata
                    (id, agent_name, input_tokens, output_tokens, total_tokens, model_name, model, finish_reason)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        _session_key(session_id),
                        _agent_key(agent_name),
                        token_usage.get("prompt_tokens"),
                        token_usage.get("completion_tokens"),
                        token_usage.get("total_tokens"),
                        resp.response_metadata.get("model_name"),
                        resp.response_metadata.get("model"),
                        resp.response_metadata.get("finish_reason"),
                    ),
                )
        else:
            _sqlite_add_message(session_id, agent_name, AIMessage(content=resp))
        return
    try:
        async with pool.connection() as conn:
            msg_store = PostgresChatMessageHistory(agent_name, session_id, async_connection=conn)
            if not isinstance(resp, str):
                if resp.tool_calls:
                    logging.info(
                        f"# 1 # variable res_tool_call tool_call_id: {resp.tool_calls[0]['id']}"
                    )
                await msg_store.aadd_messages(
                    [
                        AIMessage(
                            id=resp.id,
                            tool_calls=resp.tool_calls,
                            content=resp.content,
                            response_metadata=resp.response_metadata,
                        ),
                    ]
                )

                response_metadata = {
                    "id": session_id,
                    "agent_name": agent_name.value,
                    "input_tokens": resp.response_metadata["token_usage"]["prompt_tokens"],
                    "output_tokens": resp.response_metadata["token_usage"]["completion_tokens"],
                    "total_tokens": resp.response_metadata["token_usage"]["total_tokens"],
                    "model_name": resp.response_metadata["model_name"],
                    "model": resp.response_metadata["model"],
                    "finish_reason": resp.response_metadata["finish_reason"],
                }
                async with conn.cursor() as cur:
                    try:
                        await cur.execute(
                            f"""
                                INSERT INTO response_metadata
                                {str(tuple(response_metadata.keys())).replace("'", "")}
                                VALUES {tuple(response_metadata.values())};
                            """
                        )
                    except Exception as e:
                        logging.error(f"Error creating response_metadata table: {e}")
                        raise e
            else:
                await msg_store.aadd_messages(
                    [
                        AIMessage(content=resp),
                    ]
                )
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[append_messages_ia] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[append_messages_ia] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[append_messages_ia]: {repr(e)}")
        raise


async def append_messages_user(
    agent_name: str, pool: AsyncConnectionPool | None, session_id: str, message: str
) -> None:
    """This function stores the Human (user) Messages to PostgreSQL."""
    if USE_IN_MEMORY_STORAGE:
        IN_MEMORY_AGENT_MESSAGES[_session_key(session_id)][_agent_key(agent_name)].append(
            HumanMessage(content=message)
        )
        return
    if USE_SQLITE_STORAGE:
        _sqlite_add_message(session_id, agent_name, HumanMessage(content=message))
        return
    try:
        async with pool.connection() as conn:
            msg_store = PostgresChatMessageHistory(agent_name, session_id, async_connection=conn)
            await msg_store.aadd_messages(
                [
                    HumanMessage(content=message),
                ]
            )
    except psycopg.errors.DatabaseError as db_error:
        logging.error(f"[append_messages_user] psycopg-related error: {db_error}")
        raise
    except asyncio.CancelledError:
        logging.error("[append_messages_user] asyncio task was cancelled.")
        raise
    except Exception as e:
        logging.error(f"[append_messages_user]: {repr(e)}")
        raise
