"""Main file of the repo, used to define the agent and tools graph."""

import asyncio
import logging
import os
import platform
import sys
from datetime import datetime
from pathlib import Path
from typing import Literal

from langchain_openai import ChatOpenAI
from langgraph.graph import END, START, StateGraph
from psycopg_pool import AsyncConnectionPool

from .skills_runtime.runtime import get_skill_runtime_node
from .skills_runtime.agent_loop import user_node
from .skills_runtime.storage import (
    USE_IN_MEMORY_STORAGE,
    USE_SQLITE_STORAGE,
    init_workflow_state,
    setup_postgres_saver,
)
from .skills_runtime.structs import NodeNames, WorkflowState
from .runtime_paths import load_runtime_env, logs_root
from .https_config import openai_http_client_kwargs

load_runtime_env()


def _normalize_openai_base_url(value: str | None) -> str:
    """Accept either an OpenAI base URL or a full chat completions endpoint."""

    if not value:
        raise ValueError("OPENAI_BASE_URL or CUSTOMCONNSTR_OPENAI_BASE_URL must be set")
    endpoint = value.strip().rstrip("/")
    for suffix in ("/chat/completions", "/responses"):
        if endpoint.endswith(suffix):
            endpoint = endpoint[: -len(suffix)]
    return endpoint


def get_openai_api_key() -> str:
    """Read the OpenAI-compatible API key from supported environment variables."""

    return (
        os.getenv("CUSTOMCONNSTR_OPENAI_API_KEY")
        or os.getenv("OPENAI_API_KEY")
        or os.getenv("AZURE_OPENAI_API_KEY")
        or ""
    )


def get_openai_base_url() -> str:
    """Read the OpenAI-compatible base URL from supported environment variables."""

    return _normalize_openai_base_url(
        os.getenv("CUSTOMCONNSTR_OPENAI_BASE_URL")
        or os.getenv("OPENAI_BASE_URL")
        or os.getenv("OPENAI_ENDPOINT")
        or os.getenv("AZURE_OPENAI_ENDPOINT")
    )


def get_openai_model() -> str:
    """Read the chat completion model/deployment name."""

    return os.getenv("OPENAI_MODEL") or os.getenv("AZURE_OPENAI_MODEL") or ""


def build_openai_chat_model() -> ChatOpenAI:
    """Build the OpenAI-compatible chat model used by the skill runtime."""

    api_key = get_openai_api_key()
    if not api_key:
        raise ValueError("OPENAI_API_KEY or CUSTOMCONNSTR_OPENAI_API_KEY must be set")
    model = get_openai_model()
    if not model:
        raise ValueError("OPENAI_MODEL or AZURE_OPENAI_MODEL must be set")
    base_url = get_openai_base_url()
    logging.info("Using OpenAI-compatible chat model: model=%s base_url=%s", model, base_url)
    return ChatOpenAI(
        model=model,
        api_key=api_key,
        base_url=base_url,
        temperature=0,
        **openai_http_client_kwargs(),
    )


def decide_start_agent(state: WorkflowState) -> Literal[NodeNames.CODE_AGENT]:
    """Resume the single skill runtime after user input."""
    return NodeNames.CODE_AGENT


def build_langgraph(
    should_pause_graph_when_user_input_required: bool,
    openai_api_key: str | None = None,
    openai_base_url: str | None = None,
    openai_model: str | None = None,
) -> StateGraph:
    """
    Build and return the graph.

    Args:
        should_pause_graph_when_user_input_required (bool): if True (for the HTML API), the graph
            execution is stopped when the user_node is reached. Then, the code waits for user input
            before rerunning the graph from a saved WorkflowState.
            If False (command line), the graph continues until user exits.
        openai_api_key: API key for the OpenAI-compatible chat completions endpoint.
        openai_base_url: Base URL ending at `/openai/v1`; a full `/chat/completions`
            endpoint is also accepted and normalized.
        openai_model: Model/deployment name for chat completions.

    """
    # TODO basic error handling? What do we do if a code error happens ?
    # TODO use llm with fallback, to use different models in case of ratelimit or server error
    logging.info("Starting new session")
    state_graph = StateGraph(WorkflowState)
    if openai_api_key:
        os.environ["OPENAI_API_KEY"] = openai_api_key
    if openai_base_url:
        os.environ["OPENAI_BASE_URL"] = _normalize_openai_base_url(openai_base_url)
    if openai_model:
        os.environ["OPENAI_MODEL"] = openai_model
    llm = build_openai_chat_model()
    code_node = get_skill_runtime_node(llm)

    for node_name, node in [
        (NodeNames.CODE_AGENT, code_node),
        (NodeNames.USER_INPUT, user_node),
    ]:
        state_graph.add_node(node_name, node)

    if not should_pause_graph_when_user_input_required:
        state_graph.add_edge(START, NodeNames.USER_INPUT)
        state_graph.add_edge(NodeNames.USER_INPUT, END)
    else:
        # add agents which can have control after user input is required
        state_graph.add_conditional_edges(
            START,
            decide_start_agent,
            {
                NodeNames.CODE_AGENT: NodeNames.CODE_AGENT,
            },
        )
    return state_graph


if __name__ == "__main__":
    logformatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")

    current_date = datetime.today()
    dir_to_store_logs = logs_root() / str(current_date.year) / f"{current_date.month:02d}" / f"{current_date.day:02d}"
    Path(dir_to_store_logs).mkdir(parents=True, exist_ok=True)

    filelog = logging.FileHandler(
        filename=Path(dir_to_store_logs) / "agentic_log.log",
        encoding="utf-8",
    )
    filelog.setLevel(logging.INFO)
    filelog.setFormatter(logformatter)

    # print errors and warning in stdout
    consolelog = logging.StreamHandler(stream=sys.stdout)
    consolelog.setLevel(logging.WARNING)
    consolelog.setFormatter(logformatter)
    logging.basicConfig(handlers=[filelog, consolelog], encoding="utf-8", level=logging.INFO)
    logging.info("Starting app in local mode")

    DB_URI = os.getenv("POSTGRESQLCONNSTR_AGENT_RUNTIME_DATABASE_URL", "")
    if not DB_URI and not USE_SQLITE_STORAGE and not USE_IN_MEMORY_STORAGE:
        logging.error("POSTGRESQLCONNSTR_AGENT_RUNTIME_DATABASE_URL is required for postgres runtime storage.")
        sys.exit(1)

    # use a fixed uuid for local debugging
    session_id = os.getenv("session_id", "b0349761-27d2-4960-b7a2-c0631d23b06f")
    if DB_URI and os.getenv("ENABLE_POSTGRES_CHECKPOINTER", "false").lower() == "true":
        try:
            setup_postgres_saver(DB_URI)
        except Exception as exc:
            logging.warning(f"Postgres checkpointer setup skipped: {exc}")
    APP_GRAPH = build_langgraph(
        should_pause_graph_when_user_input_required=False,
        openai_api_key=get_openai_api_key(),
        openai_base_url=get_openai_base_url(),
        openai_model=get_openai_model(),
    )
    # TODO should maybe (???) add checkpointer here, with compile(checkpointer=checkpointer)
    # but this would require some debugging + to define a method (notimplementederror)
    APP = APP_GRAPH.compile()

    # NOTE: uncomment below to obtain graph for debug
    # This can often cause failure, use for debug only
    # try:
    #     with open("AgenticAI_graph.png", "wb") as png:
    #         png.write(APP.get_graph().draw_mermaid_png())
    #     logging.info("Graph visualization saved to AgenticAI_graph.png")
    # except Exception as e:
    #     logging.warning(f"Could not generate graph visualization: {e}")

    if not os.getenv("NOTIFY_IN_CONSOLE"):
        os.environ["NOTIFY_IN_CONSOLE"] = "true"

    async def run_app():
        """Run the app for local tests."""
        is_local_run = os.getenv("LOCAL_RUN", "false").lower() == "true"
        if is_local_run and (USE_IN_MEMORY_STORAGE or USE_SQLITE_STORAGE):
            workflow_state = await init_workflow_state(
                session_id, None, local=True, activity_context=None
            )
            async for _ in APP.astream(
                workflow_state,
                config={
                    "configurable": {"thread_id": session_id},
                    "recursion_limit": 100,
                },
                print_mode="updates",
            ):
                continue
            return

        pool_min_size = int(os.getenv("CONNEXION_POOL_MIN_SIZE", 0 if is_local_run else 4))
        pool_max_size = int(os.getenv("CONNEXION_POOL_MAX_SIZE", 1 if is_local_run else 4))
        async with AsyncConnectionPool(
            DB_URI,
            min_size=pool_min_size,
            max_size=pool_max_size,
        ) as pool:
            workflow_state = await init_workflow_state(
                session_id, pool, local=True, activity_context=None
            )
            async for _ in APP.astream(
                workflow_state,
                config={
                    "configurable": {"thread_id": session_id},
                    "recursion_limit": 100,
                },
                print_mode="updates",
            ):
                continue

    # Using WindowsSelectorEventLoopPolicy in case the OS is Windows
    if platform.system() == "Windows":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    asyncio.run(run_app())
