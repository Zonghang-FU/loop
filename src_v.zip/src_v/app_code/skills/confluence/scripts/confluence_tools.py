"""
Confluence tools using atlassian-python-api.
"""

import logging
import os
import re
from functools import lru_cache
from typing import Any

from atlassian import Confluence
from bs4 import BeautifulSoup
from markdownify import markdownify

from app_code.https_config import https_verify_enabled

from .confluence_config import CONFLUENCE_CONFIG

# Optional if not set, no access restrictions are applied
ALLOWED_SPACE = os.getenv("CONFLUENCE_ALLOWED_SPACE")
ALLOWED_LABEL = os.getenv("CONFLUENCE_ALLOWED_LABEL")


@lru_cache(maxsize=1)
def get_confluence_client() -> Confluence:
    """Initialize and return a Confluence client using environment variables."""
    CONFLUENCE_CONFIG.validate()
    return Confluence(
        url=CONFLUENCE_CONFIG.url,
        username=CONFLUENCE_CONFIG.username,
        password=CONFLUENCE_CONFIG.api_token,
        cloud=True,
        verify_ssl=https_verify_enabled(),
    )


# ==================================================================
# Fonctions utilitaires pour les outils Confluence
# ==================================================================


def _build_url(base_url, webui_path: str) -> str:
    """Helper to build absolute URLs."""
    return f"{base_url}{webui_path}"


def _check_label_and_space(
    page, page_id: str, denomination_of_page_in_error_message: str = "Page"
) -> str:
    """Helper which checks if a page is in the allowed label/space"""
    if ALLOWED_SPACE and page.get("space", {}).get("key") != ALLOWED_SPACE:
        return (
            f"Access denied: {denomination_of_page_in_error_message} {page_id} "
            f"is outside the allowed Confluence space '{ALLOWED_SPACE}'."
        )

    labels = [
        label.get("name") for label in page.get("metadata", {}).get("labels", {}).get("results", [])
    ]
    if ALLOWED_LABEL and ALLOWED_LABEL not in labels:
        return f"Access denied: Page {page_id} does not have the required label '{ALLOWED_LABEL}'."

    return ""


def _parse_xml_to_markdown(xml_content: str) -> str:
    """
    Parses Confluence XML storage format into clean, token-efficient Mardkown.

    This strips images (only filename or alt text is retained), scripts, and styles.

    Args:
        xml_content (str): the XML-formatted Confluence page body.

    Returns:
        str: the Mardkown equivalent without images and unsupported visual effects.
    """
    if not xml_content:
        return ""

    soup = BeautifulSoup(xml_content, "html.parser")

    # handle confluence code blocks
    for macro in soup.find_all("ac:structured-macro", {"ac:name": "code"}):
        lang_param = macro.find("ac:parameter", {"ac:name": "language"})
        language = lang_param.get_text(strip=True) if lang_param else "unspecified"
        code_body = macro.find("ac:plain-text-body")
        if code_body:
            code_text = f"\n```{language}\n{code_body.get_text().strip()}\n```\n"
            macro.replace_with(soup.new_string(code_text))

    # Remove noise (macros that are just visual, scripts)
    for tag in soup(["script", "style"]):
        tag.decompose()

    for img in soup.find_all(["img", "ac:image"]):
        # Try to find a description or filename to give the agent a hint
        # Confluence often stores filenames in 'ac:filename'
        alt_text = img.get("alt") or img.get("ac:filename") or "Image sans titre"

        # Replace the image tag with a compact markdown marker
        img.replace_with(soup.new_string(f" [Image: {alt_text}] "))

    # Pass the cleaned HTML to markdownify
    # heading_style="ATX" ensures # Header format (token efficient)
    text = markdownify(
        str(soup),
        heading_style="ATX",
        bullets="-",
    )

    text = text.replace("\xa0", " ")

    # Remove redundant horizontal spaces within a line (keeps \n intact)
    # This turns "|   |  content  |" into "| | content |"
    text = re.sub(r"[ \t]+", " ", text)

    # Tables: Newline before the table start, but NOT between rows
    # Logic: Match a newline + pipe, UNLESS preceded by another pipe + newline.
    text = re.sub(r"(?<!\|)\n\|", r"\n\n|", text)

    # Ensure headers have a blank line before them
    text = re.sub(r"([^\n])\n#", r"\1\n\n#", text)

    # Lists: Newline before the first item and after the last item
    # Newline before: if line starts with '-' and previous line
    # didn't start with '-'
    text = re.sub(r"(?<!-)\n- ", r"\n\n- ", text)
    # Newline after: if line starts with '-' and next line doesn't
    text = re.sub(r"(\n- .*)\n(?=[^-])", r"\1\n\n", text)

    # Squashing of excessive newlines
    lines = [line.rstrip() for line in text.splitlines()]
    text = "\n".join(lines)
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()


# ==================================================================
# CONFLUENCE TOOLS
# ==================================================================


def search_confluence_pages(text_contains_filter: str = None) -> dict[str, Any]:
    """
    Searches for documentation in Confluence, based on a text_contains_filter arg.

    Results are ordered by lastModifed date and text_contains_filter is added to a
    templatized cql query:
    ```cql
    type = page
    AND text ~ "{text_contains_filter}"
    ORDER BY lastModified
    ```
    """
    try:
        confluence_client = get_confluence_client()

        cql_parts = ["type = page"]
        if ALLOWED_SPACE:
            cql_parts.append(f'AND space = "{ALLOWED_SPACE}"')
        if ALLOWED_LABEL:
            cql_parts.append(f'AND label = "{ALLOWED_LABEL}"')

        if text_contains_filter:
            # Clean query: escape quotes and handle potential empty strings
            clean_query = re.sub(r'(?<!\\)"', r"\"", text_contains_filter)
            if clean_query.startswith(("*", "?")):
                # avoid wildcards on first char, not supported by Confluence
                # as of now and could mess up results/increase latency.
                clean_query = clean_query[1:]
            cql_parts.append(f'AND text ~ "{clean_query}"')

        cql_parts.append("ORDER BY lastModified DESC")
        cql = " ".join(cql_parts)

        results = confluence_client.cql(cql, limit=10, excerpt="highlight")

        formatted_results = []
        for page in results.get("results", []):
            content = page.get("content", {})
            formatted_results.append(
                {
                    "page_id": content.get("id"),
                    "title": content.get("title"),
                    "url": _build_url(
                        confluence_client.url, content.get("_links", {}).get("webui", "")
                    ),
                    "snippet": page.get("excerpt", "No summary available."),
                    "last_updated": page.get(
                        "friendlyLastModified", page.get("lastModified", "Unknown")
                    ),
                }
            )
        data_to_return = {
            "status": "success",
            "data": formatted_results,
        }
        if not formatted_results:
            data_to_return["message"] = "No pages found matching the criteria."
        return data_to_return
    except Exception as e:
        error_message = f"Error searching Confluence pages: {str(e)}"
        logging.error(error_message)
        return {"status": "error", "message": error_message}


def get_confluence_page_content(page_id: str) -> dict[str, Any]:
    """
    Retrieves the full content and metadata of a specific Confluence page, based on its id.

    Returns a dict containing status and a data dict containing page content and metadata:
        - page_id (str): Unique ID for the page.
        - title (str): Title of the page.
        - url (str): Direct link to the page.
        - content (str): Page content in plaintext format
            (a parsing is made to convert from Confluence XML format)
        - ancestors (list[dict[str, Any]]): list of the page parents
            with id and title.
        - version (int): version number of the page.
        - last_updated (str): The date the page was last updated.
    """
    try:
        client = get_confluence_client()

        page = client.get_page_by_id(
            page_id,
            expand="body.storage,version,ancestors.metadata.labels,space,metadata.labels",
        )

        error_message = _check_label_and_space(page, page_id)
        if error_message:
            return {"status": "error", "message": error_message}

        content = page.get("body", {}).get("storage", {}).get("value", "")
        try:
            content = _parse_xml_to_markdown(content)
        except Exception as e:
            # if parsing fails, log and return the original xml content.
            logging.warning("Error in xml Confluence page parsing %s", repr(e))

        return {
            "status": "success",
            "data": {
                "page_id": page["id"],
                "title": page["title"],
                "url": _build_url(client.url, page.get("_links", {}).get("webui", "")),
                "content": content,
                "ancestors": [
                    {"id": ancestor["id"], "title": ancestor["title"]}
                    for ancestor in page.get("ancestors", [])
                    if not ALLOWED_LABEL
                    or ALLOWED_LABEL
                    in [
                        label.get("name")
                        for label in ancestor.get("metadata", {})
                        .get("labels", {})
                        .get("results", [])
                    ]
                ],
                "version": page.get("version", {}).get("number"),
                "last_updated": page.get("version", {}).get(
                    "friendlyWhen", page.get("when", "Inconnue")
                ),
            },
        }
    except Exception as e:
        error_message = f"Error when retrieving confluence page content: {str(e)}"
        logging.error(error_message)
        return {"status": "error", "message": error_message}


def get_confluence_page_children(page_id: str, nb_children_to_fetch: int = 10) -> dict[str, Any]:
    """
    Lists direct child pages of a Confluence page.

    Returns a dict containing status and a list of dicts containing children page metadata.
    """
    try:
        client = get_confluence_client()

        # minimum 1, maximum 50
        nb_children_to_fetch = max(1, min(nb_children_to_fetch, 50))
        parent = client.get_page_by_id(page_id, expand="space,metadata.labels")

        _check_label_and_space(parent, page_id, denomination_of_page_in_error_message="Parent page")

        # Build CQL query - only filter by label/space if configured
        cql_parts = [f'parent = "{page_id}"', 'AND type = "page"']
        if ALLOWED_SPACE:
            cql_parts.append(f'AND space = "{ALLOWED_SPACE}"')
        if ALLOWED_LABEL:
            cql_parts.append(f'AND label = "{ALLOWED_LABEL}"')
        cql = " ".join(cql_parts)

        results = client.cql(cql, limit=nb_children_to_fetch, excerpt=None)
        formatted_children = []
        for page in results.get("results", []):
            content = page.get("content", {})
            formatted_children.append(
                {
                    "page_id": content.get("id"),
                    "title": content.get("title"),
                    "url": _build_url(client.url, content.get("_links", {}).get("webui", "")),
                }
            )

        if len(formatted_children) >= nb_children_to_fetch:
            formatted_children.append(
                {
                    "info": f"Limit of {nb_children_to_fetch} children reached. "
                    "There may be more children."
                }
            )

        data_to_return = {
            "status": "success",
            "data": formatted_children,
        }
        if not formatted_children:
            data_to_return["message"] = "No child pages found for the target page."
        return data_to_return
    except Exception as e:
        error_message = f"Error retrieving Confluence page children: {str(e)}"
        logging.error(error_message)
        return {"status": "error", "message": error_message}
