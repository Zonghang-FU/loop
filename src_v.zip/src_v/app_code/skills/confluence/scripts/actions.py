"""
Jira agent file, containing initial prompt, jira agent specific tools
and jira node creation function.
"""

import json
import logging

from langchain_core.tools import tool

from app_code.skills.confluence.scripts import confluence_tools
from app_code.skills_runtime.structs import NodeNames, ToolNames
from app_code.skills_runtime.user_actions import (
    handoff_to_user,
)

# ---  Definition of Confluence tools  ---

SEARCH_CONFLUENCE_PAGES = "search_confluence_pages"
GET_CONFLUENCE_PAGE_CONTENT = "get_confluence_page_content"
GET_CONFLUENCE_PAGE_CHILDREN = "get_confluence_page_children"


@tool(
    SEARCH_CONFLUENCE_PAGES,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def search_confluence_pages(
    text_contains_filter: str = None,
) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Searches for documentation in Confluence.

    The tool always returns the most recently updated pages by appending
    "ORDER BY lastModified" to the CQL query.

    The text_contains_filter parameter will be inserted in the following CQL
    (Confluence Query Language) template:
    ```cql
    type = page
    AND text ~ "{text_contains_filter}"
    ORDER BY lastModified
    ```

    Args:
        text_contains_filter (Optional[str]): A keyword or phrase to search for
            within page content. If no `text_contains_filter` is specified,
            the tool returns the most recently updated pages.

    Returns:
        str: A string containing a list of pages' metadata, with:
            - page_id: Unique ID for the page.
            - title: Title of the page.
            - url: Direct link to the page.
            - snippet: A short summary or text highlight from the page.
            - last_updated: The date the page was last updated.
    """
    logging.info("-- Search Confluence Pages tool --")
    result = confluence_tools.search_confluence_pages(text_contains_filter)

    if result["status"] == "success":
        data = result.get("data", {})
        if data:
            formatted_response = f"Success: Search made with {text_contains_filter}"
            context_msg = json.dumps(data, ensure_ascii=False)
        else:
            formatted_response = result.get(
                "message", f"No page found with criteria {text_contains_filter}"
            )
            context_msg = formatted_response
    else:
        error_message = result.get("message", "Unknown error.")
        formatted_response = (
            f"Error during Confluence search with  {text_contains_filter}: {error_message}"
        )
        context_msg = formatted_response
    return formatted_response, {
        "next_agent": NodeNames.CODE_AGENT,
        "context": context_msg,
    }


@tool(
    GET_CONFLUENCE_PAGE_CONTENT,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def get_confluence_page_content(page_id: str) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Retrieves the full content and metadata of a specific Confluence page.

    Args:
        page_id (str): the identifier of the page

    Returns:
        str: a string containing page content and metadata, with:
            - page_id: Unique ID for the page.
            - title: Title of the page.
            - url: Direct link to the page.
            - content: Page content in plaintext format
                (a parsing is made to convert from Confluence XML format)
            - ancestors: list of the page parents
                with id and title.
            - version: version number of the page.
            - last_updated: The date the page was last updated.
    """
    logging.info("-- Get Confluence Page Content tool --")
    result = confluence_tools.get_confluence_page_content(page_id)

    if result["status"] == "success":
        data = result.get("data", {})
        if data:
            formatted_response = f"Success: Obtained page {page_id} content."
            context_msg = json.dumps(data, ensure_ascii=False)
        else:
            formatted_response = result.get("message", f"No page found with id {page_id}")
            context_msg = formatted_response
    else:
        error_message = result.get("message", "Unknown error.")
        formatted_response = (
            f"Error during Confluence page {page_id} content retrieval: {error_message}"
        )
        context_msg = formatted_response
    return formatted_response, {
        "next_agent": NodeNames.CODE_AGENT,
        "context": context_msg,
    }


@tool(
    GET_CONFLUENCE_PAGE_CHILDREN,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def get_confluence_page_children(
    page_id: str, nb_children_to_fetch: int = 10
) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Lists direct child pages of a Confluence page.

    Args:
        page_id (str): the page identifier.
        nb_children_to_fetch (int): the maximum number of children to fetch.
            Hardcoded maximum of 50.

    Returns:
        str: a string containing the id, title and url of the `nb_children_to_fetch` most recently
            updated children pages of the target confluence page.
    """
    logging.info("-- Get Confluence Page Children tool --")
    result = confluence_tools.get_confluence_page_children(page_id, nb_children_to_fetch)

    if result["status"] == "success":
        data = result.get("data", {})
        if data:
            formatted_response = f"Success: Retrieved page {page_id} children"
            context_msg = json.dumps(data, ensure_ascii=False)
        else:
            formatted_response = result.get("message", f"No children found for page {page_id}")
            context_msg = formatted_response
    else:
        error_message = result.get("message", "Unknown error.")
        formatted_response = (
            f"Error during Confluence page {page_id} children discovery: {error_message}"
        )
        context_msg = formatted_response
    return formatted_response, {
        "next_agent": NodeNames.CODE_AGENT,
        "context": context_msg,
    }


skill_actions = {
    ToolNames.HANDOFF_TO_USER: handoff_to_user,
    SEARCH_CONFLUENCE_PAGES: search_confluence_pages,
    GET_CONFLUENCE_PAGE_CONTENT: get_confluence_page_content,
    GET_CONFLUENCE_PAGE_CHILDREN: get_confluence_page_children,
}
