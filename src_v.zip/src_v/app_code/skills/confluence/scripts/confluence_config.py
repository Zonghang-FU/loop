"""Confluence configuration using dataclass for type safety and immutability."""

import os
from dataclasses import dataclass

from app_code.runtime_paths import load_runtime_env

load_runtime_env()


@dataclass(frozen=True)
class ConfluenceConfig:
    """Immutable Confluence configuration.

    Attributes:
        url: Confluence instance URL (e.g., https://company.atlassian.net)
        username: Confluence account email
        api_token: Confluence API token for authentication
    """

    url: str
    username: str
    api_token: str

    def validate(self) -> None:
        """Validate configuration before making Confluence API calls."""
        if not self.url or self.url == "https://your-domain.atlassian.net":
            raise ValueError(
                "CONFLUENCE_URL not configured. Set it in runtime/env file:\n"
                "CONFLUENCE_URL=https://your-domain.atlassian.net"
            )

        if not self.username or self.username == "email@example.com":
            raise ValueError(
                "CONFLUENCE_USERNAME not configured. Set it in runtime/env file:\n"
                "CONFLUENCE_USERNAME=your-email@example.com"
            )

        if not self.api_token or self.api_token == "default_token":
            raise ValueError(
                "CONFLUENCE_API_TOKEN not configured. Set it in runtime/env file:\n"
                "CONFLUENCE_API_TOKEN=your_confluence_api_token"
            )

        if not self.url.startswith("https://"):
            raise ValueError(f"CONFLUENCE_URL must start with 'https://': {self.url}")


# Singleton instance
CONFLUENCE_CONFIG = ConfluenceConfig(
    url=os.getenv("CONFLUENCE_URL", ""),
    username=os.getenv("CONFLUENCE_USERNAME", ""),
    api_token=os.getenv("CONFLUENCE_API_TOKEN", ""),
)
