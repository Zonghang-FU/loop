---
name: confluence
description: Read Confluence pages in read-only mode by searching pages, retrieving page content by ID, and listing child pages. Use this skill when the user provides a Confluence URL or page ID, asks to read, summarize, or search Confluence content, or wants to inspect a page tree.
---

# Confluence Skill

## When to Use
Use this skill to:

- Find Confluence pages by keyword or content
- Read a Confluence page using its ID
- List the child pages of a known page
- Summarize or compare Confluence content
- Traverse a page hierarchy to locate related documentation

## Implementation

This skill is self-contained:

- `scripts/actions.py` exposes Confluence actions.
- `scripts/confluence_tools.py` contains Confluence API helpers.
- `scripts/confluence_config.py` contains Confluence configuration.

Add new Confluence behavior inside this skill directory. Do not add a shared Confluence helper outside the
skill.

## Instructions

1. Start by identifying the page ID(s)
   - Use a user-provided page ID directly.
   - Extract the ID from a Confluence URL when possible.
   - If the ID is unknown, discover it through a Confluence CQL search.
   - If a page hierarchy is known, inspect child pages before relying on broad searches.
2. Confluence search syntax and technical constraints
   - Use fuzzy search with `~` when matching similar terms is helpful.
   - Use `*` or `?` only as suffix wildcards.
   - Do not use prefix wildcards; Confluence CQL does not support them.
   - Escape double quotes for exact matches, for example: `\"foo bar\"`.
3. Read the relevant content only after identifying the correct page ID(s)
   - Fetch the page content for the selected page(s).
   - Fetch child pages only when they are useful for navigation or discovery.
4. Keep the process bounded
   - Stop after a reasonable number of searches if the target cannot be found.
   - Explain what was found and what is still missing.

## Action Call Examples

Search a page with CQL filtering:

Action: `search_confluence_pages`

Arguments:

```json
{"text_contains_filter": "term-to-search"}
```

Get a page's content:

Action: `get_confluence_page_content`

Arguments:

```json
{"page_id": "980245"}
```

Get a page's children:

Action: `get_confluence_page_children`

Arguments:

```json
{"page_id": "658934", "nb_children_to_fetch": 10}
```

## Safety

- **Do not** invent page IDs, URLs or titles.
- Do not output bare Confluence page IDs when the corresponding URL is available. IDs are for internal traceability only; the user-facing answer must use clickable links.
- **Keep the process bounded**: stop after a reasonable number of searches if the target cannot be found.
- Explain what was found and what is still missing.
**Stay read-only**: do not edit or comment on pages.

## Output Format

Return:
- The page title and URL for each page used. Each page used **must** be quoted as a clickable Markdown link `[title](URL)`.
- A concise summary of the relevant content.
- Any unresolved blockers.
