---
name: bdd
description: Work with business SQL databases, DBs, schemas, datasets, and tables across PostgreSQL/Postgres, BigQuery, Teradata, MySQL/MariaDB, and Snowflake/Snowflow. Use this skill for database discovery, structure inspection, dialect-specific SQL generation, SQL syntax validation, SELECT queries, dry-run DDL or DML, approved SQL modifications, SQL migration drafts, and business data investigation.
---

# SQL Database Work

Use this skill for database discovery, SQL generation, SQL validation, read queries, guarded write
execution, and SQL draft files. The business database is separate from the agent's own SQLite
runtime database.

## Implementation

This skill is self-contained:

- `scripts/actions.py` exposes the database actions.
- `scripts/db_tools.py` contains dialect-aware execution helpers.
- `scripts/db_config.py` loads business database connection configuration from `runtime/bd_env`.
- `scripts/draft_files.py` stores and reads session-scoped SQL draft files.
- `scripts/db_resources/` contains bundled SQL initialization resources used by this skill.

Add new database behavior inside this skill directory. Do not add a shared database helper outside
the skill.

## Process

0. Use the injected `[BDD Database Context]` as the active database profile. It gives the SQL
   language plus the default database/project and schema/dataset for this turn.
1. Discover the target database, schema, and table when they are not explicit.
2. Inspect table structure before relying on columns, constraints, or default values.
3. For reads, generate a bounded read-only query and execute it directly. Do not dry-run SELECT,
   WITH, SHOW, DESCRIBE, or other read-only SQL. If the database returns an error, use that exact
   error message to correct the SQL and retry.
4. For DDL/DML or any write/update/delete/create/drop operation, validate syntax, dry-run, then execute only the same SQL/database pair that passed
   dry-run in this run.
5. For reusable SQL, write a `.sql` draft file and return the draft path. If the requested
   deliverable is not SQL, let the runtime switch to the appropriate enabled skill instead of
   trying to force it into a SQL draft.

When the user explicitly asks for a complete redo or rebuild, treat incompatible existing tables
as disposable only for the named target objects. Inspect the current table first; if `CREATE TABLE
IF NOT EXISTS` would keep a stale structure that conflicts with the requested DDL, generate a
single guarded script that drops and recreates only that target table before inserting data:

```sql
DROP TABLE IF EXISTS schema.table_name;
CREATE TABLE schema.table_name (...);
INSERT INTO schema.table_name (...) VALUES (...);
```

Validate and dry-run that exact script before execution. This avoids false success on old schemas
and prevents insert failures from missing defaults or stale constraints.

Ignore system schemas such as `information_schema`, `pg_catalog`, and vendor system catalogs unless explicitly requested.
If the target is ambiguous, ask the user instead of guessing.

## Supported SQL Engines

The active engine is loaded by the runtime from the business database environment file. Supported
engines:

- `postgresql` or aliases `pg`, `postgres`
- `bigquery` or alias `bq`
- `teradata` or alias `td`
- `mysql` or alias `mariadb`
- `snowflake` or compatibility alias `snowflow`

Only one business database is active at a time. Use the injected database context and action
responses as the source of truth for SQL generation. If a requested SQL feature is vendor-specific
and required details are missing, ask a direct follow-up question.

## Configuration

Business database configuration lives in `runtime/bd_env`, separate from `runtime/env`. Keep
credentials in environment variables and never echo passwords or service account JSON back to the
user.

For BigQuery, `BDD_BIGQUERY_SERVICE_ACCOUNT_JSON` contains the service account JSON directly as a
single-line environment value. Treat it as a secret. Use BigQuery Standard SQL with fully qualified
project.dataset.table names when needed.

When writing Python scripts from this skill or the terminal skill, use the current database profile
and read connection values from the environment. Keep the script aligned with the injected SQL
language.

## Action Call Examples

List databases:

Action: `list_available_databases`

Arguments:

```json
{}
```

Inspect a table:

Action: `get_table_structure`

Arguments:

```json
{"database_name": "agent_dev", "schema_name": "dev", "table_name": "orders"}
```

Run a read query:

Action: `execute_read_query`

Arguments:

```json
{"sql_query": "SELECT id, status FROM dev.orders LIMIT 20", "database_name": "agent_dev"}
```

Run a guarded modification:

Action: `verify_sql_syntax`

Arguments:

```json
{"sql_query": "UPDATE dev.orders SET status = 'archived' WHERE id = 42", "database_name": "agent_dev"}
```

Action: `test_sql_modification_dry_run`

Arguments:

```json
{"sql_query": "UPDATE dev.orders SET status = 'archived' WHERE id = 42", "database_name": "agent_dev"}
```

Action: `execute_sql_modification`

Arguments:

```json
{"sql_query": "UPDATE dev.orders SET status = 'archived' WHERE id = 42", "database_name": "agent_dev"}
```

Save SQL for later use:

Action: `write_sql_file`

Arguments:

```json
{"filename": "orders_archive.sql", "content": "UPDATE dev.orders SET status = 'archived' WHERE id = 42;"}
```

## Completion

Return database, schema, table, exact SQL, validation result, dry-run result for writes, row count
or result summary, draft path if produced, and any blocker that needs user input.
