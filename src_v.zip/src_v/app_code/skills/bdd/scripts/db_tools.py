import importlib
import json
import logging
import os
from collections import defaultdict
from contextlib import contextmanager
from fnmatch import fnmatch
from typing import Any

import psycopg
import psycopg.errors
from psycopg.rows import dict_row

from .db_config import DB_CONFIG, DB_TYPE, normalize_db_type

SYSTEM_SCHEMAS = {"information_schema"}
SYSTEM_SCHEMA_PREFIXES = ("pg_", "_aiven")
SYSTEM_DATABASE_PREFIXES = ("_aiven",)
FAST_SCHEMA_CONTEXT_ENABLED_ENV = "BDD_FAST_SCHEMA_CONTEXT_ENABLED"
FAST_SCHEMA_CONTEXT_WHITELIST_ENV = "BDD_FAST_SCHEMA_CONTEXT_WHITELIST"
FAST_SCHEMA_CONTEXT_BLACKLIST_ENV = "BDD_FAST_SCHEMA_CONTEXT_BLACKLIST"

DIALECT_LABELS = {
    "postgresql": "PostgreSQL",
    "bigquery": "BigQuery Standard SQL",
    "teradata": "Teradata SQL",
    "mysql": "MySQL SQL",
    "snowflake": "Snowflake SQL",
}


class MissingDatabaseDependency(RuntimeError):
    pass


def current_db_type() -> str:
    return normalize_db_type(os.getenv("BDD_DB_TYPE") or DB_TYPE)


def current_sql_dialect() -> str:
    return DIALECT_LABELS.get(current_db_type(), current_db_type().upper())


def get_database_context() -> dict[str, Any]:
    return {
        "type": current_db_type(),
        "dialect": current_sql_dialect(),
        "database": default_database(),
        "schema": default_schema(),
    }


def default_database() -> str | None:
    db_type = current_db_type()
    if db_type == "bigquery":
        return DB_CONFIG.get("bigquery_project")
    if db_type == "snowflake":
        return DB_CONFIG.get("snowflake_database")
    if db_type == "teradata":
        return DB_CONFIG.get("teradata_database")
    return DB_CONFIG.get("database") or DB_CONFIG.get("dbname")


def default_schema() -> str | None:
    db_type = current_db_type()
    if db_type == "bigquery":
        return DB_CONFIG.get("bigquery_dataset")
    if db_type == "snowflake":
        return DB_CONFIG.get("snowflake_schema")
    return DB_CONFIG.get("schema")


def _require_package(import_name: str, install_name: str):
    try:
        return importlib.import_module(import_name)
    except ImportError as exc:
        raise MissingDatabaseDependency(
            f"Missing dependency '{install_name}' for BDD_DB_TYPE={current_db_type()}. "
            f"Install it or switch BDD_DB_TYPE."
        ) from exc


def _without_empty_values(values: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in values.items() if value not in {None, ""}}


# Establishes a connection to the configured business database.
def get_connection():
    db_type = current_db_type()
    if db_type == "postgresql":
        return psycopg.connect(**_without_empty_values({
            "dbname": DB_CONFIG.get("database"),
            "user": DB_CONFIG.get("user"),
            "password": DB_CONFIG.get("password"),
            "host": DB_CONFIG.get("host"),
            "port": DB_CONFIG.get("port"),
            "sslmode": DB_CONFIG.get("sslmode"),
            "connect_timeout": 10,
        }))
    if db_type == "mysql":
        connector = _require_package("mysql.connector", "mysql-connector-python")
        return connector.connect(**_without_empty_values({
            "host": DB_CONFIG.get("host"),
            "port": DB_CONFIG.get("port"),
            "user": DB_CONFIG.get("user"),
            "password": DB_CONFIG.get("password"),
            "database": DB_CONFIG.get("database"),
            "connection_timeout": 10,
        }))
    if db_type == "teradata":
        teradatasql = _require_package("teradatasql", "teradatasql")
        return teradatasql.connect(**_without_empty_values({
            "host": DB_CONFIG.get("teradata_host"),
            "user": DB_CONFIG.get("teradata_user"),
            "password": DB_CONFIG.get("teradata_password"),
            "database": DB_CONFIG.get("teradata_database"),
        }))
    if db_type == "snowflake":
        snowflake_connector = _require_package("snowflake.connector", "snowflake-connector-python")
        kwargs = {
            "account": DB_CONFIG.get("snowflake_account"),
            "user": DB_CONFIG.get("snowflake_user"),
            "password": DB_CONFIG.get("snowflake_password"),
            "database": DB_CONFIG.get("snowflake_database"),
            "schema": DB_CONFIG.get("snowflake_schema"),
            "warehouse": DB_CONFIG.get("snowflake_warehouse"),
            "role": DB_CONFIG.get("snowflake_role"),
        }
        return snowflake_connector.connect(**{k: v for k, v in kwargs.items() if v})
    raise ValueError(f"BDD_DB_TYPE={db_type} does not use a DB-API connection")


def _bigquery_client():
    bigquery = _require_package("google.cloud.bigquery", "google-cloud-bigquery")
    credentials_json = DB_CONFIG.get("bigquery_service_account_json")
    project = DB_CONFIG.get("bigquery_project")
    if credentials_json:
        service_account = _require_package(
            "google.oauth2.service_account", "google-auth"
        )
        info = json.loads(credentials_json)
        credentials = service_account.Credentials.from_service_account_info(info)
        return bigquery.Client(project=project or info.get("project_id"), credentials=credentials)
    return bigquery.Client(project=project)


# Simple test function to verify connection
def test_connection():
    try:
        if current_db_type() == "bigquery":
            _bigquery_client().query("SELECT 1").result()
        else:
            with get_connection() as _:
                pass
        logging.info("Connection successful for %s", current_sql_dialect())
    except Exception as e:
        logging.error("Connection ERROR: %s", e)


def safe_close(conn):
    if conn:
        try:
            conn.close()
        except Exception:
            pass


@contextmanager
def _cursor(conn, dict_rows: bool = False):
    db_type = current_db_type()
    if db_type == "postgresql" and dict_rows:
        with conn.cursor(row_factory=dict_row) as cur:
            yield cur
        return
    cur = conn.cursor()
    try:
        yield cur
    finally:
        try:
            cur.close()
        except Exception:
            pass


def _rows_to_dicts(cursor, rows: list[Any]) -> tuple[list[str], list[dict[str, Any]]]:
    columns = [desc[0] for desc in cursor.description or []]
    result_rows = []
    for row in rows:
        if isinstance(row, dict):
            result_rows.append(dict(row))
        else:
            result_rows.append(dict(zip(columns, row)))
    return columns, result_rows


def _is_system_schema(schema_name: str) -> bool:
    return schema_name in SYSTEM_SCHEMAS or schema_name.startswith(SYSTEM_SCHEMA_PREFIXES)


def _is_system_database(database_name: str) -> bool:
    return database_name.startswith(SYSTEM_DATABASE_PREFIXES)


def _is_fast_schema_context_enabled() -> bool:
    return os.getenv(FAST_SCHEMA_CONTEXT_ENABLED_ENV, "false").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _parse_filter_entries(raw_value: str, env_name: str) -> list[dict[str, str]]:
    if not raw_value.strip():
        return []
    try:
        parsed_value = json.loads(raw_value)
    except json.JSONDecodeError:
        logging.warning("[%s] Invalid JSON value: %s", env_name, raw_value)
        return []
    if not isinstance(parsed_value, list):
        logging.warning("[%s] Expected a JSON list, got %s", env_name, type(parsed_value).__name__)
        return []
    normalized_entries: list[dict[str, str]] = []
    for idx, entry in enumerate(parsed_value):
        if not isinstance(entry, dict):
            logging.warning("[%s] Entry %s is not an object: %s", env_name, idx, entry)
            continue
        database_name = str(entry.get("database", "")).strip()
        if not database_name:
            logging.warning("[%s] Entry %s is missing 'database': %s", env_name, idx, entry)
            continue
        table_name = str(entry.get("table", "*")).strip() or "*"
        schema_name = str(entry.get("schema", "*")).strip() or "*"
        normalized_entries.append({"database": database_name, "schema": schema_name, "table": table_name})
    return normalized_entries


def get_fast_schema_context_settings() -> dict[str, bool | list[dict[str, str]]]:
    return {
        "enabled": _is_fast_schema_context_enabled(),
        "whitelist": _parse_filter_entries(os.getenv(FAST_SCHEMA_CONTEXT_WHITELIST_ENV, ""), FAST_SCHEMA_CONTEXT_WHITELIST_ENV),
        "blacklist": _parse_filter_entries(os.getenv(FAST_SCHEMA_CONTEXT_BLACKLIST_ENV, ""), FAST_SCHEMA_CONTEXT_BLACKLIST_ENV),
    }


def _matches_context_rule(database_name: str, schema_name: str, table_name: str, rule: dict[str, str]) -> bool:
    return (
        fnmatch(database_name, rule["database"])
        and fnmatch(schema_name, rule.get("schema", "*"))
        and fnmatch(table_name, rule.get("table", "*"))
    )


def should_include_table_in_fast_context(database_name: str, schema_name: str, table_name: str, whitelist: list[dict[str, str]], blacklist: list[dict[str, str]]) -> bool:
    if any(_matches_context_rule(database_name, schema_name, table_name, rule) for rule in blacklist):
        return False
    if not whitelist:
        return True
    return any(_matches_context_rule(database_name, schema_name, table_name, rule) for rule in whitelist)


def _format_context_rules(rules: list[dict[str, str]]) -> str:
    return "[]" if not rules else json.dumps(rules, ensure_ascii=False)


def _scan_database_table_structures(database_name: str) -> dict[str, str | list[dict[str, Any]]]:
    db_type = current_db_type()
    if db_type == "postgresql":
        query = """
        SELECT c.table_schema, c.table_name, c.ordinal_position, c.column_name, c.data_type
        FROM information_schema.columns c
        JOIN information_schema.tables t
            ON t.table_schema = c.table_schema AND t.table_name = c.table_name
        WHERE t.table_type = 'BASE TABLE'
          AND c.table_schema <> 'information_schema'
          AND c.table_schema NOT LIKE 'pg_%'
          AND c.table_schema NOT LIKE '_aiven%'
        ORDER BY c.table_schema, c.table_name, c.ordinal_position;
        """
        conn = None
        try:
            conn = get_connection_as(DB_CONFIG["user"], db_name=database_name)
            grouped_tables: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
            with _cursor(conn, dict_rows=True) as cur:
                cur.execute(query)
                for row in cur.fetchall():
                    schema_name = row["table_schema"]
                    if _is_system_schema(schema_name):
                        continue
                    grouped_tables[(schema_name, row["table_name"])].append({"column_name": row["column_name"], "data_type": row["data_type"]})
            tables = [{"schema": s, "table": t, "columns": cols} for (s, t), cols in grouped_tables.items()]
            return {"status": "success", "data": tables}
        except Exception as e:
            return {"status": "error", "message": str(e)}
        finally:
            safe_close(conn)
    if db_type == "teradata":
        conn = None
        try:
            conn = get_connection_as(DB_CONFIG.get("user"), db_name=database_name)
            grouped_tables: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
            with _cursor(conn) as cur:
                cur.execute(
                    """
                    SELECT DatabaseName, TableName, ColumnName, ColumnType
                    FROM DBC.ColumnsV
                    WHERE DatabaseName = ?
                    ORDER BY TableName, ColumnId
                    """,
                    (database_name,),
                )
                for row in cur.fetchall():
                    schema_name = str(row[0]).strip()
                    table_name = str(row[1]).strip()
                    grouped_tables[(schema_name, table_name)].append(
                        {"column_name": str(row[2]).strip(), "data_type": str(row[3]).strip()}
                    )
            tables = [
                {"schema": schema, "table": table, "columns": columns}
                for (schema, table), columns in grouped_tables.items()
            ]
            return {"status": "success", "data": tables}
        except Exception as e:
            return {"status": "error", "message": str(e)}
        finally:
            safe_close(conn)
    schema = default_schema() or "*"
    tables_result = list_tables(schema=schema, database_name=database_name)
    if tables_result.get("status") != "success":
        return tables_result
    tables = []
    for table_name in tables_result.get("data", []):
        schema_result = get_table_schema(schema, table_name, database_name=database_name)
        if schema_result.get("status") == "success":
            tables.append({"schema": schema, "table": table_name, "columns": schema_result.get("data", [])})
    return {"status": "success", "data": tables}


def build_fast_schema_context() -> dict[str, Any]:
    settings = get_fast_schema_context_settings()
    if not settings["enabled"]:
        return {"status": "disabled", "message": "Fast schema context is disabled.", "context": "", "settings": settings}
    databases_result = list_databases()
    if databases_result["status"] != "success":
        return {"status": "error", "message": f"Unable to list databases for fast schema scan: {databases_result.get('message', 'Unknown error.')}", "context": "", "settings": settings}
    whitelist = settings["whitelist"]
    blacklist = settings["blacklist"]
    lines = [
        "[Fast Schema Mode]",
        f"SQL language: {current_sql_dialect()}",
        "A Python pre-scan has already collected the schema map for this BDD turn.",
        "Use the schema map below directly for table and column names.",
        "Do not call get_table_structure for tables already present in this injected schema map.",
        "Whitelist/blacklist below affect only injected context, not runtime DB access.",
        "Whitelist (context only): " + ("ALL databases/tables except blacklist" if not whitelist else _format_context_rules(whitelist)),
        f"Blacklist (context only): {_format_context_rules(blacklist)}",
    ]
    databases = [db for db in databases_result.get("data", []) if not _is_system_database(str(db))]
    included_tables_count = 0
    warnings: list[str] = []
    for database_name in databases:
        scan_result = _scan_database_table_structures(database_name)
        if scan_result["status"] != "success":
            warnings.append(f"- Database '{database_name}' could not be scanned: {scan_result.get('message', 'Unknown error.')}")
            continue
        tables_by_schema: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for table_info in scan_result.get("data", []):
            schema_name = str(table_info["schema"])
            table_name = str(table_info["table"])
            if should_include_table_in_fast_context(database_name, schema_name, table_name, whitelist, blacklist):
                tables_by_schema[schema_name].append(table_info)
        if not tables_by_schema:
            continue
        lines.append("")
        lines.append(f"Database: {database_name}")
        for schema_name in sorted(tables_by_schema):
            lines.append(f"Schema: {schema_name}")
            for table_info in sorted(tables_by_schema[schema_name], key=lambda item: item["table"]):
                lines.append(f"Table: {table_info['table']}")
                for column in table_info["columns"]:
                    lines.append(f"  - {column.get('column_name')} ({column.get('data_type')})")
                included_tables_count += 1
    if warnings:
        lines.append("")
        lines.append("Fast scan warnings:")
        lines.extend(warnings)
    if included_tables_count == 0:
        lines.append("")
        lines.append("No business tables were selected for fast schema context after whitelist/blacklist filtering.")
    lines.extend([
        "",
        "Use this injected schema map directly. Generate SQL from it without repeating schema discovery.",
        "If the user asks for a table or column that is absent from this map, ask for clarification or use discovery only for the missing object.",
    ])
    return {"status": "success", "message": f"Fast schema context built with {included_tables_count} tables.", "context": "\n".join(lines), "settings": settings}


# Function implemented for testing different user roles
def get_connection_as(user_role=DB_CONFIG.get("user"), db_name=None):
    if current_db_type() != "postgresql":
        return get_connection()
    target_dbname = db_name if db_name is not None else DB_CONFIG.get("database")
    return psycopg.connect(**_without_empty_values({
        "dbname": target_dbname,
        "user": DB_CONFIG.get("user"),
        "password": DB_CONFIG.get("password"),
        "host": DB_CONFIG.get("host"),
        "port": DB_CONFIG.get("port"),
        "sslmode": DB_CONFIG.get("sslmode"),
        "connect_timeout": 10,
    }))


def list_tables(schema=None, database_name=None):
    db_type = current_db_type()
    schema = schema or default_schema()
    database_name = database_name or default_database()
    conn = None
    try:
        if db_type == "bigquery":
            client = _bigquery_client()
            dataset = schema or DB_CONFIG.get("bigquery_dataset")
            tables = [table.table_id for table in client.list_tables(f"{database_name}.{dataset}")]
            return {"status": "success", "data": tables, "dialect": current_sql_dialect()}
        conn = get_connection_as(DB_CONFIG.get("user"), db_name=database_name)
        with _cursor(conn) as cur:
            if db_type == "mysql":
                cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = %s ORDER BY table_name", (database_name,))
            elif db_type == "teradata":
                cur.execute("SELECT TableName FROM DBC.TablesV WHERE DatabaseName = ? ORDER BY TableName", (schema or database_name,))
            elif db_type == "snowflake":
                cur.execute("SELECT table_name FROM information_schema.tables WHERE table_catalog = %s AND table_schema = %s ORDER BY table_name", (database_name, schema))
            else:
                cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = %s ORDER BY table_name", (schema,))
            return {"status": "success", "data": [r[0] for r in cur.fetchall()], "dialect": current_sql_dialect()}
    except Exception as e:
        logging.error("Error while listing tables", exc_info=True)
        return {"status": "error", "message": str(e), "dialect": current_sql_dialect()}
    finally:
        safe_close(conn)


def list_databases():
    db_type = current_db_type()
    conn = None
    try:
        if db_type == "bigquery":
            return {"status": "success", "data": [DB_CONFIG.get("bigquery_project")], "dialect": current_sql_dialect()}
        if db_type in {"mysql", "teradata"}:
            return {"status": "success", "data": [default_database()], "dialect": current_sql_dialect()}
        conn = get_connection_as(DB_CONFIG.get("user"))
        with _cursor(conn) as cur:
            if db_type == "snowflake":
                cur.execute("SHOW DATABASES")
                return {"status": "success", "data": [row[1] for row in cur.fetchall()], "dialect": current_sql_dialect()}
            else:
                cur.execute("SELECT datname FROM pg_database WHERE datistemplate = false")
            return {"status": "success", "data": [r[0] for r in cur.fetchall()], "dialect": current_sql_dialect()}
    except Exception as e:
        logging.error("Error listing databases", exc_info=True)
        return {"status": "error", "message": str(e), "dialect": current_sql_dialect()}
    finally:
        safe_close(conn)


def list_schemas(database_name=None):
    db_type = current_db_type()
    database_name = database_name or default_database()
    conn = None
    try:
        if db_type == "bigquery":
            client = _bigquery_client()
            datasets = [dataset.dataset_id for dataset in client.list_datasets(project=database_name)]
            return {"status": "success", "data": datasets, "dialect": current_sql_dialect()}
        if db_type == "teradata":
            return {
                "status": "success",
                "data": [default_schema() or database_name],
                "dialect": current_sql_dialect(),
            }
        conn = get_connection_as(DB_CONFIG.get("user"), db_name=database_name)
        with _cursor(conn) as cur:
            if db_type == "mysql":
                return {"status": "success", "data": [database_name], "dialect": current_sql_dialect()}
            if db_type == "snowflake":
                cur.execute("SELECT schema_name FROM information_schema.schemata WHERE catalog_name = %s ORDER BY schema_name", (database_name,))
            else:
                cur.execute("SELECT schema_name FROM information_schema.schemata ORDER BY schema_name")
            return {"status": "success", "data": [r[0] for r in cur.fetchall()], "dialect": current_sql_dialect()}
    except Exception as e:
        logging.error("Error listing schemas", exc_info=True)
        return {"status": "error", "message": str(e), "dialect": current_sql_dialect()}
    finally:
        safe_close(conn)


def _is_read_query(sql_query: str) -> bool:
    cleaned = sql_query.strip().lower()
    return cleaned.startswith(("select", "with", "values", "show", "describe", "desc"))


def execute_select_query(sql_query, database_name=None, limit=100):
    try:
        limit = max(1, int(limit))
    except (TypeError, ValueError):
        limit = 100
    if not _is_read_query(sql_query):
        return {"status": "error", "message": "Only read-only SELECT/WITH/SHOW/DESCRIBE queries are allowed.", "dialect": current_sql_dialect()}
    db_type = current_db_type()
    database_name = database_name or default_database()
    conn = None
    try:
        if db_type == "bigquery":
            client = _bigquery_client()
            job_config_module = _require_package("google.cloud.bigquery", "google-cloud-bigquery")
            job_config = job_config_module.QueryJobConfig(maximum_bytes_billed=10485760)
            query_job = client.query(sql_query, job_config=job_config)
            rows_iter = query_job.result(max_results=limit)
            rows = [dict(row.items()) for row in rows_iter]
            columns = list(rows[0].keys()) if rows else []
            return {"status": "success", "data": {"columns": columns, "rows": rows, "row_count": len(rows), "is_result_length_limited_by_tool": "Yes" if len(rows) == limit else "No"}, "dialect": current_sql_dialect()}
        conn = get_connection_as(DB_CONFIG.get("user"), db_name=database_name)
        if db_type == "postgresql":
            conn.autocommit = False
        with _cursor(conn) as cur:
            if db_type == "postgresql":
                cur.execute("SET SESSION CHARACTERISTICS AS TRANSACTION READ ONLY;")
            cur.execute(sql_query)
            if cur.description is None:
                return {"status": "success", "data": {"columns": [], "rows": [], "row_count": 0, "is_result_length_limited_by_tool": "No"}, "message": "Query executed but returned no rows.", "dialect": current_sql_dialect()}
            rows = cur.fetchmany(limit)
            columns, results = _rows_to_dicts(cur, rows)
            return {"status": "success", "data": {"columns": columns, "rows": results, "row_count": len(results), "is_result_length_limited_by_tool": "Yes" if len(results) == limit else "No"}, "dialect": current_sql_dialect()}
    except Exception as e:
        logging.error("SQL error during read query", exc_info=True)
        return {"status": "error", "message": str(e), "dialect": current_sql_dialect()}
    finally:
        if conn:
            try:
                conn.rollback()
            except Exception:
                pass
            safe_close(conn)


def get_table_schema(schema_name, table_name, database_name=None):
    db_type = current_db_type()
    database_name = database_name or default_database()
    schema_name = schema_name or default_schema()
    conn = None
    try:
        if db_type == "bigquery":
            client = _bigquery_client()
            table = client.get_table(f"{database_name}.{schema_name}.{table_name}")
            columns = [{"column_name": field.name, "data_type": field.field_type, "is_nullable": "Yes" if field.mode != "REQUIRED" else "No"} for field in table.schema]
            return {"status": "success", "data": columns, "dialect": current_sql_dialect()}
        conn = get_connection_as(DB_CONFIG.get("user"), db_name=database_name)
        with _cursor(conn, dict_rows=db_type == "postgresql") as cur:
            if db_type == "mysql":
                cur.execute("SELECT column_name, data_type, is_nullable, column_default FROM information_schema.columns WHERE table_schema = %s AND table_name = %s ORDER BY ordinal_position", (database_name, table_name))
            elif db_type == "teradata":
                cur.execute("SELECT ColumnName, ColumnType, Nullable FROM DBC.ColumnsV WHERE DatabaseName = ? AND TableName = ? ORDER BY ColumnId", (schema_name or database_name, table_name))
            elif db_type == "snowflake":
                cur.execute("SELECT column_name, data_type, is_nullable, column_default FROM information_schema.columns WHERE table_catalog = %s AND table_schema = %s AND table_name = %s ORDER BY ordinal_position", (database_name, schema_name, table_name.upper()))
            else:
                cur.execute("SELECT column_name, data_type, is_nullable, column_default FROM information_schema.columns WHERE table_schema = %s AND table_name = %s ORDER BY ordinal_position", (schema_name, table_name))
            rows = cur.fetchall()
            columns = []
            for row in rows:
                if isinstance(row, dict):
                    columns.append({"column_name": row.get("column_name"), "data_type": row.get("data_type"), "is_nullable": "Yes" if str(row.get("is_nullable", "")).upper() in {"YES", "Y"} else "No", "default": row.get("column_default")})
                else:
                    columns.append({"column_name": row[0], "data_type": row[1], "is_nullable": "Yes" if len(row) > 2 and str(row[2]).upper() in {"YES", "Y"} else "No", "default": row[3] if len(row) > 3 else None})
        return {"status": "success", "data": columns, "dialect": current_sql_dialect()}
    except Exception as e:
        logging.error("Error retrieving table schema", exc_info=True)
        return {"status": "error", "message": str(e), "exception_type": repr(e), "dialect": current_sql_dialect()}
    finally:
        safe_close(conn)


def check_sql_syntax(sql_query: str, database_name: str | None = None):
    db_type = current_db_type()
    database_name = database_name or default_database()
    conn = None
    try:
        if db_type == "bigquery":
            client = _bigquery_client()
            bigquery = _require_package("google.cloud.bigquery", "google-cloud-bigquery")
            job_config = bigquery.QueryJobConfig(dry_run=True, use_query_cache=False)
            client.query(sql_query, job_config=job_config)
            return {"status": "success", "message": "BigQuery SQL syntax is valid.", "dialect": current_sql_dialect()}
        conn = get_connection_as(user_role=DB_CONFIG.get("user"), db_name=database_name)
        with _cursor(conn) as cur:
            sql_lower = sql_query.strip().lower()
            if db_type == "postgresql":
                if sql_lower.startswith(("alter", "create", "drop", "truncate", "rename")):
                    cur.execute("BEGIN;")
                    cur.execute(sql_query)
                    cur.execute("ROLLBACK;")
                    return {"status": "success", "message": "PostgreSQL DDL syntax is valid.", "dialect": current_sql_dialect()}
                cur.execute(f"EXPLAIN {sql_query}")
            elif db_type == "mysql":
                if not _is_read_query(sql_query):
                    return {
                        "status": "unsupported",
                        "message": "MySQL write syntax validation is handled by dry-run rollback, not direct syntax execution.",
                        "dialect": current_sql_dialect(),
                    }
                cur.execute(f"EXPLAIN {sql_query}")
            elif db_type == "snowflake":
                if not _is_read_query(sql_query):
                    return {
                        "status": "unsupported",
                        "message": "Snowflake write syntax validation is handled by dry-run rollback, not direct syntax execution.",
                        "dialect": current_sql_dialect(),
                    }
                cur.execute(f"EXPLAIN USING TEXT {sql_query}")
            else:
                if not _is_read_query(sql_query):
                    return {
                        "status": "unsupported",
                        "message": f"{current_sql_dialect()} write syntax validation is handled by dry-run rollback, not direct syntax execution.",
                        "dialect": current_sql_dialect(),
                    }
                cur.execute(f"EXPLAIN {sql_query}")
        return {"status": "success", "message": f"{current_sql_dialect()} syntax is valid.", "dialect": current_sql_dialect()}
    except Exception as e:
        return {"status": "error", "message": str(e), "exception_type": repr(e), "dialect": current_sql_dialect()}
    finally:
        if conn:
            try:
                conn.rollback()
            except Exception:
                pass
            safe_close(conn)


def execute_dry_run(sql_query: str, database_name: str | None = None):
    if "commit" in sql_query.lower() or "rollback" in sql_query.lower():
        return {"status": "error", "message": "COMMIT/ROLLBACK not allowed in dry run.", "dialect": current_sql_dialect()}
    db_type = current_db_type()
    if db_type == "bigquery":
        return check_sql_syntax(sql_query, database_name)
    conn = None
    try:
        conn = get_connection_as(user_role=DB_CONFIG.get("user"), db_name=database_name or default_database())
        if hasattr(conn, "autocommit"):
            try:
                conn.autocommit = False
            except Exception:
                try:
                    conn.autocommit(False)
                except Exception:
                    pass
        with _cursor(conn) as cur:
            cur.execute(sql_query)
            cols = [desc[0] for desc in cur.description] if cur.description else []
            try:
                conn.rollback()
            except Exception:
                pass
            return {"status": "success", "message": "Dry run successful. The request was executed and rolled back.", "columns": cols, "dialect": current_sql_dialect()}
    except Exception as e:
        return {"status": "error", "message": str(e), "dialect": current_sql_dialect()}
    finally:
        safe_close(conn)


def execute_write_query(sql_query: str, database_name: str | None = None):
    if "commit" in sql_query.lower():
        return {"status": "error", "message": "Manual COMMIT is not allowed.", "dialect": current_sql_dialect()}
    db_type = current_db_type()
    database_name = database_name or default_database()
    conn = None
    try:
        if db_type == "bigquery":
            client = _bigquery_client()
            job = client.query(sql_query)
            job.result()
            return {"status": "success", "message": "BigQuery query executed.", "rows_affected": getattr(job, "num_dml_affected_rows", "N/A"), "dialect": current_sql_dialect()}
        conn = get_connection_as(user_role=DB_CONFIG.get("user"), db_name=database_name)
        if hasattr(conn, "autocommit"):
            conn.autocommit = True
        with _cursor(conn) as cur:
            cur.execute(sql_query)
            status = getattr(cur, "statusmessage", None) or f"rowcount={getattr(cur, 'rowcount', 'N/A')}"
            rows_affected = getattr(cur, "rowcount", "N/A")
        return {"status": "success", "message": f"Query executed: {status}", "rows_affected": rows_affected, "dialect": current_sql_dialect()}
    except Exception as e:
        logging.error("Unexpected error during write query", exc_info=True)
        return {"status": "error", "message": str(e), "dialect": current_sql_dialect()}
    finally:
        safe_close(conn)
