import logging
from pathlib import Path

import psycopg

from app_code.skills.bdd.scripts.db_config import DB_CONFIG


def create_database():
    """Creation of the database agent_dev if she don't exists."""
    try:
        # Connect to the default database to create a new one
        with psycopg.connect(
            dbname="postgres",
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            host=DB_CONFIG["host"],
            port=DB_CONFIG["port"],
        ) as conn:
            # Autocommit mode to execute CREATE DATABASE command
            conn.autocommit = True

            with conn.cursor() as cursor:
                # Creation of the database
                cursor.execute(
                    "SELECT 1 FROM pg_database WHERE datname = %s;",
                    (DB_CONFIG["dbname"],),
                )
                exists = cursor.fetchone()

                if not exists:
                    cursor.execute(f"CREATE DATABASE {DB_CONFIG['dbname']};")
                    logging.info(f"Database '{DB_CONFIG['dbname']}' created successfully.")
                else:
                    logging.info(f"The database '{DB_CONFIG['dbname']}' already exists.")

    except Exception as e:
        logging.error(f"Error during the database creation : {e}")


def init_schema_and_tables():
    """Initialization of the schema and tables if they don't exist."""
    sql_file = Path(__file__).resolve().parents[3] / "init_db.sql"
    # Ensure the SQL file exists for reading the schema and table definitions

    try:
        # Connect to the target database
        with psycopg.connect(**DB_CONFIG) as conn:
            conn.autocommit = True

            with conn.cursor() as cursor:
                # Read the SQL script from the file
                with open(sql_file, "r", encoding="utf-8") as file:
                    sql_script = file.read()

                # Execute the SQL script
                cursor.execute(sql_script)
                logging.info("Schema and tables initialized successfully.")

    except Exception as e:
        logging.error(f"Error during schema and tables initialization : {e}")


# Agent test base :
def create_test_database():
    """Create a separate database for testing purposes."""
    try:
        # Connect to the default database to create a new one
        with psycopg.connect(
            dbname="postgres",
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            host=DB_CONFIG["host"],
            port=DB_CONFIG["port"],
        ) as conn:
            # Autocommit mode to execute CREATE DATABASE command
            conn.autocommit = True

            with conn.cursor() as cursor:
                # Creation of the database
                cursor.execute("SELECT 1 FROM pg_database WHERE datname='agent_test';")
                exists = cursor.fetchone()

                if not exists:
                    cursor.execute("CREATE DATABASE agent_test OWNER postgres")
                    logging.info("Database 'agent_test' created successfully.")
                else:
                    logging.info("The database 'agent_test' already exists.")

    except Exception as e:
        logging.error("Error during the database creation: %s", repr(e))


def init_schemas_and_tables_aiven():
    """Initialize schema + tables inside defaultdb."""
    sql_file = Path(__file__).resolve().parent / "db_resources/init_db_aiven.sql"

    try:
        with psycopg.connect(**DB_CONFIG) as conn:
            conn.autocommit = True

            with conn.cursor() as cursor:
                with open(sql_file, "r", encoding="utf-8") as file:
                    sql_script = file.read()

                cursor.execute(sql_script)
                logging.info("Schemas and tables initialized successfully.")

                # Vérification : la table dev.users existe-t-elle ?
                cursor.execute(
                    "SELECT table_name FROM information_schema.tables WHERE table_schema='dev'"
                    " AND table_name='users';"
                )
                tables = [row[0] for row in cursor.fetchall()]
                if "users" in tables:
                    print(f"Tables trouvées dans le schéma dev: {tables}")
                    logging.info("La table 'dev.users' existe bien.")
                else:
                    logging.warning("La table 'dev.users' n'existe pas.")

    except Exception as e:
        logging.error(f"Error during schema and table initialization : {e}")


if __name__ == "__main__":
    # create_database()
    # create_test_database()
    # init_schema_and_tables()
    init_schemas_and_tables_aiven()
