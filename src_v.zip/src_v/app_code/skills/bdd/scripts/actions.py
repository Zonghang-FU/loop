"""
BDD agent file, containing initial prompt, bdd agent specific tools
and bdd node creation function.
"""

import json
import logging
import os
import re
from pathlib import Path
from typing import Annotated, Optional

from langchain_core.tools import InjectedToolArg, tool

from app_code.skills.bdd.scripts import db_tools
from app_code.skills.bdd.scripts.draft_files import get_session_draft_dir
from app_code.skills_runtime.loader import resolve_skill_name
from app_code.skills_runtime.structs import NodeNames, ToolNames, WorkflowState

SUCCESSFUL_DRY_RUNS: set[tuple[str, str]] = set()


def _dry_run_key(sql_query: str, database_name: str) -> tuple[str, str]:
    return (" ".join(sql_query.split()).strip().lower(), database_name.strip().lower())


def _target_database(database_name: Optional[str] = None) -> str:
    return database_name or db_tools.default_database() or ""


def _dialect_context(extra: dict | None = None) -> dict:
    context = db_tools.get_database_context()
    if extra:
        context.update(extra)
    return context


def _select_result_max_rows() -> int:
    raw_value = os.getenv("SQL_RESULT_MAX_ROWS", "100")
    try:
        return max(1, int(raw_value))
    except ValueError:
        logging.warning(
            "Invalid SQL_RESULT_MAX_ROWS=%r; falling back to 100 rows.",
            raw_value,
        )
        return 100


BDD_ALLOWED_EXTENSIONS = {".sql"}


def _terminal_file_handoff(message: str, filename: str) -> tuple[str, dict[str, str | NodeNames]]:
    """Route non-SQL file work to terminal when that plugin-like skill is enabled."""

    if resolve_skill_name("terminal"):
        return message, {
            "next_agent": NodeNames.CODE_AGENT,
            "active_skill": "terminal",
            "context": (
                "The active BDD skill handled database work, but the requested file artifact "
                f"'{filename}' is not SQL. Continue with the terminal skill and use the previous "
                "tool-call arguments as the source content/path. Keep files in the current "
                "session draft directory."
            ),
        }
    return message, {
        "next_agent": NodeNames.USER_INPUT,
        "context": (
            "The requested artifact is not a SQL file and the terminal skill is not enabled, "
            "so this runtime cannot create it."
        ),
    }


# Helper Function for Sanity Check
def clean_sql_argument(sql_query: str) -> str:
    """
    Removes Markdown formatting (```sql ... ```) from the string if present.
    Acts as a safety net if the LLM ignores the system prompt instructions
    """
    if sql_query is None:
        return ""
    # Remove Markdown code block formatting if present
    cleaned_sql = re.sub(r"```(sql|postgresql)?", "", sql_query, flags=re.IGNORECASE)
    # Remove trailing ``` if any and extra spaces
    cleaned_sql = cleaned_sql.replace("```", "").strip()
    return cleaned_sql


# ---  Definition of BDD tools  ---


@tool(
    ToolNames.LIST_AVAILABLE_DATABASES,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def list_available_databases() -> tuple[str, dict[str, str | NodeNames]]:
    """
    Use this tool to list all databases accessible by the system.

    Returns:
        str: a message including number of databases found and their names.
    """

    logging.debug("-- Listing available databases tool --")
    result = db_tools.list_databases()

    if result["status"] == "success":
        dbs = result.get("data", [])
        formatted_response = f"Success : Found {len(dbs)} databases : {dbs}"
        context_msg = json.dumps(_dialect_context({"databases": dbs}), default=str)

    else:
        formatted_response = (
            f"Error while listing databases: {result.get('message', 'Unknown error.')}"
        )
        context_msg = formatted_response

    return formatted_response, {
        "next_agent": NodeNames.BDD_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.LIST_AVAILABLE_SCHEMAS,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def list_available_schemas(
    database_name: str = "",
) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Use this tool to list all schemas in a specific database.

    Args:
        database_name (str): The name of the database (eg: 'defaultdb').

    Returns:
        str: a message including number of schemas found and their names.
    """

    logging.debug("-- Listing available schemas tool --")
    database_name = _target_database(database_name)
    result = db_tools.list_schemas(database_name)
    if result["status"] == "success":
        schemas = result.get("data", [])
        formatted_response = f"Success: Found {len(schemas)} schemas: {schemas}"
        context_msg = json.dumps(_dialect_context({"schemas": schemas}), default=str)

    else:
        formatted_response = (
            f"Error while listing schemas: {result.get('message', 'Unknown error.')}"
        )
        context_msg = formatted_response

    return formatted_response, {
        "next_agent": NodeNames.BDD_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.LIST_AVAILABLE_TABLES,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def list_available_tables(
    database_name: str = "", schema_name: str = ""
) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Use this tool to list all tables in a specific schema.

    Args:
        database_name (str): The name of the database (eg: 'defaultdb').
        schema_name (str): The name of the schema (eg: 'dev', 'business').

    Returns:
        str: a message indicating the number of tables found and their names.
    """

    logging.debug("-- Listing available tables tool --")
    database_name = _target_database(database_name)
    schema_name = schema_name or db_tools.default_schema() or ""
    result = db_tools.list_tables(schema_name, database_name=database_name)

    if result["status"] == "success":
        tables = result.get("data", [])

        # This message will be visible to the LLM (readable AND usable).
        formatted_response = (
            f"Success: Found {len(tables)} tables in schema '{schema_name}': {tables}"
        )

        # This message will be passed in the 'context' of the next tool for the following flow
        #    (génération SQL → parsing automatique de la liste)
        context_msg = json.dumps(_dialect_context({"tables": tables}), default=str)
    else:
        formatted_response = (
            f"Error while listing tables: {result.get('message', 'Unknown error.')}"
        )
        context_msg = formatted_response

    return formatted_response, {
        "next_agent": NodeNames.BDD_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.VERIFY_SQL_SYNTAX,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def verify_sql_syntax(
    sql_query: str, database_name: str = ""
) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Use this tool to check the syntax of an SQL query BEFORE
    attempting a 'dry run' or execution.

    Args:
        sql_query (str): The complete SQL query to check.
        database_name (str): The name of the target database (default: 'defaultdb').

    Returns:
        str: a message indicating if the query's syntax is valid and
            syntax errors in the query if any where found.
    """

    logging.debug("-- Verifying SQL syntax tool --")

    # Sanity check on SQL argument
    sql_query = clean_sql_argument(sql_query)
    database_name = _target_database(database_name)
    # ---------------------------------------
    result = db_tools.check_sql_syntax(sql_query, database_name)
    status = result.get("status", "error")
    message = result.get("message", "Unknown error.")

    if status == "success":
        formatted_response = f"Syntax OK for query: {sql_query}."

    else:
        formatted_response = f"Syntax check returned status '{status}': {message}"

    context_msg = json.dumps(
        _dialect_context({"status": status, "message": message, "query": sql_query}),
        default=str,
    )

    return formatted_response, {
        "next_agent": NodeNames.BDD_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.TEST_SQL_MODIFICATION_DRY_RUN,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def test_sql_modification_dry_run(
    sql_query: str, database_name: str = ""
) -> tuple[str, dict[str, str | NodeNames]]:
    """
    This tool is MANDATORY before any writing. Executes the query in
    a transaction that will be rolled back. (ROLLBACK).
    Only the run real execution if the user explicitly asks for it.

    Args:
        sql_query (str): The modification request (INSERT, UPDATE, DELETE, etc.) to be tested.
        database_name (str): The name of the target database on which to perform the dry run.

    Returns:
        str: A message indicating dry run status.
    """

    logging.debug("-- Testing SQL modification dry run tool --")

    # Sanity check on SQL argument
    sql_query = clean_sql_argument(sql_query)
    database_name = _target_database(database_name)
    # ---------------------------------------
    result = db_tools.execute_dry_run(sql_query, database_name)

    if result["status"] == "success":
        SUCCESSFUL_DRY_RUNS.add(_dry_run_key(sql_query, database_name))
        formatted_response = (
            "Dry-run successful: no syntax or constraint errors detected."
            "No real execution has been performed."
        )
        columns = result.get("columns")
        # If the dry-run returned a column preview, the details are added to the response.
        context_msg = json.dumps(
            {
                **_dialect_context(),
                "status": "success",
                "message": "Dry-run executed (rolled back).",
                "columns": columns or [],
                "query": sql_query,
            },
            default=str,
        )
        if columns:
            formatted_response += f" Columns overview: {columns}"

    else:
        formatted_response = f"Dry-run failed: {result.get('message', 'Unknown error.')}"
        context_msg = json.dumps(
            {
                **_dialect_context(),
                "status": "error",
                "message": result.get("message", "Unknown error."),
                "query": sql_query,
            }
        )
    return formatted_response, {
        "next_agent": NodeNames.BDD_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.EXECUTE_SQL_MODIFICATION,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def execute_sql_modification(
    sql_query: Optional[str] = None,
    database_name: str = "",
) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Executes a write modification request (with COMMIT).
    DO NOT use without a successful dry run first.
    You must NOT prefix table names with the database name.
        e.g., use 'dev.sql_scripts' instead of 'defaultdb.dev.sql_scripts'
    Manual COMMIT statements are not allowed.(transactions are auto-committed)

    Args:
        sql_query (str): The SQL query to execute. If not provided, the query will be
                extracted from the `context` argument if available.
        database_name (str): The name of the target database (default: 'defaultdb').

    Returns:
        str: A message indicating the status of the SQL modification query.
    """

    logging.debug("-- Executing SQL modification tool --")

    if not sql_query:
        return "Error: SQL query is missing.", {
            "next_agent": NodeNames.BDD_AGENT,
            "context": "Error: No SQL provided.",
        }

    # Sanity check on SQL argument
    sql_query = clean_sql_argument(sql_query)
    database_name = _target_database(database_name)
    # ---------------------------------------

    # On vérifie si le LLM essaie de faire un SELECT via cet outil
    if sql_query.strip().lower().startswith("select"):
        return f"Error: Use {ToolNames.EXECUTE_READ_QUERY} for SELECT statements.", {
            "next_agent": NodeNames.BDD_AGENT,
            "context": "Error: Wrong tool usage.",
        }

    if _dry_run_key(sql_query, database_name) not in SUCCESSFUL_DRY_RUNS:
        return "Blocked: SQL modification requires a successful dry-run of the exact query first.", {
            "next_agent": NodeNames.BDD_AGENT,
            "context": json.dumps(
                {
                    **_dialect_context(),
                    "status": "blocked",
                    "message": "No successful dry-run found for the exact SQL query.",
                    "query": sql_query,
                }
            ),
        }

    result = db_tools.execute_write_query(sql_query, database_name)

    if result["status"] == "success":
        affected = result.get("rows_affected", "?")
        formatted_response = f"Success: SQL modification executed. Rows affected: {affected}"
        context_msg = json.dumps(
            _dialect_context({"status": "success", "rows_affected": affected, "query": sql_query}),
            default=str,
        )

    else:
        formatted_response = (
            f"Error executing SQL modification: {result.get('message', 'Unknown error.')}"
        )
        context_msg = json.dumps(
            {
                **_dialect_context(),
                "status": "error",
                "message": result.get("message", "Unknown error."),
                "query": sql_query,
            }
        )

    return formatted_response, {
        "next_agent": NodeNames.BDD_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.EXECUTE_READ_QUERY,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def execute_read_query(
    sql_query: str, database_name: str = ""
) -> tuple[str, dict[str, str | NodeNames]]:
    """Execute a read-only SQL query (SELECT) and return the results.

    This tool is for read-only queries. Use it to explore data or verify
    the state of the database before making modifications. A dry-run is not
    required for read-only SQL; if execution fails, return the database error
    so the model can correct the query and retry.

    Security:
        - Only SELECT queries are allowed.
        - Returned rows are limited by SQL_RESULT_MAX_ROWS at execution time.
        - Timeout after 30 seconds.

    Args:
        sql_query (str): The SELECT query to execute.
        database_name (str): The database to query (default: 'defaultdb').

    Returns:
        str: Query results as a formatted table or list.
    """

    logging.debug("-- Executing read query tool --")
    logging.debug(f"SQL Query: {sql_query}")

    # Sanity check on SQL argument
    sql_query = clean_sql_argument(sql_query)
    database_name = _target_database(database_name)
    max_rows = _select_result_max_rows()
    # ---------------------------------------
    result = db_tools.execute_select_query(
        sql_query=sql_query, database_name=database_name, limit=max_rows
    )

    if result["status"] == "success":
        data_dict = result.get("data", {}) or {}
        rows = data_dict.get("rows", [])
        rows_count = data_dict.get("row_count", len(rows))
        is_limited = data_dict.get("is_result_length_limited_by_tool", "No")
        columns = data_dict.get("columns", [])

        formatted_response = (
            f"Success: Query executed. Returned {rows_count} rows. Sample result: {rows}."
        )
        context_msg = json.dumps(
            {
                **_dialect_context(),
                "status": "success",
                "columns": columns,
                "rows": rows,
                "rows_returned": rows_count,
                "max_rows": max_rows,
                "is_result_length_limited_by_tool": is_limited,
                "query": sql_query,
            },
            default=str,
        )
    else:
        formatted_response = (
            f"Error executing read query: {result.get('message', 'Unknown error.')}"
        )
        context_msg = json.dumps(
            {
                **_dialect_context(),
                "status": "error",
                "message": result.get("message", "Unknown error."),
                "query": sql_query,
            }
        )

    return formatted_response, {
        "next_agent": NodeNames.BDD_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.GET_TABLE_STRUCTURE,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def get_table_structure(
    database_name: str = "", schema_name: str = "", table_name: str = ""
) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Use this tool to get the full structure of a specific database table.
    Always use this tool BEFORE generating any SQL query.
    Never guess column names.

    Args:
        database_name (str): The name of the database (eg: 'defaultdb').
        schema_name (str): The name of the schema (eg: 'dev', 'business').
        table_name (str): The name of the table (eg: 'sql_scripts').

    Returns:
        str: a message providing the table structure retrieval.
    """

    logging.debug("-- Getting table structure tool --")
    database_name = _target_database(database_name)
    schema_name = schema_name or db_tools.default_schema() or ""
    result = db_tools.get_table_schema(
        schema_name=schema_name, table_name=table_name, database_name=database_name
    )

    if result["status"] != "success":
        error_msg = result.get("message", "Unknown error.")
        return (
            f"Error getting structure for table '{schema_name}.{table_name}': {error_msg}",
            {
                "next_agent": NodeNames.BDD_AGENT,
                "context": {
                    **_dialect_context(),
                    "table": f"{schema_name}.{table_name}",
                    "error": error_msg,
                    "exception_type": result.get("exception_type", "N/A"),
                },
            },
        )

    columns_info = result.get("data", [])

    formatted_response = (
        f"Success : Table '{schema_name}.{table_name}' has {len(columns_info)} columns. "
        "Full column metadata has been retrieved."
    )

    logging.debug(f"Retrieved structure for table '{schema_name}.{table_name}': {columns_info}")

    return formatted_response, {
        "next_agent": NodeNames.BDD_AGENT,
        "context": {
            **_dialect_context(),
            "database": database_name,
            "schema": schema_name,
            "table": table_name,
            "columns": columns_info,
        },
    }


@tool(
    ToolNames.WRITE_SQL_FILE,
    parse_docstring=False,
    response_format="content_and_artifact",
)
def write_sql_file(
    filename: str, content: str, state: Annotated[dict, InjectedToolArg]
) -> tuple[str, dict[str, str | NodeNames]]:
    """Save a SQL script to the current session's draft directory.

    Args:
        filename (str): Name of the SQL file to create (e.g. 'migration_v2.sql').
        content (str): SQL content to write into the file.

    Returns:
        str: The draft path where the file was saved.
    """
    suffix = Path(filename).suffix.lower()
    if suffix not in BDD_ALLOWED_EXTENSIONS:
        return _terminal_file_handoff(
            "BDD skill only writes .sql files; switching to terminal for this file artifact.",
            filename,
        )

    session_id = str(state["session_id"]) if state else "unknown"
    try:
        file_path = get_session_draft_dir(session_id) / filename
        file_path.write_text(content, encoding="utf-8")
        return (
            f"SQL file saved: {file_path} ({len(content)} chars)",
            {"next_agent": NodeNames.BDD_AGENT, "context": {"draft_path": str(file_path)}},
        )
    except Exception as e:
        return f"Error writing SQL file: {e}", {"next_agent": NodeNames.BDD_AGENT}


@tool(
    ToolNames.READ_SQL_FILE,
    parse_docstring=False,
    response_format="content_and_artifact",
)
def read_sql_file(
    filename: str, state: Annotated[dict, InjectedToolArg]
) -> tuple[str, dict[str, str | NodeNames]]:
    """Read a SQL file from the current session's draft directory."""
    suffix = Path(filename).suffix.lower()
    if suffix not in BDD_ALLOWED_EXTENSIONS:
        return _terminal_file_handoff(
            "BDD skill only reads .sql files; switching to terminal for this file artifact.",
            filename,
        )

    session_id = str(state["session_id"]) if state else "unknown"
    try:
        file_path = get_session_draft_dir(session_id) / filename
        content = file_path.read_text(encoding="utf-8")
        return (
            f"SQL file read: draft/{session_id}/{filename} ({len(content)} chars)\n\n{content}",
            {"next_agent": NodeNames.BDD_AGENT},
        )
    except FileNotFoundError:
        return (
            f"File '{filename}' not found in draft/{session_id}/. Use list_draft_files first.",
            {"next_agent": NodeNames.BDD_AGENT},
        )
    except Exception as e:
        return f"Error reading SQL file: {e}", {"next_agent": NodeNames.BDD_AGENT}


skill_actions = {
    ToolNames.LIST_AVAILABLE_DATABASES: list_available_databases,
    ToolNames.LIST_AVAILABLE_SCHEMAS: list_available_schemas,
    ToolNames.LIST_AVAILABLE_TABLES: list_available_tables,
    ToolNames.VERIFY_SQL_SYNTAX: verify_sql_syntax,
    ToolNames.TEST_SQL_MODIFICATION_DRY_RUN: test_sql_modification_dry_run,
    ToolNames.EXECUTE_SQL_MODIFICATION: execute_sql_modification,
    ToolNames.GET_TABLE_STRUCTURE: get_table_structure,
    ToolNames.EXECUTE_READ_QUERY: execute_read_query,
    ToolNames.WRITE_SQL_FILE: write_sql_file,
    ToolNames.READ_SQL_FILE: read_sql_file,
}
