CREATE SCHEMA IF NOT EXISTS dev;

CREATE TABLE IF NOT EXISTS dev.sql_scripts (
    id SERIAL PRIMARY KEY,
    script_name VARCHAR(255),
    script_content TEXT,
    status VARCHAR(50),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS dev.sql_results (
    id SERIAL PRIMARY KEY,
    script_id INT REFERENCES dev.sql_scripts(id),
    result JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);
