import os

import psycopg

from app_code.runtime_paths import load_runtime_env

load_runtime_env()

DB_URI = (
    os.getenv("BDD_DATABASE_URL")
    or os.getenv("POSTGRESQLCONNSTR_BDD_DATABASE_URL")
    or ""
)

try:
    with psycopg.connect(DB_URI, connect_timeout=1) as conn:
        print("True")
except psycopg.errors.ConnectionTimeout as e:
    print(f"Error connecting to the database: {e}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
