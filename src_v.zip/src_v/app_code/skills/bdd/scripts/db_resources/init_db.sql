-- Static SQL script to initialize the database

-- Creation of the BDD Agent role
DO
$$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'agent_bdd_dev') THEN
        CREATE ROLE agent_bdd_dev LOGIN PASSWORD 'AgentBDD';
    END IF;
END
$$;

-- Creation of the Read-only role
DO
$$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'reader_only') THEN
        CREATE ROLE reader_only LOGIN PASSWORD 'Reader';
    END IF;
END
$$;

-- Creation of the schemas
CREATE SCHEMA IF NOT EXISTS dev AUTHORIZATION agent_bdd_dev;
CREATE SCHEMA IF NOT EXISTS logs AUTHORIZATION agent_bdd_dev;

-- Tables for BDD Agent
-- 1. Table of the SQL scripts managed or executed by the agent
CREATE TABLE IF NOT EXISTS dev.sql_scripts (
    id SERIAL PRIMARY KEY,
    script_name VARCHAR(255), -- Name of the script
    script_content TEXT, -- content of the script
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'draft' -- Script status : draft, tested, executed
);

-- 2. Table of the execution results
CREATE TABLE IF NOT EXISTS dev.sql_results (
    id SERIAL PRIMARY KEY,
    script_id INT REFERENCES dev.sql_scripts(id) ON DELETE CASCADE, -- Reference of the executed script(sql_scripts.id)
    executed_by VARCHAR(50), -- Name of the executing agent
    execution_mode VARCHAR(20) DEFAULT 'dry-run', -- Mode : dry-run or real
    execution_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    result_summary TEXT, -- Result summary (5 lines modified)
    success BOOLEAN -- Indicates if the query is execute without error
);

-- 3. Table of technical logs
CREATE TABLE IF NOT EXISTS logs.execution_logs (
    id SERIAL PRIMARY KEY,
    date_run TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    agent_name VARCHAR(50), -- Name of the agent who performed the action
    action_type VARCHAR(50), -- type of action (CREATE, UPDATE, EXECUTE, ERROR, ...)
    sql_snipet TEXT, -- Portion of the SQL executed by the agent (not the entire script)
    status VARCHAR(50), -- success, error, warning
    message TEXT -- error message detail or result
);

-- Access rights
-- The BDD Agent has total access to the environment "dev" and "logs"
GRANT CONNECT ON DATABASE agent_dev TO agent_bdd_dev;
-- Right of use on schemas
GRANT USAGE,  CREATE ON SCHEMA dev, logs TO agent_bdd_dev;
-- Rights on existing tables
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA dev TO agent_bdd_dev;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA logs TO agent_bdd_dev;
-- Default permissions for future tables
ALTER DEFAULT PRIVILEGES IN SCHEMA dev GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO agent_bdd_dev;
ALTER DEFAULT PRIVILEGES IN SCHEMA logs GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO agent_bdd_dev;

-- The Read-only agent has read only to all
GRANT CONNECT ON DATABASE agent_dev TO reader_only;
GRANT USAGE ON SCHEMA dev, logs TO reader_only;
GRANT SELECT ON ALL TABLES IN SCHEMA dev TO reader_only;
GRANT SELECT ON ALL TABLES IN SCHEMA logs TO reader_only;
ALTER DEFAULT PRIVILEGES IN SCHEMA dev GRANT SELECT ON TABLES TO reader_only;
ALTER DEFAULT PRIVILEGES IN SCHEMA logs GRANT SELECT ON TABLES TO reader_only;


-- Grants rights to the agent_bdd_dev role to the sequence in order to be able to generate the id value because it is in SERIAL.
ALTER DEFAULT PRIVILEGES IN SCHEMA dev GRANT USAGE, SELECT, UPDATE ON SEQUENCES TO agent_bdd_dev;
ALTER DEFAULT PRIVILEGES IN SCHEMA logs GRANT USAGE, SELECT, UPDATE ON SEQUENCES TO agent_bdd_dev;

GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES IN SCHEMA dev TO agent_bdd_dev;
GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES IN SCHEMA logs TO agent_bdd_dev;
