import os

from app_code.runtime_paths import load_runtime_env

load_runtime_env()


def _env(*names: str, default: str | None = None) -> str | None:
    for name in names:
        value = os.getenv(name)
        if value not in {None, ""}:
            return value
    return default


DB_TYPE_ALIASES = {
    "pg": "postgresql",
    "postgres": "postgresql",
    "postgresql": "postgresql",
    "bigquery": "bigquery",
    "bq": "bigquery",
    "teradata": "teradata",
    "td": "teradata",
    "mysql": "mysql",
    "mariadb": "mysql",
    "snowflake": "snowflake",
    "snowflow": "snowflake",
}


def normalize_db_type(value: str | None) -> str:
    if not value:
        raise ValueError("BDD_DB_TYPE must be set in runtime/bd_env")
    normalized = value.strip().lower().replace("-", "_")
    return DB_TYPE_ALIASES.get(normalized, normalized)


DB_TYPE = normalize_db_type(_env("BDD_DB_TYPE"))


def _typed_env(suffix: str, *fallbacks: str, default: str | None = None) -> str | None:
    prefix_by_type = {
        "postgresql": "BDD_POSTGRES",
        "mysql": "BDD_MYSQL",
        "teradata": "BDD_TERADATA",
        "snowflake": "BDD_SNOWFLAKE",
        "bigquery": "BDD_BIGQUERY",
    }
    names: list[str] = []
    prefix = prefix_by_type.get(DB_TYPE)
    if prefix:
        names.append(f"{prefix}_{suffix}")
    names.extend(fallbacks)
    return _env(*names, default=default)


def _typed_port() -> int | None:
    raw_value = _typed_env("PORT", "BDD_DB_PORT", "CUSTOMCONNSTR_DB_PORT", "DB_PORT")
    return int(raw_value) if raw_value else None


DB_CONFIG = {
    "type": DB_TYPE,
    "database": _typed_env("DATABASE", "BDD_DB_NAME", "BDD_DATABASE", "BDD_DB_DATABASE"),
    "schema": _typed_env("SCHEMA", "BDD_DB_SCHEMA"),
    "host": _typed_env("HOST", "BDD_DB_HOST", "CUSTOMCONNSTR_DB_HOST", "DB_HOST"),
    "port": _typed_port(),
    "user": _typed_env("USER", "BDD_DB_USER", "CUSTOMCONNSTR_DB_USER", "DB_USER"),
    "password": _typed_env("PASSWORD", "BDD_DB_PASSWORD", "CUSTOMCONNSTR_DB_PASSWORD", "DB_PASSWORD"),
    "sslmode": _typed_env("SSLMODE", "BDD_DB_SSLMODE", "CUSTOMCONNSTR_DB_SSLMODE", "DB_SSLMODE"),
    "mysql_driver": _env("BDD_MYSQL_DRIVER"),
    "bigquery_project": _env("BDD_BIGQUERY_PROJECT", "GOOGLE_CLOUD_PROJECT"),
    "bigquery_dataset": _env("BDD_BIGQUERY_DATASET"),
    "bigquery_location": _env("BDD_BIGQUERY_LOCATION"),
    "bigquery_service_account_json": _env("BDD_BIGQUERY_SERVICE_ACCOUNT_JSON"),
    "teradata_host": _env("BDD_TERADATA_HOST", "BDD_DB_HOST"),
    "teradata_port": _env("BDD_TERADATA_PORT", "BDD_DB_PORT"),
    "teradata_user": _env("BDD_TERADATA_USER", "BDD_DB_USER"),
    "teradata_password": _env("BDD_TERADATA_PASSWORD", "BDD_DB_PASSWORD"),
    "teradata_database": _env("BDD_TERADATA_DATABASE", "BDD_DB_NAME"),
    "snowflake_account": _env("BDD_SNOWFLAKE_ACCOUNT"),
    "snowflake_user": _env("BDD_SNOWFLAKE_USER", "BDD_DB_USER"),
    "snowflake_password": _env("BDD_SNOWFLAKE_PASSWORD", "BDD_DB_PASSWORD"),
    "snowflake_database": _env("BDD_SNOWFLAKE_DATABASE", "BDD_DB_NAME"),
    "snowflake_schema": _env("BDD_SNOWFLAKE_SCHEMA", "BDD_DB_SCHEMA"),
    "snowflake_warehouse": _env("BDD_SNOWFLAKE_WAREHOUSE"),
    "snowflake_role": _env("BDD_SNOWFLAKE_ROLE"),
}

# Backward-compatible names used by older BDD helpers/tests.
DB_CONFIG["dbname"] = DB_CONFIG["database"]
