"""
Email agent file, containing initial prompt, email agent specific tools
and email node creation function.
"""

import logging
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from langchain_core.tools import tool

from app_code.skills_runtime.structs import NodeNames, ToolNames


@tool(
    ToolNames.SEND_EMAIL,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def send_email(
    email_body: str,
    recipient: str = "",
    subject: str = "",
) -> tuple[str, dict[str, str | NodeNames]]:
    """Use this tool to send an email to a single recipient.
    This email can only contain text, no document can be attached to it.

    Args:
        email_body: The content of the email to send.
        recipient: The recipient's email address.
        subject: The email subject.

    Returns:
        str: a status indicating if email was correctly sent or if an error occured.
    """
    missing_fields = [
        field_name
        for field_name, field_value in [
            ("recipient", recipient),
            ("subject", subject),
        ]
        if not str(field_value or "").strip()
    ]
    if missing_fields:
        message = (
            "Email not sent: missing required field(s): "
            f"{', '.join(missing_fields)}. Ask the user for the missing information, "
            "or extract it from explicit ticket/user context before calling send_email again."
        )
        return message, {"next_agent": NodeNames.EMAIL_AGENT, "context": message}

    sender = os.getenv("SYSTEM_MAIL_ADDRESS")
    password = os.getenv("SYSTEM_MAIL_PASSWORD")

    missing_env_vars = [
        var_name
        for var_name, var_value in [
            ("SYSTEM_MAIL_ADDRESS", sender),
            ("SYSTEM_MAIL_PASSWORD", password),
        ]
        if not var_value
    ]
    if missing_env_vars:
        error_msg = f"Email generation is not set up: missing env variables {missing_env_vars}"
        logging.error(error_msg)
        return "", {"next_agent": NodeNames.EMAIL_AGENT, "context": error_msg}

    try:
        # Create message
        msg = MIMEMultipart()
        msg["From"] = sender
        msg["To"] = recipient
        msg["Subject"] = subject
        msg.attach(MIMEText(email_body, "plain"))

        # SMTP connection
        server = smtplib.SMTP(host="smtp.ionos.fr", port=587)
        server.starttls()
        server.login(sender, password)
        text = msg.as_string()
        server.sendmail(sender, recipient, text)
        server.quit()

        return "", {
            "next_agent": NodeNames.EMAIL_AGENT,
            "context": f"Email successfully sent to {recipient} with subject '{subject}'.",
        }
    except Exception as e:
        error_msg = f"An error occured during email sending: {repr(e)}"
        logging.error(error_msg)
        return "", {
            "next_agent": NodeNames.EMAIL_AGENT,
            "context": error_msg,
        }


skill_actions = {
    ToolNames.SEND_EMAIL: send_email,
}
