---
name: mail
description: Draft and send plain-text mail, email, SMTP messages, and notifications. Use this skill whenever the user asks to draft an email, send an email, notify someone by email, prepare a completion summary for a recipient, or turn technical/business context into a concise email. Send only when recipient, subject, body, and send intent are explicit.
---

# Email Drafting And Sending

Use this skill for plain-text email drafts and sends.

## Implementation

This skill is self-contained:

- `scripts/actions.py` exposes mail actions.
- SMTP credentials are read from environment variables by the action at send time.

Add new mail behavior inside this skill directory. Do not add a shared mail helper outside the
skill.

## Process

1. Confirm recipient email address.
2. Confirm subject or clear purpose.
3. Confirm body requirements or enough context to write the body.
4. Confirm whether the user wants a draft or an actual send.
5. Draft first when approval is unclear.
6. Send only when recipient, subject, body, and send intent are explicit.

Do not guess addresses, recipients, approval, or whether the user wanted a draft versus a send.

## Action Call Examples

Send an approved email:

Action: `send_email`

Arguments:

```json
{"recipient": "person@example.com", "subject": "ANAIA-148 completed", "email_body": "Hello,\n\nThe requested work is complete. Summary: ...\n\nBest,"}
```

Always pass all three fields exactly as `recipient`, `subject`, and `email_body`. If either the
recipient or subject is missing, ask the user instead of calling the action with only a body.

Ask for missing recipient before sending:

```text
I can draft that email, but I need the recipient address before I can send it.
```

Return a draft when send intent is not explicit:

```text
Subject: ANAIA-148 status update

Hello,

Here is the current status...
```

## Style

Use a professional, neutral tone. Keep the message concise but include material details. Prefer
short paragraphs and bullets when the email reports multiple actions or blockers.

Preserve exact identifiers and technical terms. Do not add flourish that could obscure the status.

## Completion

Return whether the email was drafted or sent, recipient, subject, short body summary, and missing
fields if blocked.
