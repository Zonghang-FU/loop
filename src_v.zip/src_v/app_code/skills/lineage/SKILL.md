---
name: lineage
description: Analyze SQL column-level data lineage from local SQL scripts. Use this skill whenever the user asks where a table column comes from, asks for source columns, transformation rules, upstream/downstream SQL lineage, cached lineage results, or wants to inspect lineage for SQL files under runtime/work/sql-lineage/SQL. This skill is independent and should be used even when no database, git, terminal, or BDD skill is enabled.
---

# SQL Lineage Analysis

Use this skill to trace how a target table column is produced from local SQL scripts in
`runtime/work/sql-lineage/SQL`. The goal is column-level lineage: identify the target expression, every
source column feeding it, upstream transformations, filters, and the scripts that prove each step.

This skill does not clone Git repositories and does not use a separate frontend. Work only through
the current chat.

## Implementation

This skill is self-contained:

- `scripts/actions.py` exposes file discovery, SQL reading, and SQLite cache actions.
- SQL source files live in `runtime/work/sql-lineage/SQL`.
- The lineage cache lives in `runtime/work/sql-lineage/Cash/lineage_cache.sqlite3`.
- CSV and Excel exports are written directly by this skill into `runtime/draft/<session_id>/`.

Do not use `sqlglot` for SQL parsing. Complex project SQL can be vendor-specific and may parse
incorrectly. Use the LLM's semantic reading of the SQL text instead.

Do not use code-side regular expressions to parse the user's request. The user's target table,
column, intent, language, and output preference must be understood by the LLM from the conversation.

## Core Workflow

## Completion Gates

Before giving a final answer for a lineage request, verify that all gates below are satisfied:

- Target table and target column are identified.
- Candidate SQL files for the target table have been searched.
- At least one target-writing SQL file has been read.
- Cache has been checked using the actual script paths already read.
- For every source table that directly feeds the target expression, at least one upstream search has
  been attempted.
- If an upstream script exists locally for a direct source table, at least one such script has been
  read and incorporated.
- If the answer was not loaded from cache, `lineage_save_cache` has been called with every script
  used in the analysis.

If any gate is not satisfied, continue with the appropriate action call instead of answering.

1. Determine the user's intent from natural language.
   - If they ask for available files, cache status, or previous analyses, use the cache/list actions.
   - If they ask for lineage, identify the target table and target column.
   - If either target table or column is materially ambiguous, ask the user directly.

2. For normal column lineage requests, call `lineage_analyze_column`.
   - This action is the hard execution boundary: it collects SQL context, checks cache, calls the
     LLM for SQL semantic analysis when needed, saves cache, and returns the final lineage.
   - It searches local SQL files by target table first, uses the target column only as an assistive
     ranking signal, then asks the LLM to pick from that deterministic shortlist. Do not send the
     full project file list to the LLM for normal lineage steps.
   - It reads only the files selected from the shortlist, and repeats for parent SQL only when the
     current step proves that another parent table/column must be inspected.
   - The default upstream inspection depth is 10 steps.
   - Do not manually stop after partial context when this action can be used.

3. For lineage file export requests, use the lineage export action that matches the requested format.
   - If the user asks for CSV, call `lineage_export_csv` after the lineage has been analyzed.
   - If the user asks for Excel or `.xlsx`, call `lineage_export_excel` after the lineage has been analyzed.
   - Export columns are: `Source`, `Target`, `SQL rule`, `Script`, `Filters`, `Notes`.
   - `SQL rule` preserves the full rule text from the lineage result to avoid losing context.
   - This export is handled inside the lineage skill and does not require the terminal skill.

4. Discover candidate SQL files manually only for supporting questions.
   - Do not use `lineage_collect_analysis_context` for normal lineage requests; it is a support
     inspection tool. Use `lineage_analyze_column` so the Python action can select and read files
     one lineage layer at a time.
   - Call `lineage_list_sql_files` when you need an overview.
   - Call `lineage_search_sql_files` with table names, column names, and likely layer names.
   - Search both the final target table and the target column.
   - For project naming conventions, also try short table names without schema prefixes.

5. Check cache before deep analysis when not using `lineage_analyze_column`.
   - First discover at least one likely script path. Do not call `lineage_check_cache` with an
     empty `script_paths` list.
   - Once you have likely scripts, call `lineage_check_cache`.
   - If cache hits, return the cached lineage and mention that it came from cache.
   - If cache misses, continue analysis and save the final result with `lineage_save_cache`.

6. Read only relevant SQL first when not using `lineage_analyze_column`.
   - Use `lineage_read_sql_files` for candidate files.
   - Start with scripts that appear to write the target table.
   - Then inspect upstream source tables referenced by those scripts.
   - If a source table's origin is unclear, search and read the SQL files that produce that source table.

7. Build a complete lineage tree, not a flat summary.
   - If a target column is calculated from multiple columns, create child branches for every source
     column that participates in the expression.
   - For example, if `net_amount = gross_amount - discount_amount + tax_amount`, trace
     `gross_amount`, `discount_amount`, and `tax_amount` independently upstream.
   - Continue recursively until reaching raw/source tables, constants, unknown external inputs, or
     a point where the local SQL files no longer provide evidence.
   - Do not stop after the first intermediate table and do not ask whether the user wants deeper
     tracing. A lineage request means the user wants the full trace by default.
   - Do not end with offers like "I can trace deeper." Trace deeper now, or explain exactly which
     local script is missing.
   - If the context is too large, prioritize the branches that directly feed the requested column,
     but still inspect the next upstream scripts before producing a final answer.

8. Handle ambiguity honestly.
   - If a column reference has no alias and the SQL joins multiple tables, inspect upstream parent
     table scripts to infer the source.
   - If multiple parent tables remain plausible, report the ambiguity and list the candidate
     tables instead of inventing a single source.
   - Every lineage step should cite the script and SQL expression or filter that supports it.

9. Save the final lineage.
   - Use `lineage_save_cache` with the scripts actually used.
   - Store the final answer as structured JSON text when possible.
   - Do not finish a non-cached lineage answer before attempting to save the cache.

## Output Format

Prefer this structure for lineage answers:

```markdown
## Lineage: `target_table.target_column`

Cache: hit|miss then saved

### Summary
[2-4 sentences]

### Lineage Tree
1. `source_table.source_column` -> `intermediate_or_target.column`
   - Script: `path/to/script.sql`
   - SQL rule: `exact SQL expression`
   - Filters: `WHERE/HAVING/JOIN filters`, or `none found`
   - Notes: ambiguity or business meaning

### Ambiguities
[Only include when needed]

### Scripts Used
- `...`
```

When a user asks for machine-readable output, return JSON:

```json
{
  "target": {"table": "...", "column": "..."},
  "summary": "...",
  "lineage_tree": {
    "nodes": [
      {
        "source_table": "...",
        "source_column": "...",
        "target_table": "...",
        "target_column": "...",
        "sql_rule": "...",
        "script": "...",
        "filters": "...",
        "confidence": "high|medium|low",
        "children": []
      }
    ]
  },
  "ambiguities": [],
  "scripts_used": []
}
```

## Action Call Examples

Analyze lineage end-to-end:

```json
{"table_name": "agg.fait_crm_performance", "column_name": "nb_clientes", "extra_terms": []}
```

Action: `lineage_analyze_column`

List SQL files:

```json
{}
```

Action: `lineage_list_sql_files`

Search for target table and column:

```json
{"query_terms": ["agg.fait_crm_performance", "fait_crm_performance", "nb_clientes"], "limit": 20}
```

Action: `lineage_search_sql_files`

Collect a full analysis package:

```json
{"table_name": "agg.fait_crm_performance", "column_name": "nb_clientes", "extra_terms": [], "max_files": 40, "max_chars_per_file": 20000}
```

Action: `lineage_collect_analysis_context`

Read candidate files:

```json
{"file_paths": ["AGG/alim_fait_crm_performance.sql", "GOLDEN_LV3/alim_fait_ventes_entete.sql"], "max_chars_per_file": 30000}
```

Action: `lineage_read_sql_files`

Check cache:

```json
{"table_name": "agg.fait_crm_performance", "column_name": "nb_clientes", "script_paths": ["AGG/alim_fait_crm_performance.sql"]}
```

Action: `lineage_check_cache`

Save cache:

```json
{
  "table_name": "agg.fait_crm_performance",
  "column_name": "nb_clientes",
  "lineage_result": "{\"summary\":\"...\",\"lineage_tree\":{\"nodes\":[]}}",
  "script_paths": ["AGG/alim_fait_crm_performance.sql"]
}
```

Action: `lineage_save_cache`

Export cached or provided lineage to CSV:

```json
{"table_name": "agg.fait_crm_performance", "column_name": "nb_clientes", "delimiter": ","}
```

Action: `lineage_export_csv`

Export cached or provided lineage to Excel:

```json
{"table_name": "agg.fait_crm_performance", "column_name": "nb_clientes"}
```

Action: `lineage_export_excel`

## Completion

Return the target table/column, cache status, lineage tree, SQL rules, scripts used, unresolved
ambiguities, export path when a file was requested, and suggested next questions when deeper
confirmation is needed.
