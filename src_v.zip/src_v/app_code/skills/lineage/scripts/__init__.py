"""SQL lineage skill scripts."""
