"""Jira configuration using dataclass for type safety and immutability."""

import os
from dataclasses import dataclass

from app_code.runtime_paths import load_runtime_env

load_runtime_env()


@dataclass(frozen=True)
class JiraConfig:
    """Immutable Jira configuration.

    Attributes:
        url: Jira instance URL (e.g., https://company.atlassian.net)
        username: Jira account email
        api_token: Jira API token for authentication
    """

    url: str
    username: str
    api_token: str

    def validate(self) -> None:
        """Validate configuration before making Jira API calls."""
        if not self.url or self.url == "https://your-domain.atlassian.net":
            raise ValueError(
                "JIRA_URL not configured. Set it in runtime/env file:\n"
                "JIRA_URL=https://your-domain.atlassian.net"
            )

        if not self.username or self.username == "email@example.com":
            raise ValueError(
                "JIRA_USERNAME not configured. Set it in runtime/env file:\n"
                "JIRA_USERNAME=your-email@example.com"
            )

        if not self.api_token or self.api_token == "default_token":
            raise ValueError(
                "JIRA_API_TOKEN not configured. Set it in runtime/env file:\n"
                "JIRA_API_TOKEN=your_jira_api_token"
            )

        if not self.url.startswith("https://"):
            raise ValueError(f"JIRA_URL must start with 'https://': {self.url}")


# Singleton instance
JIRA_CONFIG = JiraConfig(
    url=os.getenv("JIRA_URL", ""),
    username=os.getenv("JIRA_USERNAME", ""),
    api_token=os.getenv("JIRA_API_TOKEN", ""),
)
