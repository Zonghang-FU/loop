"""
Jira tools using atlassian-python-api.
"""

import logging
import re
from datetime import datetime
from functools import lru_cache
from typing import Any, Dict

from atlassian import Jira

from app_code.https_config import https_verify_enabled

from .jira_config import JIRA_CONFIG


# ==================================================================
# JIRA CLIENT INITIALIZATION
# ==================================================================
@lru_cache(maxsize=1)
def get_jira_client() -> Jira:
    """Initialize and return a Jira client using environment variables."""
    JIRA_CONFIG.validate()
    return Jira(
        url=JIRA_CONFIG.url,
        username=JIRA_CONFIG.username,
        password=JIRA_CONFIG.api_token,
        cloud=True,
        verify_ssl=https_verify_enabled(),
    )


# ==================================================================
# Fonctions utilitaires pour les outils Jira
# ==================================================================
def format_jira_datetime(iso_datetime: str) -> str:
    """
    Convertit une date ISO Jira en format lisible (jusqu'à la minute).

    Args:
        iso_datetime: Date au format ISO (e.g., "2024-02-09T14:30:45.123+0000")

    Returns:
        Date formatée (e.g., "2024-02-09 14:30")
    """
    if not iso_datetime:
        return iso_datetime
    try:
        normalized = iso_datetime.replace("Z", "+00:00")
        normalized = re.sub(r"([+-]\d{2})(\d{2})$", r"\1:\2", normalized)
        dt = datetime.fromisoformat(normalized)
        return dt.strftime("%Y-%m-%d %H:%M")
    except Exception as e:
        logging.warning(f"Could not parse date '{iso_datetime}': {e}")
        return iso_datetime


# Validation JQL simple
def validate_jql(jql_query: str, max_results: int) -> tuple[bool, str]:
    """
    Valide la requête JQL et max_results.

    Returns:
        tuple[bool, str]: (is_valid, error_message)
    """
    # Vérifier JQL
    if not jql_query or not jql_query.strip():
        return False, "JQL query cannot be empty"

    if jql_query.count('"') % 2 != 0 or jql_query.count("'") % 2 != 0:
        return False, "Unclosed quote in JQL query"

    if jql_query.count("(") != jql_query.count(")"):
        return False, "Mismatched parentheses in JQL query"

    # Vérifier max_results
    if not isinstance(max_results, int) or max_results < 1 or max_results > 100:
        return False, "max_results must be between 1 and 100"

    return True, ""


# ==================================================================
# JIRA TOOLS
# ==================================================================


# Tool 1 - Récupérer toutes les informations sur un ticket Jira
def get_jira_issue(issue_key: str, include_all_fields: bool = False) -> Dict[str, Any]:
    """
    Retrieve detailed information about a Jira issue.

    **Field exclusion**: By default, only fields with actual values are returned.
    Empty fields (null, empty strings, empty lists) are automatically excluded to
    save tokens, unless explicitly requested with include_all_fields=True.

    Args:
        issue_key (str): The key of the Jira issue (e.g., 'ANAIA-128').
        include_all_fields (bool): If True, include ALL fields even if empty (default: False).

    Returns:
        dict: Issue information with only populated fields, or error details.
    """
    MAX_COMMENTS = 3  # Limit the number of comments to include in the response
    try:
        jira = get_jira_client()

        # Récupérer le ticket
        try:
            issue = jira.issue(issue_key)
        except Exception as e:
            logging.error(f"Issue {issue_key} not found: {e}")
            return {
                "status": "error",
                "message": f"Issue '{issue_key}' does not exist.",
                "error_code": "issue_not_found",
            }

        fields = issue["fields"]

        # CHAMPS TOUJOURS PRÉSENTS (obligatoires dans Jira)
        data = {
            "key": issue["key"],
            "summary": fields["summary"],
            "status": fields["status"]["name"],
            "issue_type": fields["issuetype"]["name"],
            "priority": fields["priority"]["name"],
            "created": format_jira_datetime(fields["created"]),
            "updated": format_jira_datetime(fields["updated"]),
            "project": {"key": fields["project"]["key"], "name": fields["project"]["name"]},
        }

        # CHAMPS OPTIONNELS (ajoutés seulement s'ils ont une valeur)

        # Description
        description = fields.get("description", "No description available.")
        if description or include_all_fields:
            data["description"] = description if description else None

        # Assigné
        assignee = fields.get("assignee")
        if assignee or include_all_fields:
            data["assignee"] = assignee["displayName"] if assignee else "Unassigned"

        # Reporter
        reporter = fields.get("reporter")
        if reporter or include_all_fields:
            data["reporter"] = reporter["displayName"] if reporter else None

        # Epic parent
        parent = fields.get("parent")
        if parent:
            data["epic"] = {"key": parent["key"], "summary": parent["fields"]["summary"]}
        elif include_all_fields:
            data["epic"] = None

        # Labels
        labels = fields.get("labels", [])
        if labels or include_all_fields:
            data["labels"] = labels if labels else []

        # Commentaires
        comments = fields.get("comment", {}).get("comments", [])

        # Cas: aucun commentaire
        if not comments:
            if include_all_fields:
                data["comments_count"] = 0
                data["comments"] = []
            # sinon: on ne met rien du tout

        else:
            # Il y a des commentaires
            if include_all_fields:
                data["comments_count"] = len(comments)
                # Toujours garder les derniers
                selected = comments[-MAX_COMMENTS:]

                data["comments"] = [
                    {
                        "author": c["author"]["displayName"],
                        "created": format_jira_datetime(c["created"]),
                        "body": c["body"],
                    }
                    for c in selected
                ]
                data["comments_truncated"] = len(selected)
                data["comments_kept"] = len(comments) > MAX_COMMENTS

        # Pièces jointes
        attachments = fields.get("attachment", [])
        if attachments:
            data["attachments_count"] = len(attachments)
            data["attachments"] = [
                {
                    "filename": att["filename"],
                    "size": att["size"],
                    "created": format_jira_datetime(att["created"]),
                    "author": att["author"]["displayName"],
                }
                for att in attachments
            ]
        elif include_all_fields:
            data["attachments_count"] = 0
            data["attachments"] = []

        # Sous-tâches
        subtasks = fields.get("subtasks", [])
        if subtasks:
            data["subtasks_count"] = len(subtasks)
            data["subtasks"] = [
                {
                    "key": subtask["key"],
                    "summary": subtask["fields"]["summary"],
                    "status": subtask["fields"]["status"]["name"],
                }
                for subtask in subtasks
            ]
        elif include_all_fields:
            data["subtasks_count"] = 0
            data["subtasks"] = []

        # Due date (échéance)
        due_date = fields.get("duedate")
        if due_date or include_all_fields:
            data["due_date"] = due_date if due_date else None

        # Estimation (si utilisée)
        time_estimate = fields.get("timeoriginalestimate")
        if time_estimate or include_all_fields:
            data["time_estimate_seconds"] = time_estimate

        # Temps passé
        time_spent = fields.get("timespent")
        if time_spent or include_all_fields:
            data["time_spent_seconds"] = time_spent

        return {
            "status": "success",
            "data": data,
            "available_fields": list(data.keys()),
        }

    except Exception as e:
        error_msg = f"Error retrieving issue {issue_key}: {str(e)}"
        logging.error(error_msg)
        return {"status": "error", "message": str(e), "error_code": "retrieval_failed"}


# Tool 2 - Lister les tickets Jira
def list_jira_issues(
    project_key: str, max_results: int = 50, jql_filter: str = "", start_at: int = 0
) -> dict:
    """
    List Jira issues from a specific project.

    Args:
        project_key (str): The key of the Jira project (e.g., 'ANAIA').
        max_results (int): Maximum number of results (default: 50, max: 100).
        jql_filter (str): Optional JQL filter (e.g., 'status="À faire"').
        start_at (int): Index of the first issue to return (for pagination, default: 0).

    Returns:
        dict: List of issues with status

    """
    try:
        jira = get_jira_client()
        max_results = min(max_results, 100)

        if jql_filter:
            jql = f"project = {project_key} AND {jql_filter}"
        else:
            jql = f"project = {project_key}"
        jql += " ORDER BY created DESC"

        result = jira.jql(jql, limit=max_results, start=start_at)

        issues_raw = result.get("issues", [])
        total = result.get("total", 0)
        returned = len(issues_raw)
        has_more = (start_at + returned) < total

        # Formatage
        formatted_issues = []
        for issue in issues_raw:
            fields = issue.get("fields", {})

            priority = fields.get("priority")
            issuetype = fields.get("issuetype")

            formatted_issues.append(
                {
                    "key": issue.get("key"),
                    "summary": fields.get("summary"),
                    "status": fields.get("status", {}).get("name"),
                    "issue_type": issuetype["name"] if issuetype else None,
                    "priority": priority["name"] if priority else None,
                    "created": format_jira_datetime(fields.get("created")),
                    "updated": format_jira_datetime(fields.get("updated")),
                }
            )

        # Message
        if total == 0:
            message = f"No issues found in project {project_key}"
        elif has_more:
            message = f"Showing {returned} of {total} issues (page {start_at // max_results + 1})"
        else:
            message = f"Found {total} issue(s) in project {project_key}"

        logging.debug(f"Listed {len(formatted_issues)} issues from project {project_key}")

        return {
            "status": "success",
            "data": formatted_issues,
            "pagination": {
                "start_at": start_at,
                "max_results": max_results,
                "total": total,
                "returned": returned,
                "has_more": has_more,
            },
            "message": message,
        }

    except Exception as e:
        logging.error(f"Error listing issues for project {project_key}: {e}")
        return {"status": "error", "message": str(e), "error_code": "list_failed"}


# Tool 3 - Créer un ticket Jira
def create_jira_issue(
    project_key: str,
    summary: str,
    description: str = "",
    issue_type: str = "Task",
    priority: str = "Medium",
    parent_key: str = None,
    # Si True, l'issue doit être liée à un parent existant, sinon elle peut être créée sans parent
    require_parent: bool = True,
) -> dict:
    """
    Create a new Jira issue.

    Use this tool to create a new ticket in Jira.

    Args:
        project_key (str): The key of the Jira project (e.g., 'ANAIA').
        summary (str): The title/summary of the issue.
        description (str): Detailed description (optional).
        issue_type (str): Type ('Task', 'Story', 'Bug').
        priority (str): Priority ('Medium', 'Low', 'High').
        parent_key (str): The key of the Parent issue (e.g., 'ANAIA-100', optional but recommended).
        require_parent (bool): If True, Parent is required (default: True).

    Returns:
        dict: Created issue details with status.
    """
    try:
        jira = get_jira_client()

        # Vérifier que le projet existe
        try:
            project = jira.project(project_key)
            logging.info(f"Project '{project_key}' validated: {project.get('name', 'N/A')}")
        except Exception as e:
            logging.error(f"Project '{project_key}' not found: {e}")
            return {
                "status": "error",
                "message": (
                    f"Error: Project '{project_key}' does not exist. "
                    f"Please create it first in Jira or use an existing project key."
                ),
                "error_code": "project_not_found",
                "project_key": project_key,
            }

        # Si require_parent est True et pas de parent_key fourni, retourner une erreur
        if require_parent and not parent_key:
            logging.error("Parent required but not provided for ticket creation.")
            return {
                "status": "error",
                "message": (
                    "Cannot create issue: A Parent is required but none was provided. "
                    "Please specify a parent_key (e.g., 'ANAIA-100') or set require_parent=False."
                ),
                "error_code": "parent_required",
                "project_key": project_key,
            }

        # Liste des types acceptés comme parents
        VALID_PARENT_TYPES = ["Projet", "Epic"]

        # Si parent_key est fourni, vérifier qu'il existe et est bien un parent valide
        if parent_key:
            try:
                parent = jira.issue(parent_key)
                parent_type = parent["fields"]["issuetype"]["name"]
                parent_hierarchy = parent["fields"]["issuetype"].get("hierarchyLevel", 0)
                logging.info("*" * 10)
                logging.info(f"Parent '{parent_key}' found: {parent['fields']['summary']}")
                logging.info(f"{parent}")
                logging.info("*" * 10)

                # Validation : Soit level >= 1, soit dans la liste des types acceptés
                is_valid = (parent_hierarchy >= 1) or (parent_type in VALID_PARENT_TYPES)

                if not is_valid:
                    logging.error(
                        f"Invalid parent '{parent_key}': type={parent_type}, "
                        f"level={parent_hierarchy}"
                    )
                    return {
                        "status": "error",
                        "message": (
                            f"Cannot use '{parent_key}' as parent issue. "
                            f"It's a '{parent_type}' (hierarchy level {parent_hierarchy}). "
                            f"Valid parent types: {', '.join(VALID_PARENT_TYPES)}."
                        ),
                        "error_code": "invalid_parent_type",
                        "parent_key": parent_key,
                        "parent_type": parent_type,
                        "parent_level": parent_hierarchy,
                        "valid_types": VALID_PARENT_TYPES,
                    }

                logging.info(
                    f"Valid parent: {parent_key} "
                    f"(type: {parent_type}, level: {parent_hierarchy})."
                )

            except Exception as e:
                logging.error(f"Parent '{parent_key}' not found: {e}")
                return {
                    "status": "error",
                    "message": (
                        f"Parent issue '{parent_key}' does not exist or is not accessible. "
                        "Please provide a valid parent key."
                    ),
                    "error_code": "parent_not_found",
                    "parent_key": parent_key,
                }

        # Création du ticket
        fields = {
            "project": {"key": project_key},
            "summary": summary,
            "description": description,
            "issuetype": {"name": issue_type},
            "priority": {"name": priority},
        }

        # Ajouter le parent (Epic) si fourni
        if parent_key:
            fields["parent"] = {"key": parent_key}

        new_issue = jira.create_issue(fields=fields)
        issue_key = new_issue["key"]

        logging.info(f"Created issue {issue_key}: {summary}")

        return {
            "status": "success",
            "data": {
                "issue_key": issue_key,
                "summary": summary,
                "issue_type": issue_type,
                "priority": priority,
                "project": project_key,
                "parent_key": parent_key if parent_key else None,
            },
            "message": f"Issue '{issue_key}' created successfully in project '{project_key}'"
            + (f" with Parent '{parent_key}'." if parent_key else ""),
        }

    except Exception as e:
        logging.error(f"Error creating issue in project {project_key}: {e}")
        return {
            "status": "error",
            "message": f"Failed to create issue: {str(e)}",
            "error_code": "creation_failed",
            "project_key": project_key,
        }


# Tool 4 - Mettre à jour le statut d'un ticket Jira
def update_jira_issue_status(issue_key: str, status: str) -> Dict[str, Any]:
    """
    Update the status of a Jira issue (transition).

    Use this tool to change the status of a Jira ticket.

    Args:
        issue_key (str): The key of the Jira issue (e.g., 'ANAIA-112').
        status (str): The target status name (e.g., 'En cours', 'Terminé', "In Progress").

    Returns:
        dict: Updated issue status with confirmation.
    """
    try:
        jira = get_jira_client()

        # Vérifier que le ticket existe
        try:
            issue = jira.issue(issue_key)
            current_status = issue["fields"]["status"]["name"]
            logging.info(f"Issue '{issue_key}' found. Current status: '{current_status}'")
        except Exception as e:
            logging.error(f"Issue '{issue_key}' not found: {e}")
            return {
                "status": "error",
                "message": f"Issue '{issue_key}' does not exist or is not accessible.",
                "error_code": "issue_not_found",
                "issue_key": issue_key,
            }

        # Vérifier si déjà dans le bon statut
        if current_status.lower() == status.lower():
            logging.info(f"Issue '{issue_key}' is already in status '{status}'. No update needed.")
            return {
                "status": "success",
                "message": (
                    f"Issue '{issue_key}' is already in status '{status}'. No update needed."
                ),
                "data": {
                    "issue_key": issue_key,
                    "current_status": current_status,
                    "new_status": current_status,
                    "changed": False,
                },
            }

        # Récuperer les transitions disponibles pour le ticket
        try:
            transitions = jira.get_issue_transitions(issue_key)
        except Exception as e:
            logging.error(f"Could not retrieve transitions for issue '{issue_key}': {e}")
            return {
                "status": "error",
                "message": f"Could not retrieve transitions for issue '{issue_key}' : {str(e)}",
                "error_code": "transitions_failed",
                "issue_key": issue_key,
            }

        # Trouver la transition correspondante au statut cible
        transition_id = None
        target_status_name = None

        for transition in transitions:
            if transition["to"].lower() == status.lower():
                transition_id = transition["id"]
                target_status_name = transition["to"]
                break

        # Si aucune transition trouvée, retourner une erreur avec les statuts disponibles
        if not transition_id:
            available_statuses = [t["to"] for t in transitions]
            logging.error(
                f"Status '{status}' not available for issue '{issue_key}'. "
                f"Available statuses: {available_statuses}"
            )
            return {
                "status": "error",
                "message": (
                    f"Cannot transition issue '{issue_key}' to status '{status}'. "
                    f"This transition is not available. "
                    f"Available target statuses are: {available_statuses}"
                ),
                "error_code": "invalid_transition",
                "issue_key": issue_key,
                "current_status": current_status,
                "requested_status": status,
                "available_statuses": available_statuses,
            }

        # Perform the transition via REST API
        try:
            url = f"{jira.resource_url('issue')}/{issue_key}/transitions"
            data = {"transition": {"id": transition_id}}
            jira.post(url, data=data)

            logging.info(f"Updated status of {issue_key}: '{current_status}' -> '{status}'")

            return {
                "status": "success",
                "data": {
                    "issue_key": issue_key,
                    "old_status": current_status,
                    "new_status": target_status_name,
                    "changed": True,
                },
                "message": (
                    f"Issue '{issue_key}' status updated from '{current_status}' "
                    f"to '{target_status_name}'"
                ),
            }
        except Exception as e:
            logging.error(f"Failed to update status for issue '{issue_key}' to '{status}': {e}")
            return {
                "status": "error",
                "message": f"Failed to update status: {str(e)}",
                "error_code": "transition_failed",
                "issue_key": issue_key,
            }

    except Exception as e:
        logging.error(f"Error updating status for issue {issue_key}: {e}")
        return {
            "status": "error",
            "message": f"Unexpected error: {str(e)}",
            "error_code": "unexpected_error",
            "issue_key": issue_key,
        }


# Tool 5 - Mettre à jour un champ spécifique d'un ticket Jira
def update_jira_issue_field(issue_key: str, field_name: str, field_value: str) -> dict:
    """
    Update a specific field of a Jira issue.

    Use this tool to update a specific field of a Jira issue.
    It validates that the field exists before attempting the update.

    Args:
        issue_key (str): The key of the Jira issue (e.g., 'ANAIA-100').
        field_name (str): Name of the field (e.g., 'summary', 'description').
        field_value (str): New value for the field.

    Returns:
        dict: A dictionary with status and confirmation data.
    """
    # Validation minimale : vérifier que les paramètres ne sont pas vides
    if not issue_key or not issue_key.strip():
        return {
            "status": "error",
            "error_code": "validation",
            "message": "Issue key cannot be empty",
            "issue_key": issue_key,
        }

    if not field_name or not field_name.strip():
        return {
            "status": "error",
            "error_code": "validation",
            "message": "Field name cannot be empty",
            "issue_key": issue_key,
        }

    try:
        jira = get_jira_client()

        # 1. Vérifier que le ticket existe
        try:
            issue = jira.issue(issue_key)
            logging.info(f"Issue '{issue_key}' found. Preparing to update field '{field_name}'.")
        except Exception as e:
            logging.error(f"Issue '{issue_key}' not found: {e}")
            return {
                "status": "error",
                "message": f"Issue '{issue_key}' does not exist or is inaccessible.",
                "error_code": "issue_not_found",
                "issue_key": issue_key,
            }

        # 2. Vérifier que le champ existe sur ce ticket
        available_fields = issue.get("fields", {})

        if field_name not in available_fields:
            # Le champ n'existe pas
            logging.error(f"Field '{field_name}' does not exist on issue '{issue_key}'")

            # Récupérer quelques champs disponibles pour aider l'agent
            sample_fields = list(available_fields.keys())[:20]

            return {
                "status": "error",
                "message": (
                    f"Field '{field_name}' does not exist on issue '{issue_key}'. "
                    f"Call get_jira_issue with include_all_fields=True to see all available fields."
                ),
                "error_code": "field_not_found",
                "issue_key": issue_key,
                "field_name": field_name,
                "sample_available_fields": sample_fields,
                "total_fields_count": len(available_fields),
            }

        # 3. Récupérer la valeur actuelle (optionnel, pour le logging)
        current_value = available_fields.get(field_name)

        # Convertir en string lisible pour l'affichage
        if isinstance(current_value, dict):
            current_value_display = (
                current_value.get("name") or current_value.get("displayName") or str(current_value)
            )
        elif isinstance(current_value, list):
            if current_value and isinstance(current_value[0], dict):
                current_value_display = ", ".join(
                    [item.get("name", str(item)) for item in current_value]
                )
            else:
                current_value_display = ", ".join([str(v) for v in current_value])
        else:
            current_value_display = str(current_value) if current_value is not None else "None"

        logging.info(f"Current value of '{field_name}': {current_value_display}")

        # 4. Construire la structure de mise à jour
        # On passe la valeur telle quelle, Jira gérera le format
        fields = {field_name: field_value}

        # 5. Effectuer la mise à jour
        try:
            jira.update_issue_field(issue_key, fields)
            logging.info(f"Successfully updated field '{field_name}' of issue '{issue_key}'")

            return {
                "status": "success",
                "data": {
                    "issue_key": issue_key,
                    "field_name": field_name,
                    "old_value": current_value_display,
                    "new_value": field_value,
                },
                "message": (
                    f"Field '{field_name}' of issue '{issue_key}' updated successfully. "
                    f"Old value: '{current_value_display}' → New value: '{field_value}'"
                ),
            }

        except Exception as e:
            error_str = str(e)
            logging.error(f"Failed to update field '{field_name}' for issue '{issue_key}': {e}")

            # L'erreur vient de Jira (format invalide, permissions, etc.)
            return {
                "status": "error",
                "message": (
                    f"Failed to update field '{field_name}' to '{field_value}'. "
                    f"The field exists but Jira rejected the update. "
                    f"Jira error: {error_str}"
                ),
                "error_code": "update_rejected",
                "issue_key": issue_key,
                "field_name": field_name,
                "field_value": field_value,
                "jira_error": error_str,
                "hint": (
                    "This usually means the value format is incorrect or you don't have "
                    "permissions. Call get_jira_issue to see the current field structure "
                    "and understand the expected format."
                ),
            }

    except Exception as e:
        logging.error(
            f"Unexpected error updating field '{field_name}' for issue '{issue_key}': {e}"
        )
        return {
            "status": "error",
            "message": f"Unexpected error: {str(e)}",
            "error_code": "unexpected_error",
            "issue_key": issue_key,
            "field_name": field_name,
        }


# Tool 6 - Ajouter un commentaire à un ticket Jira
def add_jira_comment(issue_key: str, comment: str) -> dict:
    """
    Add a comment to a Jira issue.

    Use this tool to add comments/notes to a Jira ticket.
    This is MANDATORY when creating or modifying work items.

    Args:
        issue_key (str): The key of the Jira issue (e.g., 'ANAIA-112').
        comment (str): The comment text to add to the issue.

    Returns:
        dict: A dictionary with status and confirmation data.
    """
    try:
        jira = get_jira_client()

        # Valider que le commentaire n'est pas vide
        if not comment or not comment.strip():
            logging.error("Cannot add empty comment")
            return {
                "status": "error",
                "message": "Comment cannot be empty. Please provide comment text.",
                "error_code": "empty_comment",
                "issue_key": issue_key,
            }

        # Ajouter le commentaire, Jira vérifie que le ticket exite
        try:
            jira.issue_add_comment(issue_key, comment)

            logging.info(f"Successfully added comment to {issue_key}")

            return {
                "status": "success",
                "data": {
                    "issue_key": issue_key,
                    "comment_length": len(comment),
                    "comment_preview": comment[:100] + "..." if len(comment) > 100 else comment,
                },
                "message": f"Comment added successfully to issue '{issue_key}'.",
            }
        except Exception as e:
            error_str = str(e)
            logging.error(f"Failed to add comment to issue '{issue_key}': {e}")

            # Analyse de l'erreur pour donner un message plus précis (permissions, format, etc.)
            if "issue" in error_str.lower() and (
                "not found" in error_str.lower() or "does not exist" in error_str.lower()
            ):
                return {
                    "status": "error",
                    "message": f"Issue '{issue_key}' does not exist or is not accessible.",
                    "error_code": "issue_not_found",
                    "issue_key": issue_key,
                }
            elif "permission" in error_str.lower() or "forbidden" in error_str.lower():
                return {
                    "status": "error",
                    "message": (
                        f"Failed to add comment to issue '{issue_key}': Insufficient permissions. "
                        "You may not have permission to comment on this issue."
                    ),
                    "error_code": "insufficient_permissions",
                    "issue_key": issue_key,
                }
            else:
                return {
                    "status": "error",
                    "message": f"Failed to add comment to issue '{issue_key}': {error_str}",
                    "error_code": "comment_failed",
                    "issue_key": issue_key,
                    "jira_error": error_str,
                }

    except Exception as e:
        logging.error(f"Unexpected error adding comment to issue '{issue_key}': {e}")
        return {
            "status": "error",
            "message": f"Unexpected error: {str(e)}",
            "error_code": "unexpected_error",
            "issue_key": issue_key,
        }


# Tool 7 - Rechercher des tickets Jira avec JQL
def search_jira_issues(jql_query: str, max_results: int = 50) -> dict:
    """
    Search for Jira issues using JQL (Jira Query Language).

    Use this tool for complex searches using JQL syntax.

    Args:
        jql_query (str): JQL query (e.g., 'project = ANAIA AND status = "In Progress"').
        max_results (int): Maximum number of results (default: 50, max: 100).

    Returns:
        dict: A dictionary with status and search results.
    """
    # Validation de la requête JQL et max_results
    is_valid, error_message = validate_jql(jql_query, max_results)
    if not is_valid:
        return {
            "status": "error",
            "error_type": "validation",
            "message": error_message,
            "query": jql_query,
        }

    try:
        jira = get_jira_client()
        results = jira.jql(jql_query, limit=max_results)

        if not isinstance(results, dict):
            raise ValueError(f"Unexpected response type: {type(results)}")

        issues = results.get("issues", [])
        total = results.get("total", len(issues))

        if not issues:
            return {
                "status": "success",
                "data": [],
                "message": f"No issues found matching query: {jql_query}",
                "query": jql_query,
                "total_found": 0,
            }

        # Formater les résultats avec gestion des champs manquants
        formatted_issues = []
        for issue in issues:
            fields = issue.get("fields", {})
            assignee_data = fields.get("assignee") or {}
            assignee_name = assignee_data.get("displayName", "Unassigned")

            formatted_issues.append(
                {
                    "key": issue.get("key", "UNKNOWN"),
                    "summary": issue.get("fields", {}).get("summary", "No summary"),
                    "status": issue.get("fields", {}).get("status", {}).get("name", "Unknown"),
                    "type": issue.get("fields", {}).get("issuetype", {}).get("name", "Unknown"),
                    "assignee": assignee_name,
                }
            )

        logging.debug(f"Found {len(formatted_issues)} issues matching JQL")

        return {
            "status": "success",
            "data": formatted_issues,
            "query": jql_query,
            "total_found": total,
            "returned": len(formatted_issues),
        }

    except ValueError as e:
        error_msg = str(e)
        if "jql" in error_msg.lower() or "syntax" in error_msg.lower():
            return {
                "status": "error",
                "error_type": "jql_syntax",
                "message": f"Invalid JQL: {error_msg}",
                "query": jql_query,
            }
        return {
            "status": "error",
            "error_type": "validation",
            "message": error_msg,
            "query": jql_query,
        }

    except PermissionError as e:
        return {
            "status": "error",
            "error_type": "permission",
            "message": f"Permission denied: {e}",
            "query": jql_query,
        }

    except (ConnectionError, TimeoutError) as e:
        return {
            "status": "error",
            "error_type": "connection",
            "message": f"Connection error: {e}",
            "query": jql_query,
        }

    # Fallback avec détection intelligente (pour erreurs mal typées)
    except Exception as e:
        error_msg = str(e).lower()

        # Détection du type d'erreur par mots-clés
        if any(kw in error_msg for kw in ["jql", "syntax", "field", "does not exist"]):
            error_type = "jql_syntax"
        elif any(kw in error_msg for kw in ["permission", "forbidden", "unauthorized", "403"]):
            error_type = "permission"
        elif any(kw in error_msg for kw in ["connection", "timeout", "network", "unreachable"]):
            error_type = "connection"
        else:
            error_type = "unknown"

        logging.error(f"JQL search error: {e}", exc_info=True)

        return {
            "status": "error",
            "error_type": error_type,
            "message": str(e),
            "query": jql_query,
        }


# Tool 8 - Supprimer un ticket Jira
def delete_jira_issue(issue_key: str) -> dict:
    """
    Delete a Jira issue permanently.

    WARNING: This action is IRREVERSIBLE! Use with extreme caution.

    Args:
        issue_key (str): The key of the Jira issue to delete (e.g., 'ANAIA-112').

    Returns:
        dict: Deletion confirmation with status.
    """
    # Validation minimale : vérifier que ce n'est pas vide
    if not issue_key or not issue_key.strip():
        return {
            "status": "error",
            "error_type": "validation",
            "message": "Issue key cannot be empty",
            "issue_key": issue_key,
        }

    issue_key = issue_key.strip()

    try:
        jira = get_jira_client()

        # Récupérer les détails AVANT de supprimer pour le logging
        try:
            issue = jira.issue(issue_key)
            summary = issue["fields"]["summary"]
            status_name = issue["fields"]["status"]["name"]
            logging.info(
                f"Preparing to delete issue '{issue_key}': {summary} " f"(status: {status_name})"
            )
        except Exception as e:
            # Si on ne peut pas récupérer les détails, continuer quand même
            logging.warning(f"Could not retrieve issue details before deletion: {e}")
            summary = "Unknown"
            status_name = "Unknown"

        # Supprimer le ticket
        jira.delete_issue(issue_key)

        logging.warning(f"Deleted issue {issue_key}: {summary}")

        return {
            "status": "success",
            "data": {
                "issue_key": issue_key,
                "deleted_summary": summary,
                "deleted_status": status_name,
            },
        }

    except KeyError:
        return {
            "status": "error",
            "error_type": "not_found",
            "message": f"Issue {issue_key} does not exist",
            "issue_key": issue_key,
        }

    except PermissionError as e:
        return {
            "status": "error",
            "error_type": "permission",
            "message": f"Permission denied: {e}",
            "issue_key": issue_key,
        }

    except (ConnectionError, TimeoutError) as e:
        return {
            "status": "error",
            "error_type": "connection",
            "message": f"Connection error: {e}",
            "issue_key": issue_key,
        }

    except Exception as e:
        error_msg = str(e).lower()

        # Détection intelligente du type d'erreur
        if any(kw in error_msg for kw in ["not found", "does not exist", "404"]):
            error_type = "not_found"
        elif any(kw in error_msg for kw in ["permission", "forbidden", "403"]):
            error_type = "permission"
        elif any(kw in error_msg for kw in ["connection", "timeout"]):
            error_type = "connection"
        else:
            error_type = "unknown"

        logging.error(f"Error deleting issue {issue_key}: {e}", exc_info=True)

        return {
            "status": "error",
            "error_type": error_type,
            "message": str(e),
            "issue_key": issue_key,
        }
