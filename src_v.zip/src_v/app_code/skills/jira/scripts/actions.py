"""
Jira agent file, containing initial prompt, jira agent specific tools
and jira node creation function.
"""

import json
import logging

from langchain_core.tools import tool

from app_code.skills.jira.scripts import jira_tools
from app_code.skills_runtime.user_actions import (
    handoff_to_user,
)
from app_code.skills_runtime.structs import NodeNames, ToolNames

# TODO add jira tools, review jira agent initial prompt

# ---  Definition of Jira tools  ---


@tool(
    ToolNames.GET_JIRA_ISSUE,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def get_jira_issue(
    issue_key: str, include_all_fields: bool = False
) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Use this tool to retrieve detailed information about a Jira issue.

    ANTI-HALLUCINATION CHECK (MANDATORY):
    BEFORE calling this tool:
    1. Verify issue_key is EXPLICITLY mentioned in user/planner message (format: PROJECT-123)
    2. If NOT explicit → Call handoff_to_user(
        "Which ticket? Provide key like DEV-42 or SUPPORT-1567"
    )
    3. NEVER guess or assume issue_key from context

    WRONG USAGE:
    User: "Show me the ticket details"
    Agent: [Calls get_jira_issue(issue_key='DATA-1015')] ← WHERE DID DATA-1015 COME FROM?

    CORRECT USAGE:
    User: "Show me the ticket details"
    Agent: [Calls handoff_to_user(
        "Which ticket? Please provide the issue key (e.g., TEST-8)"
    )]

    User: "Show me TEST-8 details"
    Agent: [Calls get_jira_issue(issue_key='TEST-8')] ← Explicit in user message!

    EXAMPLES:

    # Standard request - use default (False)
    User: "Show me SMART-21"
    Agent: [Calls get_jira_issue(issue_key='SMART-21')]
    Result: Returns only fields with values (summary, status, priority, etc.)

    # User wants ALL fields
    User: "Show me SMART-21 with all fields"
    Agent: [Calls get_jira_issue(issue_key='SMART-21', include_all_fields=True)]
    Result: Returns all fields including empty ones

    # Before updating a field - need to see all available fields
    User: "I want to update a custom field on SMART-21"
    Agent: [Calls get_jira_issue(issue_key='SMART-21', include_all_fields=True)]
    Result: Shows all fields including custom fields that might be empty

    # Checking if a field exists/is empty
    User: "Does SMART-21 have a description?"
    Agent: [Calls get_jira_issue(issue_key='SMART-21', include_all_fields=True)]
    Result: Will show description field even if empty

    Use Cases:
        - User asks for specific ticket details
        - Before updating/deleting to verify ticket exists
        - To check current field values before modification
        - Set include_all_fields=True when you need to discover what fields are available

    Args:
        issue_key: The explicit issue key from user (e.g., 'SMART-38')
        include_all_fields: Set to True to discover all available fields on the
            issue, including empty ones. Useful when you need to know what fields
            exist before updating them. Default is False to save tokens.

    Returns:
        str: a message with the issue details.
    """
    logging.info("-- Getting Jira issue tool --")
    result = jira_tools.get_jira_issue(issue_key, include_all_fields=include_all_fields)

    if result["status"] == "success":
        data = result.get("data", {})
        formatted_response = f"Success: Retrieved issue {data['key']}"
        context_msg = data

    else:
        # Format error message for LLM with full details
        error_message = result.get("message", "Unknown error.")
        formatted_response = f"Error retrieving issue {issue_key}: {error_message}"
        context_msg = formatted_response

    return formatted_response, {
        "next_agent": NodeNames.JIRA_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.LIST_JIRA_ISSUES,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def list_jira_issues(
    project_key: str,
    max_results: int = 10,
    jql_filter: str = "",
    start_at: int = 0,
) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Use this tool to list Jira issues from a specific project.

    VALIDATION RULES:
    - project_key is REQUIRED (e.g., 'ANAIA', 'PROJ')
    - max_results must be 1-50 (default: 10)
    - jql_filter is optional but must be valid JQL syntax

    WHEN TO USE:
    - User asks to list tickets in a project
    - Finding available parent tickets (Epic, Projet)
    - Exploring project content
    - When user doesn't provide specific issue_key

    JQL FILTER EXAMPLES:
    - Status filter: jql_filter='status="En cours"'
    - Type filter: jql_filter='type=Epic'
    - Combined: jql_filter='status="À faire" AND type=Task'

    WRONG: Using this when user provides explicit issue_key
    User: "Show me SMART-12"
    Agent: [Calls list_jira_issues] ← WRONG, use get_jira_issue instead!

    CORRECT: Using when exploring project
    User: "List all tickets in SMART project"
    Agent: [Calls list_jira_issues(project_key='SMART')]

    Args:
        project_key (str): **Required.** The key of the Jira project (e.g., 'SMART', 'SUPPORT').
        max_results (int): Must be between 1-50. Hardcoded maximum of 50. Default is 10.
        jql_filter (str): **Optional.** JQL filter syntax (e.g., 'status="À faire"').
        start_at (int): Index of the first issue to return for pagination. Default is 0.

    Returns:
        str: Formatted list of issues.
    """
    logging.info("-- Listing Jira issues tool --")
    result = jira_tools.list_jira_issues(project_key, max_results, jql_filter, start_at)

    if result["status"] == "success":
        issues = result.get("data", [])
        pagination = result.get("pagination", {})

        # Message principal avec le vrai contenu et formaté pour l'LLM
        formatted_response = result["message"]

        if issues:
            formatted_response += "\n" + "\n".join(
                [
                    f"- {issue['key']}: {issue['summary']} ({issue['status']})"
                    for issue in issues[:5]
                ]
            )
            if len(issues) > 5:
                formatted_response += f"\n... and {len(issues) - 5} more in this page."

        # Avertir s'il y a plus de résultats
        if pagination.get("has_more"):
            next_start = pagination["start_at"] + pagination["returned"]
            formatted_response += (
                f"\n\nMore results available! Call again with start_at={next_start}"
            )

        # Contexte complet pour l'agent
        context_msg = json.dumps(result, ensure_ascii=False)

    else:
        # Format error message with full details
        error_message = result.get("message", "Unknown error.")
        formatted_response = f"Error listing issues for project {project_key}: {error_message}"
        context_msg = formatted_response

    return formatted_response, {
        "next_agent": NodeNames.JIRA_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.CREATE_JIRA_ISSUE,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def create_jira_issue(
    project_key: str,
    summary: str,
    description: str = "",
    issue_type: str = "Task",
    priority: str = "Medium",
    parent_key: str = None,
    require_parent: bool = True,
) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Use this tool to create a new Jira issue.

    CRITICAL RULES:
    1. Parent is REQUIRED by default to avoid orphan tickets
    2. If user doesn't provide parent_key → Ask with handoff_to_user
    3. If user doesn't specify issue_type → Choose one of these types: Task, Story, Bug, etc...
    4. Verify parent exists and is valid type (Epic or Projet)
    5. If the field is mentionned, but you don't have the access to it, you can call the tool
        'update_jira_issue_field' to update the field after the creation of the issue.

    PARENT VALIDATION:
    - Parent must be type 'Epic' or 'Projet'
    - If parent is invalid type, tool returns error with valid types
    - Use list_jira_issues to find available parents:
      * list_jira_issues(project_key='TEEM', jql_filter='type=Projet')
      * list_jira_issues(project_key='TEEM', jql_filter='type=Epic')

    ISSUE TYPES:
    - Task: General work item
    - Story: User story (Agile)
    - Bug: Bug report
    - Epic: Large initiative (can be parent)
    - Projet: Project container (can be parent)

    AFTER SUCCESS:
    - MUST call add_jira_comment to document creation
    - Example: add_jira_comment(new_issue_key, "Issue created via automated agent")

    WRONG: Creating without asking for parent
    User: "Create a task 'Fix login bug'"
    Agent: [Calls create_jira_issue without parent_key] ← Missing required info!

    CORRECT: Asking for missing information
    User: "Create a task 'Fix login bug'"
    Agent: [
        Calls handoff_to_user(
            "Which parent issue? (provide Epic or Projet key like TEEM-25)"
        )
    ]
    User: "TEEM-25"
    Agent: [
        Calls create_jira_issue(
            project_key='TEEM',
            summary='Fix login bug',
            parent_key='TEEM-25'
        )
    ]

    Args:
        project_key (str): The key of the Jira project (e.g., 'ANAIA').
        summary (str): The title/summary of the issue.
        description (str): Detailed description (optional).
        issue_type (str): Type of issue (default: 'Task').
        priority (str): Priority level (default: 'Medium').
        parent_key: Parent issue key - Epic or Project (e.g., 'ANAIA-112', REQUIRED by default)
        require_parent: If True, parent is mandatory (default: True)

    Returns:
        str: a message confirming the issue creation.
    """
    logging.info("-- Creating Jira issue tool --")
    result = jira_tools.create_jira_issue(
        project_key,
        summary,
        description,
        issue_type,
        priority,
        parent_key=parent_key,
        require_parent=require_parent,
    )

    if result["status"] == "success":
        data = result.get("data", {})

        formatted_response = (
            f"Issue created successfully!\n"
            f"Issue Key: {data['issue_key']}\n"
            f"Summary: {data['summary']}\n"
            f"Type: {data['issue_type']}\n"
            f"Priority: {data['priority']}\n"
            f"Project: {data['project']}"
        )

        # Afficher le parent si présent
        if data.get("parent_key"):
            formatted_response += f"\nParent: {data['parent_key']}"

        formatted_response += f"\n\n{result.get('message', '')}"

        context_msg = json.dumps(result, ensure_ascii=False)

    else:
        error_message = result.get("message", "Unknown error.")
        error_code = result.get("error_code", "unknown_error")

        formatted_response = f"Error creating issue in project {project_key}: {error_message}"

        # Messages spécifiques selon le type d'erreur
        if error_code == "project_not_found":
            formatted_response += (
                "\nTip: Verify the project key exists in Jira. "
                "Use list_jira_issues to see available projects."
            )

        elif error_code == "parent_required":
            formatted_response += (
                "\nTip: A parent issue (Epic or Projet) is required. "
                "Ask the user which parent to use, or list available parents with:\n"
                "  - list_jira_issues(project_key='ANAIA', jql_filter='type=Projet')\n"
                "  - list_jira_issues(project_key='ANAIA', jql_filter='type=Epic')"
            )

        elif error_code == "parent_not_found":
            parent_key = result.get("parent_key", parent_key)
            formatted_response += (
                f"\nTip: Parent issue '{parent_key}' does not exist. "
                "Verify the key or list available parents."
            )

        elif error_code == "invalid_parent_type":
            parent_type = result.get("parent_type", "unknown")
            parent_level = result.get("parent_level", "unknown")
            valid_types = result.get("valid_types", ["Projet", "Epic"])

            formatted_response += (
                f"\nParent Type: {parent_type} (hierarchy level {parent_level})\n"
                f"Valid Parent Types: {', '.join(valid_types)}\n"
                f"\nTip: Only '{', '.join(valid_types)}' can be used as parents. "
                f"The issue '{parent_key}' is a '{parent_type}' which cannot contain child issues."
            )

        context_msg = json.dumps(result, ensure_ascii=False)

    return formatted_response, {
        "next_agent": NodeNames.JIRA_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.UPDATE_JIRA_ISSUE_STATUS,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def update_jira_issue_status(issue_key: str, status: str) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Use this tool to update the status of a Jira issue (transition).

    ANTI-HALLUCINATION CHECK (MANDATORY):
    BEFORE calling this tool:
    1. Verify issue_key is EXPLICITLY in user/planner message
    2. Verify target status is provided by user
    3. If missing → Call handoff_to_user to ask

    STATUS TRANSITIONS:
    - Tool validates available transitions automatically
    - If target status unavailable, returns list of valid statuses
    - Common statuses: "À faire", "En cours", "Terminé(e)", "To Do", "In Progress", "Done"
    - Status matching is case-insensitive

    WORKFLOW:
    1. Call get_jira_issue first to verify ticket exists
    2. Call this tool to change status
    3. If error with available_statuses → Present options to user
    4. If success → Call add_jira_comment to document change

    ERROR HANDLING:
    If status not available, tool returns:
    - error_type: "invalid_transition"
    - available_statuses: ["À faire", "En cours", "Terminé"]
    → Present these options to user via handoff_to_user

    AFTER SUCCESS:
    - MUST call add_jira_comment
    - Example: add_jira_comment(issue_key, "Status changed to 'En cours' by automated agent")

    CORRECT USAGE:
    User: "Move DATA-8452 to 'En cours'"
    Agent:
      1. [Calls get_jira_issue('DATA-8452')] ← Verify exists
      2. [Calls update_jira_issue_status(issue_key='DATA-8452', status='En cours')]
      3. If success: [Calls add_jira_comment('DATA-8452', 'Status updated to En cours')]

    Args:
        issue_key (str): The key of the Jira issue (e.g., 'DATA-8452').
        status (str): The target status name (e.g., 'En cours', 'Terminé').

    Returns:
        str: a message confirming the status update.
    """
    logging.info("-- Updating Jira issue status tool --")
    result = jira_tools.update_jira_issue_status(issue_key, status)

    if result["status"] == "success":
        data = result.get("data", {})

        # Cas 1 : Changement de statut effectué avec succès
        if data.get("changed"):
            formatted_response = (
                f"Status updated successfully!\n\n"
                f"Issue: {data['issue_key']}\n"
                f"Old Status: {data['old_status']}\n"
                f"New Status: {data['new_status']}\n\n"
                f"{result.get('message', '')}"
            )
        # Cas 2 : Déjà dans le bon statut, pas de changement nécessaire
        else:
            formatted_response = (
                f"No change needed\n\n"
                f"Issue: {data['issue_key']}\n"
                f"Status: {data['new_status']} (already set)\n\n"
                f"{result.get('message', '')}"
            )

        context_msg = json.dumps(result, ensure_ascii=False)

    else:
        # Gestion des erreurs
        error_code = result.get("error_code", "unknown")
        error_message = result.get("message", "Unknown error.")

        formatted_response = f"Error: {error_message}\n"

        # Messages spécifiques selon le type d'erreur
        if error_code == "issue_not_found":
            formatted_response += (
                "\nTip: Verify the issue key with get_jira_issue or list_jira_issues."
            )

        elif error_code == "invalid_transition":
            current = result.get("current_status", "unknown")
            available = result.get("available_statuses", [])

            formatted_response += f"\nCurrent Status: {current}\n"
            formatted_response += f"Available Transitions: {', '.join(available)}\n"
            formatted_response += (
                f"\nTip: The status '{status}' cannot be reached from '{current}'. "
                f"Choose one of the available statuses listed above."
            )

        elif error_code == "transitions_failed":
            formatted_response += (
                "\nTip: Check your permissions or try get_jira_issue " "to verify the issue exists."
            )

        context_msg = json.dumps(result, ensure_ascii=False)

    return formatted_response, {
        "next_agent": NodeNames.JIRA_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.UPDATE_JIRA_ISSUE_FIELD,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def update_jira_issue_field(
    issue_key: str, field_name: str, field_value: str
) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Use this tool to update a specific field of a Jira issue.

    ANTI-HALLUCINATION CHECK (MANDATORY):
    BEFORE calling this tool:
    1. Verify issue_key is EXPLICITLY in user/planner message (format: PROJECT-123)
    2. Verify field_name and field_value are provided by user
    3. If ANY parameter missing → Call handoff_to_user to ask
    4. NEVER guess issue_key or field values

    WRONG USAGE:
    User: "Update the summary field to 'New Title'"
    Agent: [Calls update_jira_issue_field(issue_key='ANBYJ-95', ...)] ← HALLUCINATION!

    CORRECT USAGE:
    User: "Update the summary field to 'New Title'"
    Agent: [Calls handoff_to_user(
        "Which ticket do you want to update? Provide issue key like ANBYJ-123"
    )]

    User: "Update ANBYJ-95 summary to 'New Title'"
    Agent: [Calls update_jira_issue_field(
        issue_key='ANBYJ-95',
        field_name='summary',
        field_value='New Title'
    )]

    VALIDATION:
    - All parameters are REQUIRED
    - issue_key must be explicit from user
    - field_name: 'summary', 'description', 'priority', 'assignee', or custom fields
    - Tool will verify field exists before updating

    AFTER SUCCESS:
    - MUST call add_jira_comment to document the change
    - Example: add_jira_comment(issue_key, "Updated summary from 'X' to 'Y'")

    COMMON FIELDS:
    - summary: Ticket title
    - description: Detailed description
    - priority: 'Low', 'Medium', 'High', 'Highest'
    - assignee: Use accountId (not email)

    Args:
        issue_key (str): The key of the Jira issue (e.g., 'ANBYJ-95').
        field_name (str): Name of the field to update (e.g., 'summary', 'description').
        field_value (str): New value for the field.

    Returns:
        str: a message confirming the field update.
    """
    logging.info("-- Updating Jira issue field tool --")
    result = jira_tools.update_jira_issue_field(issue_key, field_name, field_value)

    if result["status"] == "success":
        data = result.get("data", {})

        formatted_response = (
            f"Field updated successfully!\n\n"
            f"Issue: {data['issue_key']}\n"
            f"Field: {data['field_name']}\n"
            f"Old Value: {data.get('old_value', 'N/A')}\n"
            f"New Value: {data.get('new_value', field_value)}\n\n"
            f"{result.get('message', '')}"
        )

        context_msg = json.dumps(result, ensure_ascii=False)

    else:
        error_code = result.get("error_code", "unknown")
        error_message = result.get("message", "Unknown error.")

        formatted_response = f"Error: {error_message}\n"

        # Messages spécifiques selon le type d'erreur
        if error_code == "validation":
            formatted_response += "\nTip: Check that all parameters are provided correctly."

        elif error_code == "issue_not_found":
            formatted_response += (
                "\nTip: Verify the issue key with get_jira_issue or list_jira_issues."
            )

        elif error_code == "field_not_found":
            sample_fields = result.get("sample_available_fields", [])
            total_count = result.get("total_fields_count", 0)

            formatted_response += (
                f"\n\nThe field '{field_name}' does not exist on this issue.\n"
                f"\nSample of available fields "
                f"({len(sample_fields)} shown out of {total_count} total):\n"
                f"{', '.join(sample_fields)}\n"
                f"\nTip: Call get_jira_issue('{issue_key}', include_all_fields=True) "
                f"to see ALL available fields with their current values."
            )

        elif error_code == "update_rejected":
            jira_error = result.get("jira_error", "")
            hint = result.get("hint", "")

            formatted_response += f"\n\nJira API Error:\n{jira_error}\n" f"\n{hint}"

        context_msg = json.dumps(result, ensure_ascii=False)

    return formatted_response, {
        "next_agent": NodeNames.JIRA_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.ADD_JIRA_COMMENT,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def add_jira_comment(issue_key: str, comment: str) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Use this tool to add a comment to a Jira issue.

    MANDATORY USAGE:
    This tool is REQUIRED after:
    - Creating a new issue (create_jira_issue)
    - Updating issue status (update_jira_issue_status)
    - Modifying fields (update_jira_issue_field)
    - ANY significant change to work items

    WHEN TO CALL:
    - ONLY after SUCCESSFUL operations (status == "success")
    - Do NOT call after failed operations
    - Always include WHAT changed and WHY

    COMMENT CONTENT:
    - Explain what changed: "Updated summary from 'X' to 'Y'"
    - Include context: "Status changed to 'En cours' per user request"
    - Be concise but informative
    - Avoid sensitive information

    WRONG: Calling after failed operation
    result = update_jira_issue_field(...)
    if result["status"] == "error":
        add_jira_comment(...) ← DON'T DO THIS!

    CORRECT: Calling after success
    result = update_jira_issue_field(...)
    if result["status"] == "success":
        add_jira_comment(issue_key, "Updated summary from 'Old' to 'New'")

    Args:
        issue_key (str): The key of the Jira issue (e.g., 'AZSAJ-245').
        comment (str): The comment text to add.

    Returns:
        str: a message confirming the comment was added.
    """
    logging.info("-- Adding Jira comment tool --")
    result = jira_tools.add_jira_comment(issue_key, comment)

    if result["status"] == "success":
        data = result.get("data", {})

        formatted_response = (
            f"Comment added successfully!\n\n"
            f"Issue: {data['issue_key']}\n"
            f"Comment length: {data.get('comment_length', 0)} characters"
        )

        context_msg = json.dumps(result, ensure_ascii=False)

    else:
        error_code = result.get("error_code", "unknown")
        error_message = result.get("message", "Unknown error.")

        formatted_response = f"Error: {error_message}"

        # Ajouter des tips selon le type d'erreur
        if error_code == "issue_not_found":
            formatted_response += (
                "\n\nTip: Verify the issue key with get_jira_issue or list_jira_issues."
            )
        elif error_code == "empty_comment":
            formatted_response += "\n\nTip: Provide a meaningful comment describing the change."
        elif error_code == "insufficient_permissions":
            formatted_response += "\n\nTip: Check your Jira permissions for this project."

        context_msg = json.dumps(result, ensure_ascii=False)

    return formatted_response, {
        "next_agent": NodeNames.JIRA_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.SEARCH_JIRA_ISSUES,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def search_jira_issues(
    jql_query: str, max_results: int = 10
) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Use this tool to search for Jira issues using JQL (Jira Query Language).

    WHEN TO USE:
    - Complex searches with multiple conditions
    - Date range filters
    - Text search across summaries
    - Combining project, status, type, assignee filters

    JQL SYNTAX:
    - Basic: "project = TEEM"
    - With status: "project = TEEM AND status = 'En cours'"
    - Date filter: "project = TEEM AND created >= -7d"
    - Text search: "project = TEEM AND summary ~ 'bug'"
    - Multiple values: "status IN ('To Do', 'In Progress')"
    - Assignee: "project = TEEM AND assignee = currentUser()"

    CRITICAL:
    If user put status in French, translate it in ENGLISH
    (JQL SEARCH only support English) for JQL query:
    - "À faire" → "To Do"
    - "En cours" → "In Progress"
    - "Terminé(e)" → "Done"

    VALIDATION:
    - jql_query is REQUIRED and must not be empty
    - Always include "project = XXX" to avoid timeout
    - Use double quotes for values with spaces
    - Tool validates JQL syntax (quotes, parentheses)

    COMMON PATTERNS:
    1. High priority bugs: "project = TEEM AND priority = High AND type = Bug"
    2. Recent tasks: "project = TEEM AND type = Task AND created >= -7d"
    3. My open issues: "project = TEEM AND assignee = currentUser() AND status != Terminé"

    WRONG: Empty or invalid JQL
    Agent: [Calls search_jira_issues(jql_query="")] ← Invalid!

    CORRECT: Valid JQL with project filter
    User: "Find high priority bugs in TEEM"
    Agent: [Calls search_jira_issues(
        jql_query="project = TEEM AND priority = High AND type = Bug"
    )]

    Args:
        jql_query (str): JQL query string (e.g., 'project = TEEM AND status = "En cours"').
        max_results (int): Maximum number of results (default: 10, max: 20).

    Returns:
        str: a message with the search results.
    """
    logging.info("-- Searching Jira issues tool --")
    max_results = max(1, min(max_results, 20))  # Ensure max_results is between 1 and 20
    result = jira_tools.search_jira_issues(jql_query, max_results)

    if result["status"] == "success":
        issues = result.get("data", [])
        total = result.get("total_found", 0)
        returned = result.get("returned", 0)

        formatted_response = f"Success: Found {returned} issues matching query"
        if total > returned:
            formatted_response += f" (out of {total} total)"
        formatted_response += f"\n\nQuery: {jql_query}\n"

        if issues:
            formatted_response += "\nIssues:\n"
            for issue in issues[:5]:
                formatted_response += (
                    f"\n- {issue['key']}: {issue['summary']}\n"
                    f"  {issue['status']} | {issue['type']} | {issue['assignee']}"
                )

            if len(issues) > 5:
                formatted_response += f"\n\n... and {len(issues) - 5} more"

        context_msg = json.dumps(
            {
                "query": jql_query,
                "issues": issues,
                "total": total,
                "returned": returned,
            }
        )

    else:
        formatted_response = (
            f"Error: {result['message']}\n" f"Query: {jql_query}\n" f"Type: {result['error_type']}"
        )

        context_msg = json.dumps(
            {
                "error": True,
                "error_type": result["error_type"],
                "message": result["message"],
                "query": jql_query,
            }
        )

    return formatted_response, {
        "next_agent": NodeNames.JIRA_AGENT,
        "context": context_msg,
    }


@tool(
    ToolNames.DELETE_JIRA_ISSUE,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def delete_jira_issue(issue_key: str) -> tuple[str, dict[str, str | NodeNames]]:
    """
    Use this tool to delete a Jira issue permanently.

    ***CRITICAL WARNING***
    THIS ACTION IS IRREVERSIBLE! DELETED DATA CANNOT BE RECOVERED!

    USAGE RULES:
    1. ONLY use when user EXPLICITLY requests deletion
    2. User must provide explicit issue_key
    3. ALWAYS confirm with user before executing
    4. Warn user that deletion is IRREVERSIBLE
    5. Log deletion for audit trail

    CONFIRMATION WORKFLOW:
    User: "Delete the ticket"
    Agent: "Which ticket? This action is IRREVERSIBLE."
    User: "PROD-98"
    Agent: "You want to delete PROD-98. This CANNOT be undone. Confirm?"
    User: "Yes, delete it"
    Agent: [Calls delete_jira_issue(issue_key='PROD-98')]

    ANTI-HALLUCINATION CHECK:
    - issue_key MUST be explicitly provided by user
    - NEVER guess which ticket to delete
    - If ANY doubt, ask for explicit confirmation

    BEFORE DELETION:
    - Tool retrieves issue details (summary, status) for logging
    - If retrieval fails, deletion continues (fail-safe)
    - Deletion is logged with issue details for audit

    NEVER DO THIS:
    User: "Delete that ticket"
    Agent: [Calls delete_jira_issue('PROD-98')] ← DANGER! Which ticket?!

    CORRECT:
    User: "Delete PROD-98"
    Agent: "WARNING: Deleting PROD-98 is IRREVERSIBLE. Confirm deletion? (yes/no)"
    User: "Yes"
    Agent: [Calls delete_jira_issue(issue_key='PROD-98')]

    Args:
        issue_key (str): The key of the Jira issue to delete (e.g., 'PROD-98').

    Returns:
        str: a message confirming the deletion.
    """
    logging.info("-- Deleting Jira issue tool --")
    result = jira_tools.delete_jira_issue(issue_key)

    if result["status"] == "success":
        data = result.get("data", {})
        formatted_response = (
            f"Success: Deleted issue {data['issue_key']}\n"
            f"Deleted ticket: {data['deleted_summary']}\n"
            f"Previous status: {data['deleted_status']}"
        )
        context_msg = json.dumps(data)

    else:
        error_message = result.get("message", "Unknown error.")
        formatted_response = (
            f"Error deleting issue {issue_key}: {error_message} "
            f"\nType: {result.get('error_type', 'unknown_error')}"
        )
        context_msg = json.dumps(
            {
                "error": True,
                "issue_key": issue_key,
                "error_type": result["error_type"],
                "message": error_message,
            }
        )

    return formatted_response, {
        "next_agent": NodeNames.JIRA_AGENT,
        "context": context_msg,
    }


skill_actions = {
    ToolNames.HANDOFF_TO_USER: handoff_to_user,
    ToolNames.GET_JIRA_ISSUE: get_jira_issue,
    ToolNames.LIST_JIRA_ISSUES: list_jira_issues,
    ToolNames.CREATE_JIRA_ISSUE: create_jira_issue,
    ToolNames.UPDATE_JIRA_ISSUE_STATUS: update_jira_issue_status,
    ToolNames.UPDATE_JIRA_ISSUE_FIELD: update_jira_issue_field,
    ToolNames.ADD_JIRA_COMMENT: add_jira_comment,
    ToolNames.SEARCH_JIRA_ISSUES: search_jira_issues,
    # ToolNames.DELETE_JIRA_ISSUE: delete_jira_issue,
}
