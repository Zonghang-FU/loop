---
name: jira
description: Work with Jira, Atlassian tickets, issues, issue URLs, and issue keys such as ANAIA-148. Use this skill whenever the user provides a Jira URL or issue key, asks to read or summarize an issue, list or search issues, create an issue, update issue status or fields, add a comment, interpret a ticket's requirements, or verify whether a ticket is already done.
---

# Jira Issue Work

Use this skill for Jira issue retrieval, interpretation, search, creation, comments, status
changes, and field updates.

## Implementation

This skill is self-contained:

- `scripts/actions.py` exposes Jira actions.
- `scripts/jira_tools.py` contains Jira API helpers.
- `scripts/jira_config.py` contains Jira configuration.

Add new Jira behavior inside this skill directory. Do not add a shared Jira helper outside the
skill.

## Process

1. Confirm the issue key is explicit before any issue-specific action. Valid keys look like
   `ANAIA-148`.
2. Read the issue before interpreting or updating it.
3. Extract summary, status, description, acceptance criteria, explicit identifiers, constraints,
   files, commands, and delivery expectations.
4. Treat reads and searches as read-only.
5. Treat comments, status changes, field edits, issue creation, and deletion as state-changing.
6. Make state-changing Jira updates only when the user asked for them or the workflow context
   clearly authorizes them.

If an issue is already Done, Completed, Closed, Resolved, or equivalent, report that status and
summarize the known completion state. Do not imply new work was performed unless it was.

## Action Call Examples

Read an issue:

Action: `get_jira_issue`

Arguments:

```json
{"issue_key": "ANAIA-148", "include_all_fields": false}
```

Search issues:

Action: `search_jira_issues`

Arguments:

```json
{"jql_query": "project = ANAIA AND status != Done ORDER BY updated DESC", "max_results": 10}
```

Add a comment:

Action: `add_jira_comment`

Arguments:

```json
{"issue_key": "ANAIA-148", "comment": "Work completed. Branch: feature/anaia-148. Blockers: none."}
```

Update status or field:

Action: `update_jira_issue_status`

Arguments:

```json
{"issue_key": "ANAIA-148", "status": "Done"}
```

Action: `update_jira_issue_field`

Arguments:

```json
{"issue_key": "ANAIA-148", "field_name": "summary", "field_value": "Updated summary"}
```

## Safety

Do not invent issue keys, project keys, status names, field names, parent keys, assignees, or
transition names.

Deletion is not exposed by default. If deletion support is added later, require immediate explicit
confirmation for the exact issue key.

## Completion

Return the issue key, summary, current status, extracted requirements, Jira actions taken, and any
remaining blocker or approval needed.
