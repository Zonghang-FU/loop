"""Local Git worktree helpers for the terminal skill.

The repository cache lives in work/projet_from_git/<project-slug>. Editable copies live in
draft/<session_id>/<project-slug>. File inspection, branch checkout, commits, and pushes use these
local worktrees.
"""

from __future__ import annotations

import os
import re
import shutil
import shlex
import subprocess
from pathlib import Path
from urllib.parse import quote, urlsplit, urlunsplit

from app_code.runtime_paths import repo_root, work_root
from app_code.skills.terminal.scripts import draft_files

PROJECT_ROOT = repo_root()
WORK_ROOT = work_root()
PROJECT_CACHE_ROOT = WORK_ROOT / "projet_from_git"


class GitLocalRepoError(RuntimeError):
    """Raised when local Git repository preparation fails."""


def project_slug(project_path: str) -> str:
    """Return a filesystem-safe project directory name."""

    cleaned = project_path.strip().strip("/")
    return re.sub(r"[^A-Za-z0-9._-]+", "__", cleaned) or "project"


def normalize_project_path(project_or_url: str) -> str:
    """Normalize a GitLab project path or HTTPS clone URL to namespace/project."""

    value = project_or_url.strip()
    if value.startswith(("http://", "https://")):
        parts = urlsplit(value)
        path = parts.path.strip("/")
        if path.endswith(".git"):
            path = path[:-4]
        return path
    if value.endswith(".git"):
        value = value[:-4]
    return value.strip("/")


def default_clone_url(project_path: str) -> str:
    configured_repo = os.environ.get("GITLAB_REPO", "").strip()
    configured_project = normalize_project_path(os.environ.get("GITLAB_PROJECT", "").strip())
    normalized = normalize_project_path(project_path)
    if configured_repo and configured_project == normalized:
        return configured_repo
    return f"https://gitlab.com/{normalized}.git"


def project_cache_dir(project_path: str) -> Path:
    return PROJECT_CACHE_ROOT / project_slug(project_path)


def project_draft_dir(session_id: str, project_path: str) -> Path:
    return draft_files.get_session_draft_dir(session_id) / project_slug(project_path)


def _token() -> str:
    return os.environ.get("CUSTOMCONNSTR_GITLAB_JAP", os.environ.get("GITLAB_JAP", ""))


def _authenticated_url(clean_url: str) -> str:
    token = _token()
    if not token:
        raise GitLocalRepoError("Missing GitLab token: GITLAB_JAP")
    parts = urlsplit(clean_url)
    if parts.scheme not in {"http", "https"}:
        return clean_url
    netloc = f"oauth2:{quote(token, safe='')}@{parts.netloc}"
    return urlunsplit((parts.scheme, netloc, parts.path, parts.query, parts.fragment))


def _mask_token(text: str) -> str:
    token = _token()
    return text.replace(token, "***") if token else text


def _run_git(args: list[str], cwd: Path | None = None, timeout: int = 120) -> subprocess.CompletedProcess:
    cmd = ["git", *args]
    result = subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if result.returncode != 0:
        command = _mask_token(" ".join(cmd))
        stderr = _mask_token(result.stderr.strip())
        stdout = _mask_token(result.stdout.strip())
        raise GitLocalRepoError(
            f"Git command failed ({result.returncode}): {command}\nSTDOUT: {stdout}\nSTDERR: {stderr}"
        )
    return result


STATE_CHANGING_GIT_SUBCOMMANDS = {
    "commit",
    "push",
    "tag",
    "reset",
    "rebase",
    "merge",
    "cherry-pick",
    "revert",
    "clean",
    "rm",
}


def execute_git_command_string(
    repo_dir: Path,
    clone_url: str,
    command: str,
    *,
    user_confirmed_state_change: bool = False,
    timeout: int = 120,
) -> str:
    """Execute a model-generated git command inside a prepared local worktree."""

    command_parts = _split_git_command_sequence(command)
    outputs = []
    for part in command_parts:
        outputs.append(
            _execute_single_git_command(
                repo_dir,
                clone_url,
                part,
                user_confirmed_state_change=user_confirmed_state_change,
                timeout=timeout,
            )
        )
    return "\n\n".join(outputs)


def _split_git_command_sequence(command: str) -> list[str]:
    """Split a limited git-only command sequence without invoking a shell."""

    if any(token in command for token in ("|", ">", "<", "`", "$(", "\n")):
        raise GitLocalRepoError("Shell pipes, redirects, command substitution, and newlines are not allowed.")
    lexer = shlex.shlex(command, posix=True, punctuation_chars=";&")
    lexer.whitespace_split = True
    tokens = list(lexer)
    commands: list[list[str]] = [[]]
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if token == ";" or token == "&&":
            if not commands[-1]:
                raise GitLocalRepoError("Empty git command in command sequence.")
            commands.append([])
        elif token == "&" or token == "||":
            raise GitLocalRepoError(f"Unsupported shell operator: {token}")
        else:
            commands[-1].append(token)
        index += 1
    if not commands or not commands[-1]:
        raise GitLocalRepoError("Empty git command.")
    return [" ".join(shlex.quote(token) for token in parts) for parts in commands]


def _execute_single_git_command(
    repo_dir: Path,
    clone_url: str,
    command: str,
    *,
    user_confirmed_state_change: bool,
    timeout: int,
) -> str:
    try:
        parts = shlex.split(command)
    except ValueError as exc:
        raise GitLocalRepoError(f"Invalid git command syntax: {exc}") from exc

    if not parts or parts[0] != "git":
        raise GitLocalRepoError("Only commands beginning with `git` are allowed.")
    if len(parts) < 2:
        raise GitLocalRepoError("A git subcommand is required.")

    subcommand = parts[1]
    if subcommand in STATE_CHANGING_GIT_SUBCOMMANDS and not user_confirmed_state_change:
        raise GitLocalRepoError(
            f"`git {subcommand}` changes repository state and requires explicit user confirmation."
        )
    if subcommand == "checkout" and "--" in parts and not user_confirmed_state_change:
        raise GitLocalRepoError("Path checkout changes files and requires explicit user confirmation.")

    if subcommand in {"fetch", "pull", "push"}:
        with _with_auth_remote(repo_dir, clone_url):
            result = _run_git(parts[1:], cwd=repo_dir, timeout=timeout)
    else:
        result = _run_git(parts[1:], cwd=repo_dir, timeout=timeout)

    stdout = _mask_token(result.stdout.strip()) or "(empty)"
    stderr = _mask_token(result.stderr.strip()) or "(empty)"
    return (
        f"COMMAND: {command}\n"
        f"Working Directory: {repo_dir}\n"
        f"Return Code: {result.returncode}\n"
        f"STDOUT:\n{stdout}\n"
        f"STDERR:\n{stderr}"
    )


def _with_auth_remote(repo_dir: Path, clean_url: str):
    """Temporarily set origin to an authenticated URL for one network operation block."""

    class RemoteContext:
        def __enter__(self):
            _run_git(["remote", "set-url", "origin", _authenticated_url(clean_url)], cwd=repo_dir)
            return self

        def __exit__(self, exc_type, exc, tb):
            _run_git(["remote", "set-url", "origin", clean_url], cwd=repo_dir)
            return False

    return RemoteContext()


def is_git_repo(path: Path) -> bool:
    return (path / ".git").exists()


def ensure_project_cache(project_path: str, clone_url: str, branch_name: str | None = None) -> Path:
    """Clone the project into work/projet_from_git or update it if already present."""

    PROJECT_CACHE_ROOT.mkdir(parents=True, exist_ok=True)
    cache_dir = project_cache_dir(project_path)
    auth_url = _authenticated_url(clone_url)

    if not cache_dir.exists():
        _run_git(["clone", auth_url, str(cache_dir)], cwd=PROJECT_CACHE_ROOT, timeout=300)
        _run_git(["remote", "set-url", "origin", clone_url], cwd=cache_dir)
    elif not is_git_repo(cache_dir):
        raise GitLocalRepoError(f"Project cache path exists but is not a git repository: {cache_dir}")

    with _with_auth_remote(cache_dir, clone_url):
        _run_git(["fetch", "--all", "--prune"], cwd=cache_dir, timeout=180)
        if branch_name:
            checkout_branch(cache_dir, branch_name)
            _run_git(["pull", "origin", branch_name, "--ff-only"], cwd=cache_dir, timeout=180)
    return cache_dir


def checkout_branch(repo_dir: Path, branch_name: str) -> None:
    """Checkout an existing local or remote branch."""

    try:
        _run_git(["checkout", branch_name], cwd=repo_dir)
    except GitLocalRepoError:
        _run_git(["checkout", "-B", branch_name, f"origin/{branch_name}"], cwd=repo_dir)


def create_or_checkout_branch(repo_dir: Path, branch_name: str, ref_branch: str | None = None) -> None:
    """Create a branch from ref_branch when absent, otherwise checkout it."""

    branches = _run_git(["branch", "--list", branch_name], cwd=repo_dir).stdout.strip()
    if branches:
        checkout_branch(repo_dir, branch_name)
        return
    if ref_branch:
        checkout_branch(repo_dir, ref_branch)
    _run_git(["checkout", "-B", branch_name], cwd=repo_dir)


def active_repo_dir(session_id: str, project_path: str) -> Path:
    """Return the editable draft repo if present; otherwise the shared work cache."""

    draft_dir = project_draft_dir(session_id, project_path)
    if is_git_repo(draft_dir):
        return draft_dir
    return project_cache_dir(project_path)


def ensure_project_for_git(
    session_id: str,
    project_path: str,
    clone_url: str,
    branch_name: str | None = None,
) -> tuple[Path, str]:
    """Ensure cache exists, then return draft worktree if it exists, otherwise cache."""

    cache_dir = ensure_project_cache(project_path, clone_url, branch_name)
    draft_dir = project_draft_dir(session_id, project_path)
    if is_git_repo(draft_dir):
        if branch_name:
            checkout_branch(draft_dir, branch_name)
        return draft_dir, "draft"
    return cache_dir, "cache"


def ensure_project_draft_copy(
    session_id: str,
    project_path: str,
    clone_url: str,
    branch_name: str | None = None,
) -> Path:
    """Copy the cached project to draft/<session_id>/<project> for local editing."""

    cache_dir = ensure_project_cache(project_path, clone_url, branch_name)
    draft_dir = project_draft_dir(session_id, project_path)
    if not draft_dir.exists():
        shutil.copytree(cache_dir, draft_dir, ignore=shutil.ignore_patterns(".venv", "node_modules"))
    elif not is_git_repo(draft_dir):
        raise GitLocalRepoError(f"Draft project path exists but is not a git repository: {draft_dir}")
    if branch_name:
        checkout_branch(draft_dir, branch_name)
    return draft_dir


def list_repo_files(repo_dir: Path) -> list[str]:
    result = _run_git(["ls-files"], cwd=repo_dir)
    return [line for line in result.stdout.splitlines() if line.strip()]


def list_branches(repo_dir: Path) -> list[str]:
    result = _run_git(["branch", "-r"], cwd=repo_dir)
    branches = []
    for line in result.stdout.splitlines():
        cleaned = line.strip()
        if not cleaned or "->" in cleaned:
            continue
        if cleaned.startswith("origin/"):
            cleaned = cleaned[len("origin/") :]
        branches.append(cleaned)
    return sorted(set(branches))


def read_repo_file(repo_dir: Path, file_path: str) -> str:
    target = (repo_dir / file_path).resolve()
    try:
        target.relative_to(repo_dir.resolve())
    except ValueError as exc:
        raise GitLocalRepoError(f"Path escapes repository: {file_path}") from exc
    return target.read_text(encoding="utf-8")


def ensure_commit_identity(repo_dir: Path) -> None:
    """Set a local commit identity when the repository does not already define one."""

    name = _run_git(["config", "--get", "user.name"], cwd=repo_dir).stdout.strip() if _config_exists(repo_dir, "user.name") else ""
    email = _run_git(["config", "--get", "user.email"], cwd=repo_dir).stdout.strip() if _config_exists(repo_dir, "user.email") else ""
    if not name:
        _run_git(["config", "user.name", os.environ.get("GIT_AUTHOR_NAME", "DevSQL Agent")], cwd=repo_dir)
    if not email:
        _run_git(["config", "user.email", os.environ.get("GIT_AUTHOR_EMAIL", "devsql-agent@example.local")], cwd=repo_dir)


def _config_exists(repo_dir: Path, key: str) -> bool:
    result = subprocess.run(
        ["git", "config", "--get", key],
        cwd=repo_dir,
        capture_output=True,
        text=True,
        timeout=30,
    )
    return result.returncode == 0 and bool(result.stdout.strip())


def write_commit_push(
    repo_dir: Path,
    clone_url: str,
    file_path: str,
    content: str,
    branch_name: str,
    commit_message: str,
) -> str:
    """Write a file, commit it locally, and push the branch to GitLab."""

    checkout_branch(repo_dir, branch_name)
    target = (repo_dir / file_path).resolve()
    try:
        target.relative_to(repo_dir.resolve())
    except ValueError as exc:
        raise GitLocalRepoError(f"Path escapes repository: {file_path}") from exc
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    _run_git(["add", file_path], cwd=repo_dir)
    status = _run_git(["status", "--porcelain"], cwd=repo_dir).stdout.strip()
    if not status:
        return f"No local changes to commit in {repo_dir}."
    ensure_commit_identity(repo_dir)
    _run_git(["commit", "-m", commit_message], cwd=repo_dir)
    with _with_auth_remote(repo_dir, clone_url):
        _run_git(["push", "origin", branch_name], cwd=repo_dir, timeout=180)
    sha = _run_git(["rev-parse", "--short", "HEAD"], cwd=repo_dir).stdout.strip()
    return f"Committed and pushed {file_path} on {branch_name}. Commit: {sha}. Worktree: {repo_dir}"


def commit_existing_changes_push(
    repo_dir: Path,
    clone_url: str,
    branch_name: str,
    commit_message: str,
) -> str:
    """Commit all existing draft worktree changes and push the branch."""

    checkout_branch(repo_dir, branch_name)
    _run_git(["add", "-A"], cwd=repo_dir)
    status = _run_git(["status", "--porcelain"], cwd=repo_dir).stdout.strip()
    if not status:
        ahead = _local_commits_ahead(repo_dir, branch_name)
        if ahead <= 0:
            return f"No local changes to commit or push in {repo_dir}."
        with _with_auth_remote(repo_dir, clone_url):
            _run_git(["push", "origin", branch_name], cwd=repo_dir, timeout=180)
        sha = _run_git(["rev-parse", "--short", "HEAD"], cwd=repo_dir).stdout.strip()
        return f"Pushed {ahead} existing local commit(s) on branch {branch_name}. Commit: {sha}. Worktree: {repo_dir}"
    ensure_commit_identity(repo_dir)
    _run_git(["commit", "-m", commit_message], cwd=repo_dir)
    with _with_auth_remote(repo_dir, clone_url):
        _run_git(["push", "origin", branch_name], cwd=repo_dir, timeout=180)
    sha = _run_git(["rev-parse", "--short", "HEAD"], cwd=repo_dir).stdout.strip()
    return f"Committed and pushed branch {branch_name}. Commit: {sha}. Worktree: {repo_dir}"


def _local_commits_ahead(repo_dir: Path, branch_name: str) -> int:
    result = subprocess.run(
        ["git", "rev-list", "--count", f"origin/{branch_name}..HEAD"],
        cwd=repo_dir,
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        return 0
    try:
        return int(result.stdout.strip() or "0")
    except ValueError:
        return 0
