"""
Shared draft file tools.

Provides a structured workspace under draft/{session_id}/ for temporary files
produced by ENV and BDD agents during a session.

- terminal skill writes .py / .sh / .java files here.
- BDD agent writes .sql files here.
- CODE agent reads from here to commit files to GitLab.

The draft/ folder must be added to .gitignore.
"""

import time
from pathlib import Path
from typing import Annotated

from langchain_core.tools import InjectedToolArg, tool

from app_code.runtime_paths import draft_root
from app_code.skills_runtime.structs import NodeNames, ToolNames, WorkflowState

# Root directory for all draft files, absolute path.
DRAFT_BASE_DIR = draft_root()


def get_session_draft_dir(session_id: str) -> Path:
    """Return the draft directory for a given session and ensure it exists.

    Args:
        session_id: The session UUID as a string.

    Returns:
        Path: the path to draft/{session_id}/.
    """
    session_dir = DRAFT_BASE_DIR / str(session_id)
    session_dir.mkdir(parents=True, exist_ok=True)
    return session_dir


@tool(ToolNames.LIST_DRAFT_FILES, parse_docstring=True, response_format="content_and_artifact")
def list_draft_files(state: Annotated[dict, InjectedToolArg]) -> tuple[str, dict]:
    """List all files in the current session's draft directory.

    Use this tool to see which files have been created during this session,
    before deciding which ones to read, commit or clean up.

    Args:
        state: Injected automatically. No parameter required from the LLM.

    Returns:
        str: The list of files in the draft directory for the current session.
    """
    session_id = str(state["session_id"]) if state else "unknown"
    next_agent = state["next_agent"] if state else NodeNames.CODE_AGENT

    session_dir = get_session_draft_dir(session_id)
    files = [f for f in session_dir.iterdir() if f.name != "env"] if session_dir.exists() else []

    if not files:
        return (
            f"No files found in draft/{session_id}/.",
            {"next_agent": next_agent},
        )

    file_list = "\n".join(f" - {f.name} ({f.stat().st_size} bytes)" for f in files)
    return (
        f"Files in draft/{session_id}/:\n{file_list}",
        {"next_agent": next_agent},
    )


@tool(
    ToolNames.DELETE_CURRENT_SESSION_FILE,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def delete_current_session_file(
    filename: str,
    state: Annotated[dict, InjectedToolArg] = None,
) -> tuple[str, dict]:
    """
    Delete a specific file from the current session's draft directory.

    Use this tool to delete a single file produced during this session (e.g. an outdated
    script that has been replaced by a newer version). Only affects the current session.

    **IMPORTANT:**
    - Only files inside draft/{current_session_id}/ can be deleted.
    - The env file is protected and cannot be deleted.

    Args:
        filename (str): Name of the file to delete (e.g. 'old_script.py').

    Returns:
        str: Confirmation or error message.
    """
    session_id = str(state["session_id"]) if state else "unknown"
    next_agent = state["next_agent"] if state else NodeNames.CODE_AGENT

    if filename == "env":
        return (
            "Deletion denied: env file cannot be deleted.",
            {"next_agent": next_agent},
        )

    session_dir = get_session_draft_dir(session_id)
    file_path = session_dir / filename

    if not file_path.exists():
        return (
            f"File '{filename}' not found in draft/{session_id}/.",
            {"next_agent": next_agent},
        )

    file_path.unlink()

    # Remove folder if empty
    if not any(f for f in session_dir.iterdir() if f.name != "env"):
        for f in session_dir.iterdir():
            if f.name == "env":
                continue
            f.unlink()
        session_dir.rmdir()

    return (
        f"File '{filename}' successfully deleted from draft/{session_id}/.",
        {"next_agent": next_agent},
    )


@tool(
    ToolNames.CLEANUP_OLD_DRAFT_FILES,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def cleanup_old_draft_files(
    max_age_hours: float = 24.0, state: Annotated[dict, InjectedToolArg] = None
) -> tuple[str, dict]:
    """Delete draft session folders older than a given number of hours, across all sessions.

    This tool scans every session folder under draft/ and deletes individual files
    whose last modification time exceeds max_age_hours. This applies to ALL sessions,
    including the current one. Empty session folders are removed after their files
    are deleted.

    Use this tool when the user asks to clean up old draft files, or periodically
    to avoid filling the draft/ directory.

    Args:
        max_age_hours (float): Age threshold in hours. Files older than this will be
            deleted. Defaults to 24 hours. Pass max_age_hours=N to change the threshold.

    Returns:
        str: The exact list of files that were deleted. Read this result carefully
            before informing the user.
    """
    next_agent = state["next_agent"] if state else NodeNames.CODE_AGENT
    # current_session_id = str(state["session_id"]) if state else None

    if not DRAFT_BASE_DIR.exists():
        return "Draft directory does not exist yet. Nothing to clean.", {"next_agent": next_agent}

    now = time.time()
    max_age_seconds = max_age_hours * 3600
    deleted_files = []
    skipped_files = []

    for session_dir in DRAFT_BASE_DIR.iterdir():
        if not session_dir.is_dir():
            continue
        for file_path in session_dir.iterdir():
            if file_path.name == "env":
                continue
            if not file_path.is_file():
                continue
            age_seconds = now - file_path.stat().st_mtime
            if age_seconds > max_age_seconds:
                file_path.unlink()
                deleted_files.append(f"{session_dir.name}/{file_path.name}")
            else:
                skipped_files.append(file_path.name)
        # Remove session folder if now empty
        if not any(f for f in session_dir.iterdir() if f.name != "env"):
            for f in session_dir.iterdir():
                f.unlink()
            session_dir.rmdir()

    if not deleted_files:
        return (
            f"No files older than {max_age_hours}h found. {len(skipped_files)} file(s) kept.",
            {"next_agent": next_agent},
        )

    return (
        f"Deleted {len(deleted_files)} file(s) older than {max_age_hours}h:\n"
        + "\n".join(f" - {f}" for f in deleted_files)
        + (f"\n{len(skipped_files)} file(s) kept (still recent)." if skipped_files else ""),
        {"next_agent": next_agent},
    )


@tool(
    ToolNames.GET_DRAFT_FILE_FOR_COMMIT,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def get_draft_file_for_commit(
    filename: str, state: Annotated[dict, InjectedToolArg]
) -> tuple[str, dict]:
    """Read a file from the current session's draft directory and return its content
    ready to be committed to GitLab via receive_file_and_commit.

    Use this tool to retrieve a file produced by the terminal skill (.py/.sh) or the BDD agent
    (.sql) during this session. The file content is returned and ready to be used
    displayed, analyzed, modified, or passed to receive_file_and_commit().

    IMPORTANT: This tool only reads and returns the file content.
    Committing to GitLab via receive_file_and_commit() must ONLY be done if the user
    explicitly requested a commit. Do not commit automatically.

    The returned context always contains a 'success' flag (bool):
    - If success is True  : 'filename' and 'content' are available and ready to be used.
    - If success is False : the file could not be read. Inform the user.

    Args:
        filename (str): Name of the file in the draft directory (e.g. 'export.py', 'migration.sql').

    Returns:
        str: Confirmation with file name and size, or error message.
            context always contains 'success' (bool), 'filename' (str),
            and 'content' (str | None).
    """
    session_id = str(state["session_id"]) if state else "unknown"
    next_agent = state["next_agent"] if state else NodeNames.CODE_AGENT

    if filename == "env":
        return (
            "Access denied: env file cannot be read or committed.",
            {
                "next_agent": next_agent,
                "context": {
                    "success": False,
                    "filename": filename,
                    "content": None,
                    "error": "Access denied",
                },
            },
        )

    file_path = get_session_draft_dir(session_id) / filename

    # --- Case 1: file does not exist ---
    if not file_path.exists():
        return (
            f"File '{filename}' not found in draft/{session_id}/. "
            f"Use list_draft_files to see available files.",
            {
                "next_agent": next_agent,
                "context": {
                    "success": False,
                    "filename": filename,
                    "content": None,
                    "error": "File not found",
                },
            },
        )

    # --- Case 2: file exists, try to read it ---
    try:
        content = file_path.read_text(encoding="utf-8")
        return (
            f"File '{filename}' read ({len(content)} chars). "
            "Content is available. Ready for commit if user confirms.",
            {
                "next_agent": next_agent,
                "context": {
                    "success": True,
                    "filename": filename,
                    "content": content,
                    "error": None,
                },
            },
        )

    # --- Case 3: file exists but cannot be read ---
    except Exception as e:
        return (
            f"Error reading '{filename}': {e}",
            {
                "next_agent": next_agent,
                "context": {
                    "success": False,
                    "filename": filename,
                    "content": None,
                    "error": str(e),
                },
            },
        )
