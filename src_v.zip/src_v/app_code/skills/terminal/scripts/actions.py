"""Terminal skill actions."""

import os
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Annotated

from dotenv import dotenv_values
from langchain_core.tools import InjectedToolArg, tool

from app_code.runtime_paths import repo_root, work_root
from app_code.skills.terminal.scripts import draft_files as draft_tools
from app_code.skills.terminal.scripts import local_repo
from app_code.skills.bdd.scripts.db_config import DB_CONFIG
from app_code.skills.bdd.scripts.db_tools import get_database_context
from app_code.skills_runtime.runtime_services import emit_skill_status
from app_code.skills_runtime.storage import get_user_value, save_user_value
from app_code.skills_runtime.structs import NodeNames, ToolNames, WorkflowState

# Text files the terminal skill may read/write directly. Binary artifacts such as .pptx and .xlsx
# should be produced by scripts executed inside the session draft directory.
ENV_ALLOWED_EXTENSIONS = {
    ".py",
    ".sh",
    ".bash",
    ".java",
    ".js",
    ".ts",
    ".html",
    ".htm",
    ".css",
    ".json",
    ".md",
    ".txt",
    ".csv",
    ".xml",
    ".svg",
}

PROJECT_ROOT = repo_root()
WORK_ROOT = work_root()

DEFAULT_WHITELIST_CLI_COMMANDS = {
    "git",
    "python",
    "python3",
    "pip",
    "pip3",
    "uv",
    "pytest",
    "ruff",
    "mypy",
    "node",
    "npm",
    "npx",
    "yarn",
    "java",
    "javac",
    "mvn",
    "gradle",
    "ls",
    "cat",
    "echo",
    "pwd",
    "find",
    "grep",
    "wc",
    "head",
    "tail",
    "diff",
    "mkdir",
    "apt-get",
    "apt",
    "brew",
    "docker",
}

DEFAULT_BLOCKLIST_RUN_COMMANDS = {
    "rm",
    "rmdir",
    "del",
    "erase",
    "mv",
    "move",
    "rename",
    "cd",
    "sudo",
    "su",
    "chmod",
    "chown",
    "chgrp",
    "dd",
    "mkfs",
    "fdisk",
    "parted",
    "curl",
    "wget",
    "nc",
    "netcat",
    "ncat",
    "kill",
    "killall",
    "pkill",
    "shutdown",
    "reboot",
    "halt",
    "bash",
    "sh",
    "zsh",
    "powershell",
    "cmd",
    "export",
    "set",
    "unset",
}


def _split_env_command_set(env_name: str, default: set[str] | None = None) -> set[str]:
    raw_value = os.getenv(env_name)
    if raw_value is None:
        return set(default or set())
    return {item.strip() for item in raw_value.replace("\n", ",").split(",") if item.strip()}


def _allowed_cli_commands() -> set[str]:
    return _split_env_command_set("WHITELIST_CLI_COMMANDS", None)


def _blocked_cli_commands() -> set[str]:
    return _split_env_command_set("BLOCKLIST_RUN_COMMANDS", DEFAULT_BLOCKLIST_RUN_COMMANDS)


def _base_command(command_parts: str) -> str:
    try:
        parts = shlex.split(command_parts)
    except ValueError:
        return ""
    return parts[0] if parts else ""


def _command_parts(command_parts: str) -> list[str]:
    return shlex.split(command_parts)


def _session_id(state: dict | None) -> str:
    return str(state["session_id"]) if state else "unknown"


def _safe_roots(session_id: str) -> tuple[Path, Path]:
    session_draft = draft_tools.get_session_draft_dir(session_id).resolve()
    work_root = WORK_ROOT.resolve()
    work_root.mkdir(parents=True, exist_ok=True)
    return session_draft, work_root


def _is_relative_to(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _sandbox_error(path: str) -> str:
    return (
        "Access denied by terminal sandbox. Terminal actions may only access files under "
        "the current session draft directory or the project work directory. "
        f"Rejected path: {path}"
    )


def _resolve_sandbox_path(
    requested_path: str,
    state: dict | None,
    *,
    default_root: str = "draft",
    must_exist: bool = False,
    allow_directory: bool = True,
) -> Path:
    """Resolve a model supplied path into the terminal sandbox."""

    session_draft, work_root = _safe_roots(_session_id(state))
    raw = str(requested_path or ".").strip()
    raw_path = Path(raw).expanduser()

    if raw_path.is_absolute():
        candidate = raw_path.resolve()
    else:
        parts = raw_path.parts
        if parts and parts[0] == "work":
            candidate = (work_root / Path(*parts[1:])).resolve()
        elif parts and parts[0] == "draft":
            if len(parts) >= 2 and parts[1] == _session_id(state):
                candidate = (session_draft / Path(*parts[2:])).resolve()
            else:
                candidate = (session_draft / Path(*parts[1:])).resolve()
        elif default_root == "work":
            candidate = (work_root / raw_path).resolve()
        else:
            candidate = (session_draft / raw_path).resolve()

    if not (_is_relative_to(candidate, session_draft) or _is_relative_to(candidate, work_root)):
        raise PermissionError(_sandbox_error(raw))

    if must_exist and not candidate.exists():
        raise FileNotFoundError(f"Path not found in terminal sandbox: {raw}")
    if not allow_directory and candidate.exists() and candidate.is_dir():
        raise IsADirectoryError(f"Expected a file, got directory: {raw}")
    return candidate


def _validate_command_paths(parts: list[str], state: dict | None) -> str | None:
    for token in parts:
        if not token or token.startswith("-") or token in {".", "./"}:
            continue
        if token.startswith(("http://", "https://")):
            continue
        maybe_path = any(marker in token for marker in ("/", "\\", "~")) or token.startswith(".")
        if not maybe_path:
            continue
        try:
            _resolve_sandbox_path(token, state, must_exist=False)
        except Exception as exc:
            return str(exc)
    return None


def _session_cwd(state: dict | None, working_dir: str | None = None) -> Path:
    return _resolve_sandbox_path(working_dir or ".", state, must_exist=True)


def _tool_artifact(context: str | None = None) -> dict[str, str | NodeNames]:
    artifact: dict[str, str | NodeNames] = {"next_agent": NodeNames.CODE_AGENT}
    if context is not None:
        artifact["context"] = context
    return artifact


def _blocked_artifact(message: str) -> tuple[str, dict[str, str | NodeNames]]:
    return message, _tool_artifact(message)


def _path_display(path: Path, state: dict | None) -> str:
    session_draft, work_root = _safe_roots(_session_id(state))
    resolved = path.resolve()
    if _is_relative_to(resolved, session_draft):
        return f"draft/{_session_id(state)}/{resolved.relative_to(session_draft)}"
    if _is_relative_to(resolved, work_root):
        return f"work/{resolved.relative_to(work_root)}"
    return str(resolved)


async def _current_project_path(state: dict, project_path: str | None = None) -> str | None:
    selected = project_path or await get_user_value(state, "state_data", "project_path")
    return local_repo.normalize_project_path(selected) if selected else None


async def _current_branch_name(state: dict, branch_name: str | None = None) -> str | None:
    return branch_name or await get_user_value(state, "state_data", "branch_name") or os.environ.get("GITLAB_BRANCH")


def _clone_url_for_project_path(project_path: str) -> str:
    return local_repo.default_clone_url(project_path)



@tool(ToolNames.READ_FILE, parse_docstring=True, response_format="content_and_artifact")
def read_file(
    filename: str, state: Annotated[dict, InjectedToolArg] = None
) -> tuple[str, dict[str, str | NodeNames]]:
    """Read the content of a file from the current session's draft directory.

    Use this tool to read a .py, .sh or .java file previously created in this session.
    For .sql files, use the BDD agent.

    Args:
        filename (str): Name of the file to read (e.g. 'export.py', 'run.sh').

    Returns:
        str: the content of the file.
    """
    suffix = Path(filename).suffix.lower()

    if Path(filename).name == "env":
        return _blocked_artifact("Access denied: env file cannot be read.")

    if suffix not in ENV_ALLOWED_EXTENSIONS:
        return _blocked_artifact(
            f"terminal skill only reads {', '.join(sorted(ENV_ALLOWED_EXTENSIONS))} files. "
            "Binary artifacts should be created by scripts and then returned by path."
        )

    try:
        file_path = _resolve_sandbox_path(filename, state, must_exist=True, allow_directory=False)
        content = file_path.read_text(encoding="utf-8")
        return (
            f"File read: {_path_display(file_path, state)} ({len(content)} chars)\n\n{content}",
            _tool_artifact(),
        )
    except FileNotFoundError:
        return _blocked_artifact(
            f"File '{filename}' not found in terminal sandbox. "
            "Use list_draft_files or search_files in draft/work to see available files."
        )
    except PermissionError as e:
        return _blocked_artifact(str(e))
    except Exception as e:
        return f"Error reading file: {e}", _tool_artifact()


@tool(ToolNames.WRITE_FILE, parse_docstring=True, response_format="content_and_artifact")
def write_file(
    filename: str, content: str, state: Annotated[dict, InjectedToolArg]
) -> tuple[str, dict[str, str | NodeNames]]:
    """Create or overwrite a file in the current session's draft directory.

    Use this tool to save Python, Shell or Java scripts produced during this session.
    whether creating a new file or overwriting an existing one after modifications.
    Always provide the COMPLETE file content, never partial content.
    Files are saved under draft/{session_id}/{filename}.
    For .sql files, use the BDD agent's write_sql_file tool.

    Args:
        filename (str): Name of the file to create or overwrite (e.g. 'export.py', 'run.sh').
            Do NOT include a path, only the filename.
        content (str): Content to write into the file.

    Returns:
        str: the result of the write command.
    """
    suffix = Path(filename).suffix.lower()

    if suffix not in ENV_ALLOWED_EXTENSIONS:
        return _blocked_artifact(
            f"terminal skill only writes {', '.join(sorted(ENV_ALLOWED_EXTENSIONS))} files. "
            "Create binary artifacts such as .pptx and .xlsx by writing and executing a script."
        )

    try:
        file_path = _resolve_sandbox_path(filename, state, must_exist=False, allow_directory=False)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        full_path = str(file_path)
        return (
            f"File created: {full_path} ({len(content)} chars)",
            _tool_artifact(f"File created: {_path_display(file_path, state)}"),
        )
    except PermissionError as e:
        return _blocked_artifact(str(e))
    except Exception as e:
        return f"Error writing file: {e}", _tool_artifact()


@tool("append_text_line", parse_docstring=True, response_format="content_and_artifact")
def append_text_line(
    filename: str,
    line: str,
    state: Annotated[dict, InjectedToolArg],
) -> tuple[str, dict[str, str | NodeNames]]:
    """Append one exact line to a text file in the terminal sandbox.

    Use this for small file edits inside the current session draft directory or work directory,
    including files inside a draft Git project prepared by `prepare_git_project_worktree`.

    Args:
        filename: File path under draft/<session_id>/ or work/.
        line: Exact line to append.

    Returns:
        The modified file path and whether the line was appended or already present.
    """
    suffix = Path(filename).suffix.lower()
    if suffix not in ENV_ALLOWED_EXTENSIONS:
        return _blocked_artifact(
            f"terminal skill only edits {', '.join(sorted(ENV_ALLOWED_EXTENSIONS))} files directly."
        )
    try:
        file_path = _resolve_sandbox_path(filename, state, must_exist=True, allow_directory=False)
        existing = file_path.read_text(encoding="utf-8")
        normalized_line = line.rstrip("\r\n")
        if normalized_line in [part.rstrip("\r\n") for part in existing.splitlines()]:
            return (
                f"Line already present in {_path_display(file_path, state)}",
                _tool_artifact(f"Line already present in {_path_display(file_path, state)}"),
            )
        separator = "" if not existing or existing.endswith(("\n", "\r")) else "\n"
        file_path.write_text(f"{existing}{separator}{normalized_line}\n", encoding="utf-8")
        return (
            f"Line appended to {_path_display(file_path, state)}",
            _tool_artifact(f"Line appended to {_path_display(file_path, state)}"),
        )
    except PermissionError as e:
        return _blocked_artifact(str(e))
    except FileNotFoundError:
        return f"File not found in terminal sandbox: {filename}", _tool_artifact()
    except Exception as e:
        return f"Error appending line: {e}", _tool_artifact()


@tool(ToolNames.SEARCH_FILES, parse_docstring=True, response_format="content_and_artifact")
def search_files(
    pattern: str,
    directory: str = ".",
    state: Annotated[dict, InjectedToolArg] = None,
) -> tuple[str, dict[str, str | NodeNames]]:
    """Search for files matching a pattern.

    Args:
        pattern (str): Glob pattern (e.g., '*.py', '*.sql').
        directory (str): Root directory.

    Returns:
        str: the result of the search.
    """
    try:
        root = _resolve_sandbox_path(directory or ".", state, must_exist=True)
        if not root.is_dir():
            return _blocked_artifact(f"Search root is not a directory: {_path_display(root, state)}")
        matches = [p for p in root.rglob(pattern) if p.is_file()]
        if not matches:
            return f"No files found for '{pattern}' in {_path_display(root, state)}", _tool_artifact()
        result = f"{len(matches)} files found in {_path_display(root, state)}:\n"
        for p in matches[:10]:
            result += f" - {_path_display(p, state)}\n"
        if len(matches) > 10:
            result += f"... {len(matches) - 10} more not shown\n"
        return result, _tool_artifact()
    except PermissionError as e:
        return _blocked_artifact(str(e))
    except Exception as e:
        return f"Error searching files: {e}", _tool_artifact()


@tool(ToolNames.READ_LOGS, parse_docstring=True, response_format="content_and_artifact")
def read_logs(
    log_file: str,
    state: Annotated[dict, InjectedToolArg] = None,
) -> tuple[str, dict[str, str | NodeNames]]:
    """Read log files (tail).

    Args:
        log_file (str): Path to log file.

    Returns:
        str: the 2000 last chars of the log file read.
    """
    try:
        path = _resolve_sandbox_path(log_file, state, must_exist=True, allow_directory=False)
        content = path.read_text(encoding="utf-8")
        return f"Logs from {_path_display(path, state)} (last 2000 chars):\n\n{content[-2000:]}", _tool_artifact()
    except PermissionError as e:
        return _blocked_artifact(str(e))
    except FileNotFoundError:
        return f"Log file not found in terminal sandbox: {log_file}", _tool_artifact()
    except Exception as e:
        return f"Error reading logs: {e}", _tool_artifact()


# ==================== PYTHON/EXECUTION TOOLS ====================


@tool(ToolNames.EXECUTE_SCRIPT, parse_docstring=True, response_format="content_and_artifact")
def execute_script(
    file_path: str,
    script_type: str = "python",
    state: Annotated[dict, InjectedToolArg] = None,
) -> tuple[str, dict[str, str | NodeNames]]:
    """Execute a Python or Bash script from the current session draft directory.

    Args:
        file_path (str): Filename of the script (e.g. 'export.py').
            If only a filename is given, it is resolved from the session draft directory.
        script_type (str): 'python', 'bash', or 'auto'.

    Returns:
        str: the result of the script execution.
    """
    try:
        path = _resolve_sandbox_path(file_path, state, must_exist=True, allow_directory=False)
        session_id = _session_id(state)

        if script_type == "auto":
            suffix = path.suffix.lower()
            if suffix == ".sql":
                return "SQL files are outside env script execution.", _tool_artifact()
            elif suffix == ".java":
                return "For Java, compile first then run.", _tool_artifact()
            script_type = {".py": "python", ".sh": "bash"}.get(suffix, "bash")

        commands = {
            "python": [sys.executable, str(path)],  # Use current python env
            "bash": ["bash", str(path)],
        }

        cmd = commands.get(script_type)
        if not cmd:
            return f"Unsupported type: {script_type}", _tool_artifact()

        execution_env = None
        env_file = draft_tools.get_session_draft_dir(session_id) / "env"
        if env_file.exists():
            execution_env = dict(os.environ)
            execution_env.update(
                {key: value for key, value in dotenv_values(env_file).items() if value is not None}
            )

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
            cwd=path.parent,
            env=execution_env,
        )

        output = f"""EXECUTION: {file_path}
Return Code: {result.returncode}
STDOUT:
{result.stdout if result.stdout else "(empty)"}

STDERR:
{result.stderr if result.stderr else "(empty)"}"""

        return output, _tool_artifact()

    except subprocess.TimeoutExpired:
        return "TIMEOUT: Script execution exceeded 30 seconds", _tool_artifact()
    except PermissionError as e:
        return _blocked_artifact(str(e))
    except FileNotFoundError:
        return f"File not found in terminal sandbox: {file_path}", _tool_artifact()
    except Exception as e:
        return f"Execution Error: {e}", _tool_artifact()


@tool(ToolNames.INSTALL_DEPENDENCIES, parse_docstring=True, response_format="content_and_artifact")
def install_dependencies(requirements: str) -> tuple[str, dict[str, str | NodeNames]]:
    """Install Python dependencies via pip.

    Args:
        requirements (str): Comma separated packages (e.g. 'pandas,numpy').

    Returns:
        str: The result of the installation.
    """
    try:
        packages = [pkg.strip() for pkg in requirements.split(",")]
        cmd = [sys.executable, "-m", "pip", "install"] + packages

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)

        if result.returncode == 0:
            return f"Packages installed: {', '.join(packages)}\n\n{result.stdout}", _tool_artifact()
        else:
            return f"Installation Error:\n{result.stderr}", _tool_artifact()
    except Exception as e:
        return f"Error: {e}", _tool_artifact()


@tool(ToolNames.RUN_TESTS, parse_docstring=True, response_format="content_and_artifact")
def run_tests(
    test_file_or_dir: str,
    framework: str = "pytest",
    state: Annotated[dict, InjectedToolArg] = None,
) -> tuple[str, dict[str, str | NodeNames]]:
    """Run Python tests.

    Args:
        test_file_or_dir (str): File or directory.
        framework (str): 'pytest' or 'unittest'.

    Returns:
        str: the result of the tests.
    """
    try:
        path = _resolve_sandbox_path(test_file_or_dir, state, must_exist=True)

        if framework == "pytest":
            cmd = [sys.executable, "-m", "pytest", str(path), "-v"]
        else:
            cmd = [sys.executable, "-m", "unittest", str(path)]

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)

        output = f"""TEST RESULTS: {test_file_or_dir}
Return Code: {result.returncode}
{result.stdout}
{result.stderr if result.stderr else ""}"""

        return output, _tool_artifact()
    except PermissionError as e:
        return _blocked_artifact(str(e))
    except FileNotFoundError:
        return f"Path not found in terminal sandbox: {test_file_or_dir}", _tool_artifact()
    except Exception as e:
        return f"Test Execution Error: {e}", _tool_artifact()


@tool(ToolNames.LINT_CODE, parse_docstring=True, response_format="content_and_artifact")
def lint_code(
    file_path: str,
    linter: str = "pylint",
    state: Annotated[dict, InjectedToolArg] = None,
) -> tuple[str, dict[str, str | NodeNames]]:
    """Lint Python code.

    Args:
        file_path (str): File to lint.
        linter (str): 'pylint', 'flake8', etc.
    """
    # TODO: try to install some linters on system on startup or add manual shell scripts to do so in
    # deploy pipelines.
    try:
        path = _resolve_sandbox_path(file_path, state, must_exist=True, allow_directory=False)

        cmd = [sys.executable, "-m", linter, str(path)]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

        return f"LINT: {file_path}\n\n{result.stdout}\n{result.stderr}", _tool_artifact()
    except PermissionError as e:
        return _blocked_artifact(str(e))
    except FileNotFoundError:
        return f"File not found in terminal sandbox: {file_path}", _tool_artifact()
    except Exception as e:
        return f"Lint Error: {e}. Ensure linter is installed.", _tool_artifact()


# ==================== SYSTEM TOOLS ====================


@tool(ToolNames.RUN_COMMAND, parse_docstring=True, response_format="content_and_artifact")
def run_command(
    command: str,
    working_dir: str = ".",
    state: Annotated[dict, InjectedToolArg] = None,
) -> tuple[str, dict[str, str | NodeNames]]:
    """Execute arbitrary system command (use with caution).

    Args:
        command (str): Command string.
        working_dir (str): Working directory, default to current directory (".")

    Returns:
        str: The result of the command.
    """
    # TODO better docstring for returned string.
    base_cmd = _base_command(command)
    blocked_commands = _blocked_cli_commands()
    if base_cmd == "git":
        return _git_command_block_message(), _tool_artifact(_git_command_block_message())
    if base_cmd in blocked_commands:
        return (
            f"Command '{base_cmd}' is blocked for security reasons. "
            f"Blocked commands: {', '.join(sorted(blocked_commands))}.",
            _tool_artifact(),
        )
    try:
        parts = shlex.split(command)
    except ValueError as exc:
        return f"System Error: invalid command syntax: {exc}", _tool_artifact()
    path_error = _validate_command_paths(parts, state)
    if path_error:
        return _blocked_artifact(path_error)
    try:
        cwd = _session_cwd(state, working_dir)
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=60,
            cwd=cwd,
        )
        output = f"""COMMAND: {command}
Working Directory: {cwd}
Return Code: {result.returncode}
STDOUT:
{result.stdout if result.stdout else "(empty)"}
STDERR:
{result.stderr if result.stderr else "(empty)"}"""
        return output, _tool_artifact()
    except PermissionError as e:
        return _blocked_artifact(str(e))
    except Exception as e:
        return f"System Error: {e}", _tool_artifact()


@tool(ToolNames.EXECUTE_CLI_COMMAND, parse_docstring=True, response_format="content_and_artifact")
def execute_cli_command(
    command_parts: str,
    state: Annotated[dict, InjectedToolArg] = None,
) -> tuple[str, dict[str, str | NodeNames]]:
    """Execute CLI command safely (no shell=True).

    Args:
        command_parts (str): Command and args (e.g., 'git status').

    Returns:
        str: The result of the CLI command in format CLI {command_parts}:
            Ret: {status_code}
            {stdout_output}
            {stderr_output}
    """
    # TODO add STDOUT/STDERR + empty as in run_command?
    try:
        parts = _command_parts(command_parts)
    except ValueError as exc:
        return f"CLI Error: invalid command syntax: {exc}", _tool_artifact()
    base_cmd = parts[0] if parts else ""
    allowed_commands = _allowed_cli_commands()
    blocked_commands = _blocked_cli_commands()
    if base_cmd == "git":
        return _git_command_block_message(), _tool_artifact(_git_command_block_message())
    if base_cmd in blocked_commands:
        return (
            f"Command '{base_cmd}' is blocked for security reasons. "
            f"Blocked commands: {', '.join(sorted(blocked_commands))}.",
            _tool_artifact(),
        )
    if allowed_commands and base_cmd not in allowed_commands:
        return (
            f"Command '{base_cmd}' is not allowed. "
            f"Allowed commands: {', '.join(sorted(allowed_commands))}.",
            _tool_artifact(),
        )
    path_error = _validate_command_paths(parts, state)
    if path_error:
        return _blocked_artifact(path_error)
    try:
        cwd = _session_cwd(state)
        result = subprocess.run(parts, capture_output=True, text=True, timeout=30, cwd=cwd)
        return (
            f"CLI: {command_parts}\nWorking Directory: {cwd}\nRet: {result.returncode}\n"
            f"{result.stdout}\n{result.stderr}",
            _tool_artifact(),
        )
    except PermissionError as e:
        return _blocked_artifact(str(e))
    except Exception as e:
        return f"CLI Error: {e}", _tool_artifact()


@tool(ToolNames.GREP_SEARCH, parse_docstring=True, response_format="content_and_artifact")
def grep_search(
    pattern: str,
    file_path: str,
    options: str = "",
    state: Annotated[dict, InjectedToolArg] = None,
) -> tuple[str, dict[str, str | NodeNames]]:
    """Search within file using grep.

    Args:
        pattern (str): pattern so search in the file
        file_path (str): path to the file.
        options (str): string for options to apply to grep (default is no options)

    Returns:
        str: The result of the grep command.
    """
    # TODO improve docstring
    try:
        safe_file = _resolve_sandbox_path(file_path, state, must_exist=True, allow_directory=False)
        # Check if grep exists (might not on Windows without Git Bash/WSL)
        cmd = ["grep"] + options.split() + [pattern, str(safe_file)]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return f"MATCHES:\n{result.stdout}", _tool_artifact()
        return "No matches found.", _tool_artifact()
    except FileNotFoundError:
        return "Grep command not found on this system or file not found.", _tool_artifact()
    except PermissionError as e:
        return _blocked_artifact(str(e))
    except Exception as e:
        return f"Grep Error: {e}", _tool_artifact()


# ===================== DATABASE CONNECTION TOOLS =====================


@tool(
    ToolNames.GET_DB_CONNECTION_INFO,
    parse_docstring=True,
    response_format="content_and_artifact",
)
def get_db_connection_info() -> tuple[str, dict[str, str | NodeNames]]:
    """Return the business database context needed to write a Python script.

    Use this tool before generating a script that connects to the configured business database.
    The password is intentionally hidden. Scripts must read secrets from the environment instead
    of hard-coding them.

    Returns:
        str: Database type, dialect, and non-secret connection info.
    """
    context = get_database_context()
    info = (
        f"BDD_DB_TYPE={context['type']}\n"
        f"SQL_DIALECT={context['dialect']}\n"
        f"DB_DATABASE_OR_PROJECT={context.get('database') or ''}\n"
        f"DB_SCHEMA_OR_DATASET={context.get('schema') or ''}\n"
        f"DB_HOST={DB_CONFIG['host']}\n"
        f"DB_PORT={DB_CONFIG['port']}\n"
        f"DB_NAME={DB_CONFIG['dbname']}\n"
        f"DB_USER={DB_CONFIG['user']}\n"
        f"DB_SSLMODE={DB_CONFIG['sslmode']}\n"
        "DB_PASSWORD=(hidden; use os.getenv('BDD_DB_PASSWORD') or the matching typed env var)\n"
        "Configuration source: runtime/bd_env"
    )
    return (
        f"Database connection info:\n{info}",
        _tool_artifact(),
    )


@tool("prepare_git_project_worktree", parse_docstring=True, response_format="content_and_artifact")
def prepare_git_project_worktree(
    project_path: str = "",
    branch_name: str = "",
    state: Annotated[dict, InjectedToolArg] = None,
) -> tuple[str, dict[str, str | NodeNames]]:
    """Copy a Git project from work/projet_from_git into the current session draft worktree.

    Use this before terminal modifies a Git project. The shared cache under work/projet_from_git
    is cloned or updated first, then copied to draft/<session_id>/<project>. All subsequent
    terminal edits and commands should use that draft worktree path.

    Args:
        project_path: GitLab project path or clone URL. Defaults to GITLAB_PROJECT.
        branch_name: Branch to checkout. Defaults to GITLAB_BRANCH.
        state: Runtime state injected by the runtime.

    Returns:
        Draft worktree path prepared for terminal edits.
    """
    try:
        selected_project = local_repo.normalize_project_path(
            project_path or os.getenv("GITLAB_PROJECT", "")
        )
        if not selected_project:
            return _blocked_artifact("No project_path provided and GITLAB_PROJECT is empty.")
        selected_branch = branch_name or os.getenv("GITLAB_BRANCH", "")
        clone_url = local_repo.default_clone_url(selected_project)
        draft_dir = local_repo.ensure_project_draft_copy(
            _session_id(state),
            selected_project,
            clone_url,
            selected_branch or None,
        )
        return (
            f"Draft Git worktree prepared: {_path_display(draft_dir, state)}",
            _tool_artifact(
                f"Use this draft worktree for project edits: {_path_display(draft_dir, state)}"
            ),
        )
    except Exception as e:
        return f"Error preparing Git project worktree: {e}", _tool_artifact()


@tool("select_git_project", parse_docstring=True, response_format="content_and_artifact")
async def select_git_project(
    project_path: str,
    branch_name: str | None = None,
    state: Annotated[dict, InjectedToolArg] = None,
) -> tuple[str, dict[str, str | NodeNames]]:
    """Select and update a GitLab project in the local terminal project cache.

    Args:
        project_path: GitLab project path or clone URL, for example `smart-teem/pimkie`.
        branch_name: Optional branch to checkout and fast-forward pull.

    Returns:
        Local cache path and selected context.
    """
    try:
        selected_project = local_repo.normalize_project_path(project_path)
        selected_branch = await _current_branch_name(state, branch_name)
        await save_user_value(state, "state_data", "project_path", selected_project)
        if selected_branch:
            await save_user_value(state, "state_data", "branch_name", selected_branch)
        clone_url = _clone_url_for_project_path(selected_project)
        cache_dir = local_repo.ensure_project_cache(selected_project, clone_url, selected_branch)
        return (
            f"Git project selected and updated: {selected_project}\n"
            f"Branch: {selected_branch or '[not selected]'}\n"
            f"Cache: work/projet_from_git/{cache_dir.name}",
            _tool_artifact(
                f"Git project selected: {selected_project}. Cache: work/projet_from_git/{cache_dir.name}"
            ),
        )
    except Exception as e:
        return f"Git project selection failed: {e}", _tool_artifact(f"Git project selection failed: {e}")


@tool("execute_git_command", parse_docstring=True, response_format="content_and_artifact")
async def execute_git_command(
    command: str,
    project_path: str | None = None,
    branch_name: str | None = None,
    user_confirmed_state_change: bool = False,
    timeout_seconds: int = 120,
    state: Annotated[dict, InjectedToolArg] = None,
) -> tuple[str, dict[str, str | NodeNames]]:
    """Execute a Git command inside the selected local cache or session draft worktree.

    Args:
        command: Complete `git ...` command, for example `git status --short`.
        project_path: Optional GitLab project path or clone URL. Defaults to selected project.
        branch_name: Optional branch to checkout/update before executing. Defaults to selected branch.
        user_confirmed_state_change: True only when the latest user message explicitly confirmed a
            state-changing operation such as commit, push, reset, merge, rebase, tag, clean, or rm.
        timeout_seconds: Command timeout in seconds.

    Returns:
        Git stdout/stderr and the worktree used.
    """
    try:
        selected_project = await _current_project_path(state, project_path)
        if not selected_project:
            return "Please provide the GitLab project path to use.", _tool_artifact()
        if project_path:
            await save_user_value(state, "state_data", "project_path", selected_project)
        selected_branch = await _current_branch_name(state, branch_name)
        if branch_name:
            await save_user_value(state, "state_data", "branch_name", selected_branch)
        clone_url = _clone_url_for_project_path(selected_project)
        repo_dir, source = local_repo.ensure_project_for_git(
            _session_id(state),
            selected_project,
            clone_url,
            selected_branch,
        )
        emit_skill_status(
            state,
            f"Executing `{command}` in {source} Git worktree",
            skill_name="terminal",
            detail={"type": "code", "tool": "execute_git_command", "query": command},
        )
        result = local_repo.execute_git_command_string(
            repo_dir,
            clone_url,
            command,
            user_confirmed_state_change=user_confirmed_state_change,
            timeout=timeout_seconds,
        )
        emit_skill_status(
            state,
            f"Finished `{command}`",
            skill_name="terminal",
            detail={"type": "code", "tool": "execute_git_command", "query": command, "result": result},
        )
        return (
            f"Git command executed in local {source} worktree for {selected_project}.\n{result}",
            _tool_artifact(result),
        )
    except Exception as e:
        message = (
            f"Git command `{command}` failed inside terminal skill.\n"
            f"Error: {e}\n"
            "Generate a corrected `git ...` command, use terminal file actions for file edits, "
            "or ask the user if the operation needs confirmation or permission."
        )
        emit_skill_status(
            state,
            f"Git command failed: {e}",
            skill_name="terminal",
            detail={"type": "code", "tool": "execute_git_command", "query": command, "result": str(e)},
        )
        return message, _tool_artifact(message)


@tool("commit_prepared_worktree", parse_docstring=True, response_format="content_and_artifact")
async def commit_prepared_worktree(
    feature_branch: str,
    commit_message: str,
    project_path: str | None = None,
    state: Annotated[dict, InjectedToolArg] = None,
) -> tuple[str, dict[str, str | NodeNames]]:
    """Commit and push changes already prepared in the current session draft Git worktree.

    Args:
        feature_branch: Branch to commit and push.
        commit_message: Commit message confirmed by the user.
        project_path: Optional GitLab project path or clone URL. Defaults to selected project.

    Returns:
        Commit and push result, or the exact Git error if push is rejected.
    """
    selected_project = project_path
    repo_dir = None
    try:
        selected_project = await _current_project_path(state, project_path)
        if not selected_project:
            return "Please provide the GitLab project path to use.", _tool_artifact()
        if project_path:
            await save_user_value(state, "state_data", "project_path", selected_project)
        clone_url = _clone_url_for_project_path(selected_project)
        repo_dir = local_repo.project_draft_dir(_session_id(state), selected_project)
        if not local_repo.is_git_repo(repo_dir):
            message = (
                f"No draft Git worktree exists for {selected_project}. Prepare changes in "
                f"draft/{_session_id(state)}/{local_repo.project_slug(selected_project)} first."
            )
            return message, _tool_artifact(message)
        emit_skill_status(
            state,
            f"Committing and pushing {selected_project}:{feature_branch}",
            skill_name="terminal",
            detail={"type": "code", "tool": "commit_prepared_worktree", "query": commit_message},
        )
        result = local_repo.commit_existing_changes_push(
            repo_dir,
            clone_url,
            feature_branch,
            commit_message,
        )
        return result, _tool_artifact(result)
    except Exception as e:
        local_state = ""
        if selected_project:
            repo_dir = repo_dir or local_repo.project_draft_dir(_session_id(state), selected_project)
            if local_repo.is_git_repo(repo_dir):
                local_state = _git_partial_delivery_state(repo_dir, feature_branch)
        message = (
            f"Commit or push failed for {selected_project or project_path or '[selected project]'}.\n"
            f"Error: {e}"
            f"{local_state}"
        )
        emit_skill_status(
            state,
            f"Commit or push failed: {e}",
            skill_name="terminal",
            detail={"type": "code", "tool": "commit_prepared_worktree", "query": commit_message, "result": str(e)},
        )
        return message, _tool_artifact(message)


def _git_partial_delivery_state(repo_dir: Path, branch_name: str) -> str:
    """Return local commit state after a failed delivery attempt."""

    def run(args: list[str]) -> str:
        result = subprocess.run(
            ["git", *args],
            cwd=repo_dir,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            return ""
        return result.stdout.strip()

    head = run(["rev-parse", "--short", "HEAD"])
    subject = run(["log", "-1", "--pretty=%s"])
    ahead = run(["rev-list", "--count", f"origin/{branch_name}..HEAD"])
    status = run(["status", "--short"])
    details = []
    if head:
        details.append(f"Local HEAD: {head} {subject}".rstrip())
    if ahead:
        details.append(f"Local commits ahead of origin/{branch_name}: {ahead}")
    if status:
        details.append(f"Remaining working tree status:\n{status}")
    if not details:
        return ""
    return "\n\nLocal state after failure:\n" + "\n".join(f"- {item}" for item in details)


skill_actions = {
    ToolNames.LIST_DRAFT_FILES: draft_tools.list_draft_files,
    ToolNames.GET_DRAFT_FILE_FOR_COMMIT: draft_tools.get_draft_file_for_commit,
    ToolNames.READ_FILE: read_file,
    ToolNames.WRITE_FILE: write_file,
    "append_text_line": append_text_line,
    ToolNames.SEARCH_FILES: search_files,
    ToolNames.READ_LOGS: read_logs,
    ToolNames.EXECUTE_SCRIPT: execute_script,
    ToolNames.INSTALL_DEPENDENCIES: install_dependencies,
    ToolNames.RUN_TESTS: run_tests,
    ToolNames.LINT_CODE: lint_code,
    ToolNames.RUN_COMMAND: run_command,
    ToolNames.EXECUTE_CLI_COMMAND: execute_cli_command,
    ToolNames.GREP_SEARCH: grep_search,
    ToolNames.GET_DB_CONNECTION_INFO: get_db_connection_info,
    "select_git_project": select_git_project,
    "execute_git_command": execute_git_command,
    "commit_prepared_worktree": commit_prepared_worktree,
    "prepare_git_project_worktree": prepare_git_project_worktree,
}
