---
name: terminal
description: Work with the local terminal, filesystem runtime, shell, CLI, scripts, tests, logs, draft files, and Git/GitLab repository delivery. Use this skill whenever the user asks to read or search local files, write support scripts, execute bounded commands, install dependencies, run tests, inspect logs, create draft files, clone/update a GitLab project, edit a repository draft worktree, run Git commands, commit, or push.
---

# Terminal Runtime Work

Use this skill for local filesystem inspection, script creation, command execution, dependency
installation, tests, linting, logs, draft files, and Git/GitLab repository delivery.

## Implementation

This skill is self-contained:

- `scripts/actions.py` exposes local runtime actions.
- `scripts/draft_files.py` stores and reads session-scoped draft files.
- `scripts/local_repo.py` manages GitLab project caches in `runtime/work/projet_from_git` and editable
  draft worktrees in `draft/<session_id>/`.

Add new runtime behavior inside this skill directory. Do not add a shared runtime helper outside
the skill.

## Process

1. Observe before changing: read files, search paths, or inspect logs.
2. Choose the narrowest action that can answer the next question.
3. Write the smallest support script or draft file needed.
4. Run the relevant command, script, test, or linter.
5. Summarize the important output and return draft paths for reusable artifacts.

Temporary files, generated code, ad hoc outputs, package scratch projects, and command outputs that
belong to a conversation should live under the current session's `runtime/draft/<session_id>/` directory.
The terminal actions default to that directory for command execution.

The terminal runtime is sandboxed. It can read, write, search, lint, test, and execute only files
inside the current session draft directory or the project `runtime/work/` directory. Use `work/...` paths
only for user-provided working files; use draft paths for generated temporary files and final
artifacts. Do not attempt to inspect repository, home, cache, history, or system paths from this
skill.

When terminal needs to modify a Git project, first call `prepare_git_project_worktree`. That action
updates the shared Git cache in `runtime/work/projet_from_git` and copies the project into the current
session draft directory. Run edits, commands, tests, and generated scripts inside the draft project
copy, not inside the shared cache.

Use `write_file` for text artifacts including `.html`, `.md`, `.json`, `.csv`, `.xml`, `.svg`,
Python, JavaScript, shell, Java, and TypeScript files. For binary artifacts such as `.pptx`,
`.docx`, `.xlsx`, and `.pdf`, write a small Python script in draft and execute it so the script
creates the binary file inside draft.

Use `append_text_line` for narrow text edits such as adding one line to a README inside a prepared
draft Git worktree.

Use the dedicated Git actions in this skill for repository operations. Prefer `execute_git_command`
for `git status`, `git log`, `git diff`, fetch/pull, and branch inspection. Use
`commit_prepared_worktree` after the user explicitly confirms the branch and commit message.

Do not read `env` files. Do not expose secrets. Do not run destructive commands, privilege
escalation, broad deletes, or unbounded operations.

`execute_cli_command` reads `WHITELIST_CLI_COMMANDS` and `BLOCKLIST_RUN_COMMANDS` from the process
environment on every call. If `WHITELIST_CLI_COMMANDS` is missing or empty, any base command is
allowed except commands present in `BLOCKLIST_RUN_COMMANDS`.

## Action Call Examples

Search files:

Action: `search_files`

Arguments:

```json
{"pattern": "*.py", "directory": "."}
```

Create an HTML artifact:

Action: `write_file`

Arguments:

```json
{"filename": "report.html", "content": "<!doctype html><html><body>...</body></html>"}
```

Append a line to a text file:

Action: `append_text_line`

Arguments:

```json
{"filename": "smart-teem__pimkie/AGG/README.txt", "line": "This is a test line."}
```

Prepare a Git project for terminal edits:

Action: `select_git_project`

Arguments:

```json
{"project_path": "smart-teem/pimkie", "branch_name": "main"}
```

Action: `prepare_git_project_worktree`

Arguments:

```json
{"project_path": "smart-teem/pimkie", "branch_name": "main"}
```

Inspect and deliver Git changes:

Action: `execute_git_command`

Arguments:

```json
{"command": "git status --short", "project_path": "smart-teem/pimkie", "branch_name": "main"}
```

Action: `commit_prepared_worktree`

Arguments:

```json
{"project_path": "smart-teem/pimkie", "feature_branch": "main", "commit_message": "test1"}
```

Action: `grep_search`

Arguments:

```json
{"pattern": "target_text", "file_path": "report.html"}
```

Write and execute a support script:

Action: `write_file`

Arguments:

```json
{"filename": "check_status.py", "content": "print('ok')"}
```

Action: `execute_script`

Arguments:

```json
{"file_path": "check_status.py", "script_type": "python"}
```

Run validation:

Action: `run_tests`

Arguments:

```json
{"test_file_or_dir": "tests"}
```

Action: `lint_code`

Arguments:

```json
{"file_path": "src/app.py", "linter": "ruff"}
```

Run a bounded command:

Action: `execute_cli_command`

Arguments:

```json
{"command_parts": "python -m compileall ."}
```

Create a binary artifact with Python:

Action: `write_file`

Arguments:

```json
{"filename": "create_deck.py", "content": "from pptx import Presentation\nprs = Presentation()\nprs.slides.add_slide(prs.slide_layouts[0])\nprs.save('result.pptx')\nprint('result.pptx')"}
```

Action: `execute_script`

Arguments:

```json
{"file_path": "create_deck.py", "script_type": "python"}
```

Create Word and Excel artifacts the same way: write a Python script that uses the installed
document or spreadsheet libraries and saves `.docx` or `.xlsx` inside the current session draft
directory, then execute that script.

## Completion

Return files inspected or changed, commands run, tests or lints executed, pass/fail summary,
important output excerpts, draft paths, and blockers.
