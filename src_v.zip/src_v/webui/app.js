const STORAGE_KEY = "smartteem-agent-web-history";

const elements = {
  historyList: document.getElementById("historyList"),
  messageStream: document.getElementById("messageStream"),
  messageScroll: document.getElementById("messageScroll"),
  chatTitle: document.getElementById("chatTitle"),
  chatInput: document.getElementById("chatInput"),
  composerForm: document.getElementById("composerForm"),
  newChatButton: document.getElementById("newChatButton"),
  clearHistoryButton: document.getElementById("clearHistoryButton"),
  stopButton: document.getElementById("stopButton"),
  sendButton: document.getElementById("sendButton"),
  composerProcessing: document.getElementById("composerProcessing"),
  promptOButton: document.getElementById("promptOButton"),
  promptEButton: document.getElementById("promptEButton"),
  menuButton: document.getElementById("menuButton"),
  sidebar: document.getElementById("sidebar"),
  sidebarBackdrop: document.getElementById("sidebarBackdrop"),
  promptModalBackdrop: document.getElementById("promptModalBackdrop"),
  promptModalTitle: document.getElementById("promptModalTitle"),
  promptModalSubtitle: document.getElementById("promptModalSubtitle"),
  promptModalTextarea: document.getElementById("promptModalTextarea"),
  promptModalStatus: document.getElementById("promptModalStatus"),
  promptModalSaveButton: document.getElementById("promptModalSaveButton"),
  promptModalCancelButton: document.getElementById("promptModalCancelButton"),
  promptModalCloseButton: document.getElementById("promptModalCloseButton"),
};

let conversations = loadConversations();
let activeSessionId = conversations[0]?.sessionId ?? null;
let currentAbortController = null;
let currentRequestSessionId = null;
let timerIntervalId = null;
let statusRenderQueued = false;
let activePromptModalKind = null;
let promptModalBusy = false;

function loadConversations() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch (error) {
    console.error("Failed to parse stored conversations", error);
    return [];
  }
}

function saveConversations() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations));
}

function formatDate(timestamp) {
  return new Date(timestamp).toLocaleString([], {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function truncateTitle(title) {
  if (!title) {
    return "New Chat";
  }
  return title.length > 42 ? `${title.slice(0, 39)}...` : title;
}

function getConversation(sessionId) {
  return conversations.find((item) => item.sessionId === sessionId);
}

function createEmptyConversation(sessionId) {
  return {
    sessionId,
    title: "New Chat",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    messages: [],
  };
}

function createPendingTurnMessage() {
  return {
    id: crypto.randomUUID(),
    role: "assistant-turn",
    createdAt: Date.now(),
    pending: true,
    responseType: null,
    responseVariant: "default",
    content: "",
    title: "",
    cardContent: "",
    inputs: [],
    actions: [],
    statusOpen: true,
    statusStartedAt: Date.now(),
    statusFinishedAt: null,
    statusEntries: [],
    artifacts: [],
  };
}

async function createSession() {
  const response = await fetch("/api/web/session", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({}),
  });
  const payload = await response.json();
  return payload.session_id;
}

async function ensureActiveConversation() {
  if (activeSessionId && getConversation(activeSessionId)) {
    return getConversation(activeSessionId);
  }
  const sessionId = await createSession();
  const conversation = createEmptyConversation(sessionId);
  conversations.unshift(conversation);
  activeSessionId = sessionId;
  saveConversations();
  renderHistory();
  renderConversation();
  return conversation;
}

function renderHistory() {
  elements.historyList.innerHTML = "";
  conversations.forEach((conversation) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `history-item ${conversation.sessionId === activeSessionId ? "active" : ""}`;
    button.disabled = Boolean(currentRequestSessionId);
    button.innerHTML = `
      <div class="history-item-title">${escapeHtml(truncateTitle(conversation.title))}</div>
      <div class="history-item-meta">${formatDate(conversation.updatedAt)}</div>
    `;
    button.addEventListener("click", () => {
      activeSessionId = conversation.sessionId;
      renderHistory();
      renderConversation();
      closeSidebar();
    });
    elements.historyList.appendChild(button);
  });
}

function renderConversation() {
  const conversation = getConversation(activeSessionId);
  elements.messageStream.innerHTML = "";
  elements.chatTitle.textContent = conversation ? truncateTitle(conversation.title) : "New Chat";

  if (!conversation || conversation.messages.length === 0) {
    refreshComposerAvailability();
    appendEmptyState();
    return;
  }

  conversation.messages.forEach((message) => {
    renderMessage(message);
  });
  refreshComposerAvailability();
  scrollToBottom();
}

function appendEmptyState() {
  const article = document.createElement("article");
  article.className = "message assistant";
  article.innerHTML = `
    <div class="message-bubble">
      <div class="message-content">
        <p>Start a new conversation with AI.</p>
        <p>Ask me anything!</p>
      </div>
    </div>
  `;
  elements.messageStream.appendChild(article);
}

function renderMessage(message) {
  const article = document.createElement("article");
  if (message?.id) {
    article.dataset.messageId = message.id;
  }

  if (message.role === "user") {
    article.className = "message user";
    article.innerHTML = `
      <div class="message-bubble">
        <div class="message-content">${renderRichText(message.content)}</div>
      </div>
    `;
    wireCodeCopyButtons(article);
    elements.messageStream.appendChild(article);
    return;
  }

  if (message.role === "assistant-turn") {
    article.className = "message assistant";
    article.innerHTML = buildAssistantTurnMarkup(message);
    if (message.responseType === "card") {
      wireCardActions(article, message);
      wireCardLiveInputs(article, message);
    }
    wireStatusInteractions(article, message);
    wireCodeCopyButtons(article);
    elements.messageStream.appendChild(article);
    return;
  }

  if (message.role === "status") {
    article.className = "message status";
    article.innerHTML = buildLegacyStatusMarkup(message);
    wireLegacyStatusInteractions(article, message);
    elements.messageStream.appendChild(article);
    return;
  }

  if (message.role === "card") {
    article.className = "message card";
    article.innerHTML = buildLegacyCardMarkup(message);
    wireCardActions(article, message);
    wireCardLiveInputs(article, message);
    wireCodeCopyButtons(article);
    elements.messageStream.appendChild(article);
    return;
  }

  if (message.role === "assistant-pending") {
    article.className = "message assistant";
    article.innerHTML = `
      <div class="message-bubble">
        <div class="typing-indicator"><span></span><span></span><span></span></div>
      </div>
    `;
    elements.messageStream.appendChild(article);
    return;
  }

  article.className = `message ${message.role || "assistant"}`;
  article.innerHTML = `
    <div class="message-bubble">
      <div class="message-content">${renderRichText(message.content)}</div>
    </div>
  `;
  wireCodeCopyButtons(article);
  elements.messageStream.appendChild(article);
}

function buildAssistantTurnMarkup(message) {
  const primary = buildAssistantTurnPrimaryMarkup(message);
  const status = buildAssistantTurnStatusMarkup(message);
  const content =
    message.pending || !status
      ? `${primary}${status}`
      : `${status}${primary}`;
  return `
    <div class="assistant-turn-shell">
      ${content}
    </div>
  `;
}

function buildAssistantTurnPrimaryMarkup(message) {
  if (message.pending && !message.responseType) {
    return "";
  }

  if (message.responseType === "card") {
    return buildLegacyCardMarkup({
      title: message.title,
      content: message.cardContent,
      inputs: message.inputs,
      actions: message.actions,
      layout: message.layout,
      cardKind: message.cardKind,
    });
  }

  if (message.responseType === "assistant" && message.content) {
    const isCodeOnly = isCodeOnlyMarkdown(message.content);
    const bubbleClass =
      message.responseVariant === "muted"
        ? "message-bubble message-bubble-muted"
        : isCodeOnly
          ? "message-bubble message-bubble-code"
          : "message-bubble";
    return `
      <div class="${bubbleClass}">
        <div class="message-content">${renderRichText(message.content)}</div>
        ${buildArtifactDownloadsMarkup(message.artifacts)}
      </div>
    `;
  }

  if ((message.artifacts || []).length) {
    return `
      <div class="message-bubble">
        ${buildArtifactDownloadsMarkup(message.artifacts)}
      </div>
    `;
  }

  return "";
}

function buildArtifactDownloadsMarkup(artifacts = []) {
  if (!artifacts.length) {
    return "";
  }
  const links = artifacts
    .map((artifact) => {
      const href = `/api/web/artifact?session_id=${encodeURIComponent(activeSessionId || "")}&path=${encodeURIComponent(artifact.path || "")}`;
      const filename = artifact.name || artifact.path || "artifact";
      return `
        <a class="artifact-download-link" href="${href}" download="${escapeHtml(filename)}">
          <span>${escapeHtml(filename)}</span>
          <span>${formatFileSize(artifact.size)}</span>
        </a>
      `;
    })
    .join("");
  return `<div class="artifact-downloads">${links}</div>`;
}

function formatFileSize(bytes) {
  const value = Number(bytes) || 0;
  if (value < 1024) {
    return `${value} B`;
  }
  if (value < 1024 * 1024) {
    return `${(value / 1024).toFixed(1)} KB`;
  }
  return `${(value / (1024 * 1024)).toFixed(1)} MB`;
}

function buildAssistantTurnStatusMarkup(message) {
  const entries = message.statusEntries || [];
  const hasStatusContent = Boolean(message.pending || entries.length);
  if (!hasStatusContent) {
    return "";
  }

  const totalLines = countStatusLines(entries);
  const detailsOpen = message.pending || Boolean(message.statusOpen) ? "open" : "";
  const content = entries
    .map((entry) => buildStatusEntryMarkup(entry, message.pending))
    .join("");

  return `
    <div class="turn-status-shell">
      <details class="status-details status-details-root" data-turn-toggle="status" ${detailsOpen}>
        <summary>
          <span class="status-summary-copy">Status updates</span>
          <span class="status-summary-meta">
            ${totalLines ? `<span class="status-count">${totalLines} updates</span>` : ""}
            <span
              class="status-duration"
              data-started-at="${message.statusStartedAt || message.createdAt}"
              data-finished-at="${message.statusFinishedAt || ""}"
              data-pending="${message.pending ? "true" : "false"}"
            >${formatDurationLabel(message.statusStartedAt || message.createdAt, message.statusFinishedAt, message.pending)}</span>
          </span>
        </summary>
        <div class="status-log status-log-root">
          ${content || '<div class="status-empty">Waiting for agent updates...</div>'}
        </div>
      </details>
    </div>
  `;
}

function buildStatusEntryMarkup(entry, parentPending) {
  if (entry.kind === "assistant_update") {
    const nestedGroups = (entry.agentGroups || [])
      .map((group) => buildAgentStatusGroupMarkup(group, parentPending))
      .join("");
    const open = parentPending || Boolean(entry.open) ? "open" : "";
    const summaryText = buildAssistantUpdateSummary(entry.content);
    const bodyMarkup = shouldRenderAssistantUpdateBody(entry.content)
      ? `<div class="assistant-update-content message-content">${renderMarkdown(entry.content)}</div>`
      : "";
    return `
      <details class="status-details assistant-update-entry" data-entry-toggle="assistant" data-entry-id="${entry.id}" ${open}>
        <summary>
          <span class="assistant-update-summary-text">${renderInlineMarkdown(summaryText)}</span>
          <span class="assistant-update-summary-meta">Assistant update</span>
        </summary>
        ${bodyMarkup}
        ${nestedGroups ? `<div class="status-log assistant-update-log">${nestedGroups}</div>` : ""}
      </details>
    `;
  }

  return buildTopLevelStatusGroupMarkup(entry, parentPending);
}

function buildAssistantUpdateSummary(text) {
  const source = String(text || "").replace(/\r\n/g, "\n");
  const firstMeaningfulLine = source.split("\n").find((line) => line.trim()) || "";
  const normalized = firstMeaningfulLine
    .replace(/^\s*#{1,6}\s+/, "")
    .replace(/^\s*[-*+]\s+/, "")
    .replace(/^\s*\d+\.\s+/, "")
    .trim();
  return normalized || "Assistant update";
}

function shouldRenderAssistantUpdateBody(text) {
  const source = String(text || "").replace(/\r\n/g, "\n").trim();
  if (!source) {
    return false;
  }
  return source.includes("\n") || source.includes("```");
}

function buildStatusLineMarkup(line, parentPending = false) {
  const detail = line.detail;
  const children = buildStatusLineChildrenMarkup(line, parentPending);
  if (detail?.type === "llm_content") {
    const text = String(detail.content || line.content || "").trim();
    const open = parentPending ? "open" : "";
    return `
      <details class="llm-content-details" ${open}>
        <summary>${escapeHtml(line.content || "LLM content")}</summary>
        <div class="llm-content-body message-content">${renderMarkdown(text)}</div>
      </details>
      ${children}
    `;
  }

  if (!detail || (detail.type !== "sql" && detail.type !== "code")) {
    return `<div class="status-line">${escapeHtml(line.content)}</div>${children}`;
  }

  if (detail.type === "sql") {
    const toolLabel = detail.tool ? `<span class="sql-detail-tool">${escapeHtml(detail.tool)}</span>` : "";
    let detailContent;
    const detailsOpen = "open";
    const structuredSql = buildSqlStructuredResultMarkup(detail);
    if (structuredSql) {
      detailContent = structuredSql;
    } else if (!detail.result) {
      detailContent = detail.query ? renderCodeBlock(detail.query.trim(), "sql") : "";
    } else {
      detailContent = `<pre>${escapeHtml(String(detail.result).trim())}</pre>`;
    }
    if (!detailContent) return `<div class="status-line">${escapeHtml(line.content)}</div>${children}`;
    return `<div class="status-line status-line-with-detail"><div class="status-line-copy">${escapeHtml(line.content)}</div><details class="sql-detail-details" ${detailsOpen}><summary><span>SQL details</span>${toolLabel}</summary><div class="sql-detail-content">${detailContent}</div></details></div>${children}`;
  }

  if (detail.type === "code") {
    const labelText = detail.label || detail.tool || "code";
    const toolLabel = `<span class="code-detail-tool">${escapeHtml(labelText)}</span>`;
    let detailContent;
    let detailsOpen;
    if (detail.query && looksLikeGeneratedCode(detail.query)) {
      const codeBlock = renderCodeBlock(detail.query.trim(), inferCodeLanguage(detail.query, labelText));
      const resultBlock = detail.result ? `<pre>${escapeHtml(String(detail.result).trim())}</pre>` : "";
      detailContent = `${codeBlock}${resultBlock}`;
      detailsOpen = "open";
    } else if (!detail.result) {
      detailContent = detail.query ? renderCodeBlock(detail.query.trim(), inferCodeLanguage(detail.query, labelText)) : "";
      detailsOpen = "open";
    } else {
      detailContent = `<pre>${escapeHtml(String(detail.result).trim())}</pre>`;
      detailsOpen = parentPending ? "open" : "";
    }
    if (!detailContent) return `<div class="status-line">${escapeHtml(line.content)}</div>${children}`;
    return `<div class="status-line status-line-with-detail"><div class="status-line-copy">${escapeHtml(line.content)}</div><details class="code-detail-details" ${detailsOpen}><summary><span>Code details</span>${toolLabel}</summary><div class="code-detail-content">${detailContent}</div></details></div>${children}`;
  }

  return `<div class="status-line">${escapeHtml(line.content)}</div>${children}`;
}

function buildSqlStructuredResultMarkup(detail) {
  const structured = detail.structured_result;
  if (!structured || !Array.isArray(structured.rows) || !Array.isArray(structured.columns)) {
    return "";
  }
  const rows = structured.rows;
  const columns = structured.columns.map((column) => String(column));
  const delimiter = String(detail.csv_delimiter || ";");
  const csv = buildCsv(columns, rows, delimiter);
  const csvPayload = escapeHtml(encodeURIComponent(csv));
  const tableRows = rows
    .map((row) => `
      <tr>
        ${columns.map((column) => `<td>${escapeHtml(formatSqlCell(row?.[column]))}</td>`).join("")}
      </tr>
    `)
    .join("");
  const limitedLabel =
    structured.is_result_length_limited_by_tool && structured.is_result_length_limited_by_tool !== "No"
      ? `<span class="sql-result-note">Limited sample</span>`
      : "";
  return `
    <div class="sql-result-toolbar">
      <span>${escapeHtml(String(structured.rows_returned ?? rows.length))} rows</span>
      ${limitedLabel}
      <button type="button" class="sql-csv-button" data-download-sql-csv="${csvPayload}">Download CSV</button>
    </div>
    <div class="sql-result-table-wrap">
      <table class="sql-result-table">
        <thead>
          <tr>${columns.map((column) => `<th>${escapeHtml(column)}</th>`).join("")}</tr>
        </thead>
        <tbody>${tableRows || `<tr><td colspan="${columns.length || 1}">No rows</td></tr>`}</tbody>
      </table>
    </div>
  `;
}

function formatSqlCell(value) {
  if (value === null || value === undefined) {
    return "";
  }
  if (typeof value === "object") {
    return JSON.stringify(value);
  }
  return String(value);
}

function buildCsv(columns, rows, delimiter) {
  const safeDelimiter = delimiter || ";";
  const serialize = (value) => {
    const text = formatSqlCell(value);
    const escaped = text.replaceAll('"', '""');
    return /["\r\n]/.test(escaped) || escaped.includes(safeDelimiter) ? `"${escaped}"` : escaped;
  };
  const lines = [
    columns.map(serialize).join(safeDelimiter),
    ...rows.map((row) => columns.map((column) => serialize(row?.[column])).join(safeDelimiter)),
  ];
  return lines.join("\n");
}

function downloadSqlCsv(button) {
  const csv = decodeURIComponent(button.dataset.downloadSqlCsv || "");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "sql_result.csv";
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function downloadCodeBlock(button) {
  const code = decodeURIComponent(button.dataset.downloadCode || "");
  const filename = button.dataset.codeFilename || "code.txt";
  const blob = new Blob([code], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function buildStatusLineChildrenMarkup(line, parentPending = false) {
  const children = line.children || [];
  if (!children.length) {
    return "";
  }
  return `
    <div class="status-line-children">
      ${children.map((child) => buildStatusLineMarkup(child, parentPending)).join("")}
    </div>
  `;
}

function buildTopLevelStatusGroupMarkup(group, parentPending) {
  const open = parentPending || Boolean(group.open) ? "open" : "";
  const lines = (group.lines || [])
    .map((line) => buildStatusLineMarkup(line, parentPending))
    .join("");
  return `
    <details class="status-details status-group-entry" data-entry-toggle="group" data-entry-id="${group.id}" ${open}>
      <summary>
        <span class="status-summary-copy">${escapeHtml(group.label)}</span>
        <span class="status-summary-meta">
          <span class="status-count">${(group.lines || []).length} updates</span>
        </span>
      </summary>
      <div class="status-log">${lines}</div>
    </details>
  `;
}

function buildAgentStatusGroupMarkup(group, parentPending) {
  const open = parentPending || Boolean(group.open) ? "open" : "";
  const lines = (group.lines || [])
    .map((line) => buildStatusLineMarkup(line, parentPending))
    .join("");
  return `
    <details class="status-details agent-status-details" data-entry-toggle="nested-group" data-group-id="${group.id}" ${open}>
      <summary>
        <span class="status-summary-copy">${escapeHtml(group.label)}</span>
        <span class="status-summary-meta">
          <span class="status-count">${(group.lines || []).length} updates</span>
        </span>
      </summary>
      <div class="status-log">${lines}</div>
    </details>
  `;
}

function buildLegacyStatusMarkup(message) {
  const lines = (message.lines || [])
    .map((line) => `<div class="status-line">${escapeHtml(line)}</div>`)
    .join("");
  const open = message.open ? "open" : "";
  return `
    <div class="message-bubble">
      <details class="status-details" ${open}>
        <summary>${escapeHtml(message.summary || "Status updates")}</summary>
        <div class="status-log">${lines}</div>
      </details>
    </div>
  `;
}

function buildLegacyCardMarkup(message) {
  const inputById = new Map((message.inputs || []).map((input) => [input.id, input]));
  const layout = Array.isArray(message.layout) ? message.layout : [];

  const renderActions = (actions, actionGroup = "default") =>
    (actions || [])
      .map((action, index) => {
        const actionKey = `${actionGroup}:${index}`;
        return `<button type="button" class="ghost-button" data-card-action="${escapeHtml(actionKey)}">${escapeHtml(action.title)}</button>`;
      })
      .join("");

  const layoutMarkup = layout
    .map((item, index) => {
      if (item.type === "input") {
        const input = inputById.get(item.input_id);
        return input ? buildCardInputMarkup(input) : "";
      }
      if (item.type === "action_set") {
        return `<div class="card-actions card-actions-inline">${renderActions(item.actions || [], `inline-${index}`)}</div>`;
      }
      return "";
    })
    .join("");
  const fallbackInputsMarkup = (message.inputs || []).map((input) => buildCardInputMarkup(input)).join("");

  const renderedInlineActionCount = layout.reduce(
    (count, item) => count + (item.type === "action_set" ? (item.actions || []).length : 0),
    0,
  );
  const trailingActions = (message.actions || []).slice(renderedInlineActionCount);
  const actions = renderActions(trailingActions, "footer");

  return `
    <div class="message-bubble card-bubble">
      <div class="card-title">${escapeHtml(message.title || "Assistant Action")}</div>
      ${message.content ? `<div class="card-content">${renderRichText(message.content)}</div>` : ""}
      ${(layoutMarkup || fallbackInputsMarkup) ? `<div class="card-inputs">${layoutMarkup || fallbackInputsMarkup}</div>` : ""}
      ${actions ? `<div class="card-actions">${actions}</div>` : ""}
    </div>
  `;
}

function getCardKindFromPayload(payload) {
  if (payload?.card_kind) {
    return payload.card_kind;
  }
  if (payload?.title === "Select GitLab project and branch") {
    return "gitlab_rsc";
  }
  return null;
}

function getStoredCardKind(message) {
  if (message?.cardKind) {
    return message.cardKind;
  }
  if (
    (message?.title === "Select GitLab project and branch") ||
    (message?.responseType === "card" && message?.title === "Select GitLab project and branch")
  ) {
    return "gitlab_rsc";
  }
  return null;
}

function isCardMessage(message) {
  return (
    message &&
    ((message.role === "card") || (message.role === "assistant-turn" && message.responseType === "card"))
  );
}

function findCardTarget(conversation, payload) {
  const payloadKind = getCardKindFromPayload(payload);
  const reversedMessages = [...conversation.messages].reverse();

  if (payloadKind) {
    return reversedMessages.find((message) => isCardMessage(message) && getStoredCardKind(message) === payloadKind) || null;
  }

  if (!payload.replace_last_card) {
    return null;
  }

  return reversedMessages.find((message) => isCardMessage(message)) || null;
}

function dedupeCardMessages(conversation, retainedMessage) {
  const retainedKind = getStoredCardKind(retainedMessage);
  if (!retainedKind) {
    return;
  }

  conversation.messages = conversation.messages.filter((message) => {
    if (message === retainedMessage) {
      return true;
    }
    if (!isCardMessage(message)) {
      return true;
    }
    return getStoredCardKind(message) !== retainedKind;
  });
}

function removeCardMessage(sessionId, payload) {
  const conversation = getConversation(sessionId);
  if (!conversation) {
    return;
  }

  const payloadKind = getCardKindFromPayload(payload);
  if (payloadKind) {
    conversation.messages = conversation.messages.filter(
      (message) => !(isCardMessage(message) && getStoredCardKind(message) === payloadKind),
    );
  } else {
    let removed = false;
    conversation.messages = conversation.messages.filter((message) => {
      if (removed || !isCardMessage(message)) {
        return true;
      }
      removed = true;
      return false;
    });
  }

  conversation.updatedAt = Date.now();
  saveConversations();
  renderHistory();
  renderConversation();
}

function buildCardInputMarkup(input) {
  const label = input.label ? `<label class="card-input-label">${escapeHtml(input.label)}</label>` : "";
  const disabledAttr = input.enabled === false ? "disabled" : "";
  const liveRefreshAttr = input.liveRefresh ? 'data-card-live-refresh="true"' : "";
  if (input.kind === "textarea") {
    return `
      <div class="card-input-field">
        ${label}
        <textarea data-card-input="${escapeHtml(input.id)}" data-card-input-kind="textarea" placeholder="${escapeHtml(input.placeholder || "")}" ${liveRefreshAttr} ${disabledAttr}>${escapeHtml(input.value || "")}</textarea>
      </div>
    `;
  }
  if (input.kind === "select") {
    const options = (input.choices || [])
      .map(
        (choice) =>
          `<option value="${escapeHtml(choice.value)}" ${choice.value === input.value ? "selected" : ""}>${escapeHtml(choice.title)}</option>`,
      )
      .join("");
    return `
      <div class="card-input-field">
        ${label}
        <select data-card-input="${escapeHtml(input.id)}" data-card-input-kind="select" ${liveRefreshAttr} ${disabledAttr}>${options}</select>
      </div>
    `;
  }
  if (input.kind === "toggle") {
    return `
      <label class="card-toggle-field">
        <input
          type="checkbox"
          data-card-input="${escapeHtml(input.id)}"
          data-card-input-kind="toggle"
          data-value-on="${escapeHtml(input.valueOn || "true")}"
          data-value-off="${escapeHtml(input.valueOff || "false")}"
          ${liveRefreshAttr}
          ${disabledAttr}
          ${String(input.value || "") === String(input.valueOn || "true") ? "checked" : ""}
        />
        <span>${escapeHtml(input.label || input.id || "Toggle")}</span>
      </label>
    `;
  }
  return `
    <div class="card-input-field">
      ${label}
      <input data-card-input="${escapeHtml(input.id)}" data-card-input-kind="text" placeholder="${escapeHtml(input.placeholder || "")}" value="${escapeHtml(input.value || "")}" ${liveRefreshAttr} ${disabledAttr} />
    </div>
  `;
}

function collectCardInputValues(article, action = null) {
  const values = structuredClone(action?.data || {});
  if (action?.verb) {
    values.verb = action.verb;
  }
  if (action?.action_type) {
    values.action_type = action.action_type;
  }
  article.querySelectorAll("[data-card-input]").forEach((input) => {
    const inputKey = input.dataset.cardInput;
    if (!inputKey) {
      return;
    }
    const kind = input.dataset.cardInputKind || "text";
    if (kind === "toggle") {
      values[inputKey] = input.checked ? input.dataset.valueOn : input.dataset.valueOff;
    } else {
      const value = input.value;
      if (value === "" && Object.prototype.hasOwnProperty.call(values, inputKey)) {
        return;
      }
      values[inputKey] = value;
    }
  });
  return values;
}

function findMessageById(conversation, messageId) {
  if (!conversation || !messageId) {
    return null;
  }
  return conversation.messages.find((message) => message.id === messageId) || null;
}

function resolveCardAction(message, actionKey) {
  if (!message || !actionKey) {
    return null;
  }
  const [group, indexRaw] = String(actionKey).split(":");
  const index = Number(indexRaw);
  if (!Number.isFinite(index)) {
    return null;
  }
  if (group === "footer") {
    const layout = Array.isArray(message.layout) ? message.layout : [];
    const inlineCount = layout.reduce(
      (count, item) => count + (item.type === "action_set" ? (item.actions || []).length : 0),
      0,
    );
    return message.actions?.[inlineCount + index] || null;
  }
  if (group === "default") {
    return message.actions?.[index] || null;
  }
  if (group.startsWith("inline-")) {
    const layoutIndex = Number(group.replace("inline-", ""));
    const layoutItem = (message.layout || [])[layoutIndex];
    return layoutItem?.actions?.[index] || null;
  }
  return message.actions?.[Number(actionKey)] || null;
}

async function handleCardAction(button) {
  const article = button.closest("article");
  if (!article) {
    return;
  }
  const conversation = getConversation(activeSessionId);
  const message = findMessageById(conversation, article.dataset.messageId);
  if (!message) {
    return;
  }
  const action = resolveCardAction(message, button.dataset.cardAction || "");
  if (!action) {
    return;
  }

  const cardAction = collectCardInputValues(article, action);
  if (cardAction.selected_option) {
    addMessageToConversation(activeSessionId, {
      id: crypto.randomUUID(),
      role: "user",
      content: String(cardAction.selected_option),
      createdAt: Date.now(),
    });
  }

  await sendChat({ cardAction });
}

function wireStatusInteractions(article, message) {
  article.querySelectorAll("[data-turn-toggle='status']").forEach((details) => {
    details.addEventListener("toggle", () => {
      if (message.pending) {
        return;
      }
      message.statusOpen = details.open;
      if (details.open) {
        message.statusEntries = openAllStatusEntries(message.statusEntries || []);
        article.querySelectorAll(".status-log details:not(.sql-detail-details):not(.code-detail-details):not(.llm-content-details)").forEach((nested) => {
          nested.open = true;
        });
      }
      saveConversations();
    });
  });

  article.querySelectorAll("[data-entry-toggle='assistant']").forEach((details) => {
    details.addEventListener("toggle", () => {
      if (message.pending) {
        return;
      }
      const entry = (message.statusEntries || []).find((item) => item.id === details.dataset.entryId);
      if (!entry) {
        return;
      }
      entry.open = details.open;
      saveConversations();
    });
  });

  article.querySelectorAll("[data-entry-toggle='group']").forEach((details) => {
    details.addEventListener("toggle", () => {
      if (message.pending) {
        return;
      }
      const entry = (message.statusEntries || []).find((item) => item.id === details.dataset.entryId);
      if (!entry) {
        return;
      }
      entry.open = details.open;
      saveConversations();
    });
  });

  article.querySelectorAll("[data-entry-toggle='nested-group']").forEach((details) => {
    details.addEventListener("toggle", () => {
      if (message.pending) {
        return;
      }
      const group = findNestedGroupById(message.statusEntries || [], details.dataset.groupId);
      if (!group) {
        return;
      }
      group.open = details.open;
      saveConversations();
    });
  });
}

function wireLegacyStatusInteractions(article, message) {
  article.querySelectorAll(".status-details").forEach((details) => {
    details.addEventListener("toggle", () => {
      message.open = details.open;
      saveConversations();
    });
  });
}

function wireCardActions(article, message) {
  article.querySelectorAll("[data-card-action]").forEach((button) => {
    button.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      await handleCardAction(button);
    });
  });
}

function wireCardLiveInputs(article, message) {
  article.querySelectorAll("[data-card-live-refresh='true']").forEach((input) => {
    input.addEventListener("change", async () => {
      try {
        const values = collectCardInputValues(article);
        const payload = await openGitLabResourceMenu({
          selectedProject: values.selectedProject || "",
          selectedBranch: values.selectedBranch || "",
        });
        upsertCardMessage(activeSessionId, { ...payload, replace_last_card: true });
      } catch (error) {
        console.error("Failed to refresh card inputs", error);
      }
    });
  });
}

function wireCodeCopyButtons(article) {
  article.querySelectorAll("[data-copy-code]").forEach((button) => {
    button.addEventListener("click", async () => {
      const code = decodeURIComponent(button.dataset.copyCode || "");
      try {
        await navigator.clipboard.writeText(code);
        const previousLabel = button.textContent;
        button.textContent = "Copied";
        window.setTimeout(() => {
          button.textContent = previousLabel || "Copy";
        }, 1400);
      } catch (error) {
        console.error("Failed to copy code block", error);
        button.textContent = "Failed";
        window.setTimeout(() => {
          button.textContent = "Copy";
        }, 1400);
      }
    });
  });
  article.querySelectorAll("[data-download-code]").forEach((button) => {
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      downloadCodeBlock(button);
    });
  });
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function renderRichText(text) {
  return renderMarkdown(text || "");
}

function isCodeOnlyMarkdown(markdown) {
  const source = String(markdown || "").trim();
  if (!source.startsWith("```") || !source.endsWith("```")) {
    return false;
  }
  const matches = source.match(/```[\s\S]*?```/g);
  return Boolean(matches && matches.length === 1 && matches[0].trim() === source);
}

function renderMarkdown(markdown) {
  const source = String(markdown || "").replace(/\r\n/g, "\n");
  if (window.marked && window.DOMPurify) {
    try {
      const renderer = new window.marked.Renderer();
      renderer.code = (codeOrToken, infoString = "") => {
        const tokenMode = codeOrToken && typeof codeOrToken === "object";
        const codeText = tokenMode ? codeOrToken.text || codeOrToken.raw || "" : codeOrToken;
        const language = tokenMode ? codeOrToken.lang || "" : infoString;
        return renderCodeBlock(codeText, language);
      };
      window.marked.setOptions({
        gfm: true,
        breaks: false,
        renderer,
      });
      const rendered = window.marked.parse(source);
      return window.DOMPurify.sanitize(rendered, {
        ADD_ATTR: [
          "target",
          "rel",
          "data-copy-code",
          "data-download-code",
          "data-code-filename",
          "data-language",
        ],
      });
    } catch (error) {
      console.warn("Marked renderer failed, falling back to local renderer.", error);
    }
  }
  return renderMarkdownFallback(source);
}

function renderMarkdownFallback(source) {
  const lines = source.split("\n");
  const blocks = [];
  let index = 0;

  while (index < lines.length) {
    const line = lines[index];

    if (!line.trim()) {
      index += 1;
      continue;
    }

    const codeMatch = line.match(/^\s*```([^`]*)\s*$/);
    if (codeMatch) {
      const language = (codeMatch[1] || "").trim();
      index += 1;
      const codeLines = [];
      while (index < lines.length && !lines[index].match(/^\s*```\s*$/)) {
        codeLines.push(lines[index]);
        index += 1;
      }
      if (index < lines.length) {
        index += 1;
      }
      blocks.push(
        renderCodeBlock(codeLines.join("\n"), language),
      );
      continue;
    }

    const headingMatch = line.match(/^(#{1,6})\s+(.*)$/);
    if (headingMatch) {
      const level = headingMatch[1].length;
      blocks.push(`<h${level}>${renderInlineMarkdown(headingMatch[2])}</h${level}>`);
      index += 1;
      continue;
    }

    if (line.match(/^>\s?/)) {
      const quoteLines = [];
      while (index < lines.length && lines[index].match(/^>\s?/)) {
        quoteLines.push(lines[index].replace(/^>\s?/, ""));
        index += 1;
      }
      blocks.push(`<blockquote>${quoteLines.map((item) => renderInlineMarkdown(item)).join("<br />")}</blockquote>`);
      continue;
    }

    if (isMarkdownTableStart(lines, index)) {
      const tableLines = [];
      while (index < lines.length && lines[index].trim().startsWith("|")) {
        tableLines.push(lines[index]);
        index += 1;
      }
      blocks.push(renderMarkdownTable(tableLines));
      continue;
    }

    if (line.match(/^[-*+]\s+/)) {
      const items = [];
      while (index < lines.length && lines[index].match(/^[-*+]\s+/)) {
        items.push(lines[index].replace(/^[-*+]\s+/, ""));
        index += 1;
      }
      blocks.push(`<ul>${items.map((item) => `<li>${renderInlineMarkdown(item)}</li>`).join("")}</ul>`);
      continue;
    }

    const orderedMatch = line.match(/^(\d+)\.\s+/);
    if (orderedMatch) {
      const startNumber = Number(orderedMatch[1]) || 1;
      const items = [];
      while (index < lines.length && lines[index].match(/^\d+\.\s+/)) {
        items.push(lines[index].replace(/^\d+\.\s+/, ""));
        index += 1;
      }
      const startAttr = startNumber > 1 ? ` start="${startNumber}"` : "";
      blocks.push(`<ol${startAttr}>${items.map((item) => `<li>${renderInlineMarkdown(item)}</li>`).join("")}</ol>`);
      continue;
    }

    const paragraphLines = [];
    while (index < lines.length && lines[index].trim()) {
      if (
        lines[index].match(/^```/) ||
        lines[index].match(/^(#{1,6})\s+/) ||
        lines[index].match(/^>\s?/) ||
        isMarkdownTableStart(lines, index) ||
        lines[index].match(/^[-*+]\s+/) ||
        lines[index].match(/^\d+\.\s+/)
      ) {
        break;
      }
      paragraphLines.push(lines[index]);
      index += 1;
    }
    blocks.push(
      `<p>${paragraphLines.map((item) => renderInlineMarkdown(item)).join("<br />")}</p>`,
    );
  }

  return blocks.join("");
}

function splitMarkdownTableRow(line) {
  const trimmed = String(line || "").trim();
  return trimmed
    .replace(/^\|/, "")
    .replace(/\|$/, "")
    .split("|")
    .map((cell) => cell.trim());
}

function isMarkdownTableSeparator(line) {
  const cells = splitMarkdownTableRow(line);
  return cells.length > 0 && cells.every((cell) => /^:?-{3,}:?$/.test(cell));
}

function isMarkdownTableStart(lines, index) {
  return (
    index + 1 < lines.length &&
    lines[index].trim().startsWith("|") &&
    lines[index + 1].trim().startsWith("|") &&
    isMarkdownTableSeparator(lines[index + 1])
  );
}

function renderMarkdownTable(tableLines) {
  const header = splitMarkdownTableRow(tableLines[0] || "");
  const bodyRows = tableLines.slice(2).map(splitMarkdownTableRow);
  const headerMarkup = header
    .map((cell) => `<th>${renderInlineMarkdown(cell)}</th>`)
    .join("");
  const bodyMarkup = bodyRows
    .map((row) => {
      const cells = header.map((_, index) => row[index] || "");
      return `<tr>${cells.map((cell) => `<td>${renderInlineMarkdown(cell)}</td>`).join("")}</tr>`;
    })
    .join("");
  return `
    <div class="markdown-table-wrap">
      <table class="markdown-table">
        <thead><tr>${headerMarkup}</tr></thead>
        <tbody>${bodyMarkup}</tbody>
      </table>
    </div>
  `;
}

function normalizeCodeBlockContent(code) {
  const lines = String(code || "").replace(/\r\n/g, "\n").split("\n");
  while (lines.length && !lines[0].trim()) {
    lines.shift();
  }
  while (lines.length && !lines[lines.length - 1].trim()) {
    lines.pop();
  }
  return lines.join("\n");
}

function renderCodeBlock(code, language = "") {
  const normalizedCode = normalizeCodeBlockContent(code);
  const escapedCode = escapeHtml(normalizedCode);
  const normalizedLanguage = normalizeCodeLanguage(language);
  const escapedLanguage = escapeHtml(normalizedLanguage);
  const copyPayload = escapeHtml(encodeURIComponent(normalizedCode));
  const filename = codeDownloadFilename(normalizedLanguage);
  const toolbarClass = escapedLanguage ? "code-block-toolbar" : "code-block-toolbar code-block-toolbar-compact";
  const languageLabel = escapedLanguage
    ? `<span class="code-block-language">${escapedLanguage}</span>`
    : "";
  return `
    <div class="code-block-shell">
      <div class="${toolbarClass}">
        ${languageLabel}
        <div class="code-block-actions">
          <button type="button" class="code-copy-button" data-copy-code="${copyPayload}">Copy</button>
          <button type="button" class="code-download-button" data-download-code="${copyPayload}" data-code-filename="${escapeHtml(filename)}">Download</button>
        </div>
      </div>
      <pre><code${normalizedLanguage ? ` data-language="${escapedLanguage}"` : ""}>${escapedCode}</code></pre>
    </div>
  `;
}

function normalizeCodeLanguage(language = "") {
  return String(language || "").trim().split(/\s+/)[0].replace(/[^\w#+.-]/g, "").toLowerCase();
}

function codeDownloadFilename(language = "") {
  const extensionByLanguage = {
    bash: "sh",
    shell: "sh",
    sh: "sh",
    zsh: "sh",
    python: "py",
    py: "py",
    javascript: "js",
    js: "js",
    typescript: "ts",
    ts: "ts",
    json: "json",
    sql: "sql",
    html: "html",
    css: "css",
    java: "java",
    xml: "xml",
    yaml: "yaml",
    yml: "yml",
    markdown: "md",
    md: "md",
  };
  const ext = extensionByLanguage[normalizeCodeLanguage(language)] || "txt";
  return `code.${ext}`;
}

function inferCodeLanguage(text = "", hint = "") {
  const source = String(text || "").trim();
  const normalizedHint = normalizeCodeLanguage(hint);
  if (normalizedHint.includes("sql")) return "sql";
  if (/^<!doctype html/i.test(source) || /^<html[\s>]/i.test(source)) return "html";
  if (/^(select|with|insert|update|delete|create|drop|alter)\b/i.test(source)) return "sql";
  if (/^\s*[{[]/.test(source)) return "json";
  if (/^\s*(def |import |from |class |print\()/m.test(source)) return "python";
  if (/^\s*(const |let |var |function |import .* from )/m.test(source)) return "javascript";
  if (/^\s*#!/.test(source)) return "shell";
  return normalizedHint || "";
}

function looksLikeGeneratedCode(text = "") {
  const source = String(text || "").trim();
  return (
    source.includes("\n") ||
    /^<!doctype html/i.test(source) ||
    /^<html[\s>]/i.test(source) ||
    /^(select|with|insert|update|delete|create|drop|alter)\b/i.test(source) ||
    /^\s*(def |import |from |class |const |let |var |function )/m.test(source)
  );
}

function renderInlineMarkdown(text) {
  const placeholders = [];
  let rendered = escapeHtml(text || "");

  rendered = rendered.replace(/`([^`]+)`/g, (_, code) => {
    const token = `@@INLINECODE${placeholders.length}@@`;
    placeholders.push(`<code>${escapeHtml(code)}</code>`);
    return token;
  });

  rendered = rendered.replace(
    /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
    (_, label, url) => `<a href="${escapeHtml(url)}" target="_blank" rel="noreferrer">${escapeHtml(label)}</a>`,
  );
  rendered = rendered.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  rendered = rendered.replace(/(^|[^\*])\*([^*]+)\*/g, "$1<em>$2</em>");
  rendered = rendered.replace(/(^|[^_])_([^_]+)_/g, "$1<em>$2</em>");

  placeholders.forEach((html, index) => {
    rendered = rendered.split(`@@INLINECODE${index}@@`).join(html);
  });

  return rendered;
}

function formatDurationLabel(startedAt, finishedAt, pending) {
  const start = Number(startedAt) || Date.now();
  const end = pending ? Date.now() : Number(finishedAt) || Date.now();
  const totalSeconds = Math.max(0, Math.floor((end - start) / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  const clock = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  return pending ? `Elapsed ${clock}` : `Completed in ${clock}`;
}

function updateVisibleDurations() {
  document.querySelectorAll(".status-duration").forEach((element) => {
    const startedAt = element.dataset.startedAt;
    const finishedAt = element.dataset.finishedAt;
    const pending = element.dataset.pending === "true";
    element.textContent = formatDurationLabel(startedAt, finishedAt, pending);
  });
}

function startTimerLoop() {
  if (timerIntervalId) {
    return;
  }
  timerIntervalId = window.setInterval(updateVisibleDurations, 250);
}

function scrollToBottom() {
  requestAnimationFrame(() => {
    elements.messageScroll.scrollTop = elements.messageScroll.scrollHeight;
  });
}

function scheduleStatusRender() {
  if (statusRenderQueued) {
    return;
  }
  statusRenderQueued = true;
  requestAnimationFrame(() => {
    statusRenderQueued = false;
    renderHistory();
    renderConversation();
  });
}

function getBlockingCardMessage(conversation) {
  if (!conversation) {
    return null;
  }
  const lastAssistantMessage = [...conversation.messages]
    .reverse()
    .find((message) => message.role !== "user");
  if (!lastAssistantMessage) {
    return null;
  }
  if (lastAssistantMessage.role === "card" && (lastAssistantMessage.actions || []).length) {
    return lastAssistantMessage;
  }
  if (
    lastAssistantMessage.role === "assistant-turn" &&
    lastAssistantMessage.responseType === "card" &&
    (lastAssistantMessage.actions || []).length
  ) {
    return lastAssistantMessage;
  }
  return null;
}

function isComposerBlockedByCard(conversation) {
  const blockingCard = getBlockingCardMessage(conversation);
  if (!blockingCard) {
    return false;
  }
  return Boolean((blockingCard.actions || []).length || (blockingCard.inputs || []).length);
}

function refreshComposerAvailability() {
  const conversation = getConversation(activeSessionId);
  const hasBlockingCard = isComposerBlockedByCard(conversation);
  elements.composerForm.classList.toggle("card-mode", hasBlockingCard);
  if (hasBlockingCard && !currentRequestSessionId) {
    elements.chatInput.disabled = true;
    elements.sendButton.disabled = true;
  }
}

function setLoading(loading) {
  elements.stopButton.disabled = !loading;
  elements.sendButton.disabled = loading;
  elements.chatInput.disabled = loading;
  elements.newChatButton.disabled = loading;
  elements.clearHistoryButton.disabled = loading;
  if (elements.promptOButton) {
    elements.promptOButton.disabled = loading || promptModalBusy;
  }
  if (elements.promptEButton) {
    elements.promptEButton.disabled = loading || promptModalBusy;
  }
  elements.composerProcessing.classList.toggle("active", loading);
  elements.composerForm.classList.toggle("processing", loading);
  currentRequestSessionId = loading ? activeSessionId : null;
  renderHistory();
  refreshComposerAvailability();
}

function setPromptModalBusy(busy) {
  promptModalBusy = busy;
  if (elements.promptModalTextarea) {
    elements.promptModalTextarea.disabled = busy;
  }
  if (elements.promptModalSaveButton) {
    elements.promptModalSaveButton.disabled = busy;
  }
  if (elements.promptModalCancelButton) {
    elements.promptModalCancelButton.disabled = busy;
  }
  if (elements.promptModalCloseButton) {
    elements.promptModalCloseButton.disabled = busy;
  }
  if (elements.promptOButton) {
    elements.promptOButton.disabled = busy || Boolean(currentRequestSessionId);
  }
  if (elements.promptEButton) {
    elements.promptEButton.disabled = busy || Boolean(currentRequestSessionId);
  }
}

function setPromptModalStatus(message = "", tone = "") {
  elements.promptModalStatus.textContent = message;
  elements.promptModalStatus.className = "prompt-modal-status";
  if (tone) {
    elements.promptModalStatus.classList.add(tone);
  }
}

function closePromptModal() {
  activePromptModalKind = null;
  setPromptModalBusy(false);
  setPromptModalStatus("");
  elements.promptModalBackdrop.hidden = true;
  elements.promptModalTextarea.value = "";
}

async function openPromptModal(promptKind) {
  const conversation = await ensureActiveConversation();
  activePromptModalKind = promptKind;
  setPromptModalBusy(true);
  setPromptModalStatus("Loading prompt...");
  elements.promptModalBackdrop.hidden = false;

  try {
    const response = await fetch("/api/web/prompt-modal", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: conversation.sessionId,
        prompt_kind: promptKind,
      }),
    });
    if (!response.ok) {
      throw new Error(await response.text());
    }
    const payload = await response.json();
    if (activePromptModalKind !== promptKind) {
      return;
    }
    elements.promptModalTitle.textContent = payload.title || "Prompt";
    elements.promptModalSubtitle.textContent = payload.subtitle || "";
    elements.promptModalTextarea.value = payload.value || "";
    setPromptModalStatus("");
    setPromptModalBusy(false);
    elements.promptModalTextarea.focus();
  } catch (error) {
    setPromptModalStatus(`Request failed: ${error.message}`, "error");
    setPromptModalBusy(false);
  }
}

async function savePromptModal() {
  if (!activePromptModalKind) {
    return;
  }
  const conversation = await ensureActiveConversation();
  setPromptModalBusy(true);
  setPromptModalStatus("Saving...");

  try {
    const response = await fetch("/api/web/prompt-modal/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: conversation.sessionId,
        prompt_kind: activePromptModalKind,
        value: elements.promptModalTextarea.value,
      }),
    });
    if (!response.ok) {
      throw new Error(await response.text());
    }
    setPromptModalStatus("Saved successfully.", "success");
    window.setTimeout(() => {
      if (!promptModalBusy) {
        closePromptModal();
      }
    }, 500);
    setPromptModalBusy(false);
  } catch (error) {
    setPromptModalStatus(`Save failed: ${error.message}`, "error");
    setPromptModalBusy(false);
  }
}

function addMessageToConversation(sessionId, message) {
  const conversation = getConversation(sessionId);
  if (!conversation) {
    return;
  }
  conversation.messages.push(message);
  conversation.updatedAt = Date.now();
  if (conversation.title === "New Chat" && message.role === "user") {
    conversation.title = truncateTitle(message.content);
  }
  saveConversations();
  renderHistory();
  renderConversation();
}

function findPendingTurn(conversation) {
  if (!conversation) {
    return null;
  }
  return [...conversation.messages].reverse().find((message) => message.role === "assistant-turn" && message.pending) || null;
}

function ensurePendingTurn(sessionId) {
  const conversation = getConversation(sessionId);
  if (!conversation) {
    return null;
  }
  let turn = findPendingTurn(conversation);
  if (!turn) {
    turn = createPendingTurnMessage();
    conversation.messages.push(turn);
  }
  conversation.updatedAt = Date.now();
  saveConversations();
  renderConversation();
  void refreshArtifactsForTurn(sessionId, turn.id, turn.statusStartedAt || turn.createdAt);
  return turn;
}

async function refreshArtifactsForTurn(sessionId, turnId, sinceMs) {
  try {
    const response = await fetch(
      `/api/web/artifacts?session_id=${encodeURIComponent(sessionId)}&since_ms=${encodeURIComponent(String(sinceMs || 0))}`,
    );
    if (!response.ok) {
      return;
    }
    const payload = await response.json();
    const artifacts = payload.artifacts || [];
    if (!artifacts.length) {
      return;
    }
    const conversation = getConversation(sessionId);
    const message = conversation?.messages.find((item) => item.id === turnId);
    if (!message) {
      return;
    }
    message.artifacts = artifacts;
    conversation.updatedAt = Date.now();
    saveConversations();
    renderConversation();
  } catch (error) {
    console.error("Failed to refresh generated artifacts", error);
  }
}

function humanizeAgentLabel(agentKey) {
  if (!agentKey || agentKey === "system") {
    return "System";
  }
  if (agentKey.startsWith("skill:")) {
    return `${agentKey.slice("skill:".length)} skill`;
  }
  const cleaned = agentKey.endsWith("_agent") ? agentKey.slice(0, -6) : agentKey;
  return `${cleaned.replaceAll("_", " ")} skill`;
}

function parseStatusEvent(content) {
  const raw = String(content || "").trim();
  const match = raw.match(/^\[([^\]]+)\]\s*(.*)$/);
  if (!match) {
    return {
      agentKey: "system",
      label: "System",
      line: raw,
    };
  }
  return {
    agentKey: match[1],
    label: humanizeAgentLabel(match[1]),
    line: match[2] || raw,
  };
}

function parseAgentKeyFromMessage(content) {
  const raw = String(content || "").trim();
  const match = raw.match(/^\[([^\]]+)\]/);
  return match ? match[1] : null;
}

function findNestedGroupById(entries, groupId) {
  for (const entry of entries) {
    if (entry.kind !== "assistant_update") {
      continue;
    }
    const group = (entry.agentGroups || []).find((item) => item.id === groupId);
    if (group) {
      return group;
    }
  }
  return null;
}

function countStatusLines(entries) {
  const countLineAndChildren = (line) =>
    1 + (line.children || []).reduce((childCount, child) => childCount + countLineAndChildren(child), 0);
  return entries.reduce((count, entry) => {
    if (entry.kind === "assistant_update") {
      return (
        count +
        (entry.agentGroups || []).reduce(
          (groupCount, group) =>
            groupCount + (group.lines || []).reduce((lineCount, line) => lineCount + countLineAndChildren(line), 0),
          0,
        )
      );
    }
    return count + (entry.lines || []).reduce((lineCount, line) => lineCount + countLineAndChildren(line), 0);
  }, 0);
}

function lineHasStructuredDetail(line) {
  return (
    line?.detail?.type === "sql" ||
    line?.detail?.type === "code" ||
    line?.detail?.type === "llm_content" ||
    (line?.children || []).some((child) => lineHasStructuredDetail(child))
  );
}

function entryHasStructuredDetail(entry) {
  if (!entry) {
    return false;
  }
  if (entry.kind === "assistant_update") {
    return (entry.agentGroups || []).some((group) =>
      (group.lines || []).some((line) => lineHasStructuredDetail(line)),
    );
  }
  return (entry.lines || []).some((line) => lineHasStructuredDetail(line));
}

function turnHasStructuredDetail(entries) {
  return (entries || []).some((entry) => entryHasStructuredDetail(entry));
}

function openAllStatusEntries(entries) {
  return (entries || []).map((entry) => {
    if (entry.kind === "assistant_update") {
      return {
        ...entry,
        open: true,
        agentGroups: (entry.agentGroups || []).map((group) => ({
          ...group,
          open: true,
        })),
      };
    }
    return {
      ...entry,
      open: true,
    };
  });
}

function findLatestRunningToolLine(group, toolName) {
  if (!group || !Array.isArray(group.lines)) {
    return null;
  }
  const expected = `Running \`${toolName}\``;
  for (let index = group.lines.length - 1; index >= 0; index -= 1) {
    const line = group.lines[index];
    if (line.content === expected) {
      return line;
    }
  }
  return null;
}

function appendStatusLineToGroup(group, line, detail = null) {
  const parentTool = detail?.parent_tool;
  if (parentTool) {
    const parentLine = findLatestRunningToolLine(group, parentTool);
    if (parentLine) {
      parentLine.children = parentLine.children || [];
      parentLine.children.push(line);
      return;
    }
  }
  group.lines.push(line);
}

function addStatusToTurn(sessionId, content, kind = "agent_status", detail = null) {
  const conversation = getConversation(sessionId);
  const turn = ensurePendingTurn(sessionId);
  if (!conversation || !turn) {
    return;
  }

  if (kind === "assistant_update") {
    turn.statusEntries.push({
      id: crypto.randomUUID(),
      kind: "assistant_update",
      content: String(content || "").trim(),
      sourceAgentKey: parseAgentKeyFromMessage(content),
      open: true,
      agentGroups: [],
    });
  } else {
    const parsed = parseStatusEvent(content);
    const lastEntry = turn.statusEntries[turn.statusEntries.length - 1];

    const shouldNestUnderAssistant =
      lastEntry &&
      lastEntry.kind === "assistant_update" &&
      lastEntry.sourceAgentKey &&
      lastEntry.sourceAgentKey === parsed.agentKey;

    if (shouldNestUnderAssistant) {
      let group = (lastEntry.agentGroups || []).find((item) => item.agentKey === parsed.agentKey);
      if (!group) {
        group = {
          id: crypto.randomUUID(),
          agentKey: parsed.agentKey,
          label: parsed.label,
          lines: [],
          open: true,
        };
        lastEntry.agentGroups.push(group);
      }
      appendStatusLineToGroup(group, {
        id: crypto.randomUUID(),
        content: parsed.line,
        detail,
        createdAt: Date.now(),
      }, detail);
    } else {
      let group = lastEntry && lastEntry.kind === "status_group" && lastEntry.agentKey === parsed.agentKey ? lastEntry : null;
      if (!group) {
        group = {
          id: crypto.randomUUID(),
          kind: "status_group",
          agentKey: parsed.agentKey,
          label: parsed.label,
          lines: [],
          open: true,
        };
        turn.statusEntries.push(group);
      }
      appendStatusLineToGroup(group, {
        id: crypto.randomUUID(),
        content: parsed.line,
        detail,
        createdAt: Date.now(),
      }, detail);
    }
  }

  turn.statusOpen = true;
  turn.statusFinishedAt = null;
  conversation.updatedAt = Date.now();
  saveConversations();
  scheduleStatusRender();
}

function finalizeTurn(sessionId, patch = {}) {
  const conversation = getConversation(sessionId);
  if (!conversation) {
    return null;
  }
  const turn = findPendingTurn(conversation);
  if (!turn) {
    return null;
  }

  Object.assign(turn, patch);
  turn.pending = false;
  turn.statusFinishedAt = Date.now();
  const keepStatusOpen = turnHasStructuredDetail(turn.statusEntries || []);
  turn.statusOpen = keepStatusOpen;
  turn.statusEntries = (turn.statusEntries || []).map((entry) => {
    const keepEntryOpen = keepStatusOpen && entryHasStructuredDetail(entry);
    if (entry.kind === "assistant_update") {
      return {
        ...entry,
        open: keepEntryOpen,
        agentGroups: (entry.agentGroups || []).map((group) => ({
          ...group,
          open: keepEntryOpen,
        })),
      };
    }
    return {
      ...entry,
      open: keepEntryOpen,
    };
  });
  conversation.updatedAt = Date.now();
  saveConversations();
  renderHistory();
  renderConversation();
  return turn;
}

function upsertCardMessage(sessionId, payload) {
  const conversation = getConversation(sessionId);
  if (!conversation) {
    return;
  }
  const target = findCardTarget(conversation, payload);
  const payloadKind = getCardKindFromPayload(payload);

  if (!target) {
    const newMessage = {
      id: crypto.randomUUID(),
      role: "card",
      title: payload.title,
      content: payload.content,
      inputs: payload.inputs,
      actions: payload.actions,
      layout: payload.layout,
      cardKind: payloadKind,
      createdAt: Date.now(),
    };
    conversation.messages.push(newMessage);
    dedupeCardMessages(conversation, newMessage);
  } else if (target.role === "assistant-turn") {
    target.title = payload.title;
    target.cardContent = payload.content;
    target.inputs = payload.inputs;
    target.actions = payload.actions;
    target.layout = payload.layout;
    target.cardKind = payloadKind;
    dedupeCardMessages(conversation, target);
  } else {
    target.title = payload.title;
    target.content = payload.content;
    target.inputs = payload.inputs;
    target.actions = payload.actions;
    target.layout = payload.layout;
    target.cardKind = payloadKind;
    dedupeCardMessages(conversation, target);
  }
  conversation.updatedAt = Date.now();
  saveConversations();
  renderHistory();
  renderConversation();
}

function ensureTurnCompleted(sessionId) {
  const conversation = getConversation(sessionId);
  if (!conversation) {
    return;
  }
  const turn = findPendingTurn(conversation);
  if (!turn) {
    return;
  }
  finalizeTurn(sessionId);
}

async function sendChat({ message = "", cardAction = null } = {}) {
  const conversation = await ensureActiveConversation();

  currentAbortController = new AbortController();
  const expectsGraphReply = Boolean(message || cardAction?.func_call || cardAction?.selected_option);
  setLoading(true);
  if (expectsGraphReply) {
    ensurePendingTurn(conversation.sessionId);
  }

  try {
    const response = await fetch("/api/web/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: conversation.sessionId,
        ...(message ? { message } : {}),
        ...(cardAction ? { card_action: cardAction } : {}),
      }),
      signal: currentAbortController.signal,
    });

    if (!response.ok || !response.body) {
      throw new Error(await response.text());
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) {
        break;
      }
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        if (!line.trim()) {
          continue;
        }
        const event = JSON.parse(line);
        handleStreamEvent(conversation.sessionId, event);
      }
    }
  } catch (error) {
    if (error.name === "AbortError") {
      addStatusToTurn(conversation.sessionId, "[system] The current turn was stopped.");
      finalizeTurn(conversation.sessionId, {
        responseType: "assistant",
        responseVariant: "muted",
        content: "Generation stopped.",
      });
    } else {
      finalizeTurn(conversation.sessionId, {
        responseType: "assistant",
        content: `Request failed: ${error.message}`,
      });
    }
  } finally {
    currentAbortController = null;
    setLoading(false);
  }
}

function handleStreamEvent(sessionId, event) {
  if (event.type === "status") {
    addStatusToTurn(sessionId, event.content, event.kind || "agent_status", event.detail || null);
    return;
  }

  if (event.type === "assistant") {
    finalizeTurn(sessionId, {
      responseType: "assistant",
      content: event.content,
      responseVariant: "default",
    });
    return;
  }

  if (event.type === "card") {
    if (event.remove_card) {
      removeCardMessage(sessionId, event);
      return;
    }
    if (event.replace_last_card) {
      upsertCardMessage(sessionId, event);
    } else {
      finalizeTurn(sessionId, {
        responseType: "card",
        title: event.title,
        cardContent: event.content,
        inputs: event.inputs,
        actions: event.actions,
        layout: event.layout,
        cardKind: event.card_kind || null,
      });
    }
    return;
  }

  if (event.type === "error") {
    finalizeTurn(sessionId, {
      responseType: "assistant",
      content: `Error: ${event.content}`,
      responseVariant: "default",
    });
    return;
  }

  if (event.type === "stopped") {
    addStatusToTurn(sessionId, "[system] The current turn was stopped.");
    finalizeTurn(sessionId, {
      responseType: "assistant",
      responseVariant: "muted",
      content: "Generation stopped.",
    });
    return;
  }

  if (event.type === "done") {
    ensureTurnCompleted(sessionId);
  }
}

async function handleSubmit(event) {
  event.preventDefault();
  if (isComposerBlockedByCard(getConversation(activeSessionId))) {
    return;
  }
  const text = elements.chatInput.value.trim();
  if (!text) {
    return;
  }

  const conversation = await ensureActiveConversation();
  addMessageToConversation(conversation.sessionId, {
    id: crypto.randomUUID(),
    role: "user",
    content: text,
    createdAt: Date.now(),
  });
  elements.chatInput.value = "";
  autoresizeInput();
  await sendChat({ message: text });
}

function autoresizeInput() {
  elements.chatInput.style.height = "auto";
  elements.chatInput.style.height = `${Math.min(elements.chatInput.scrollHeight, 220)}px`;
}

async function startNewChat() {
  const sessionId = await createSession();
  const conversation = createEmptyConversation(sessionId);
  conversations.unshift(conversation);
  activeSessionId = sessionId;
  saveConversations();
  renderHistory();
  renderConversation();
  closeSidebar();
  elements.chatInput.focus();
}

function clearAllHistory() {
  conversations = [];
  activeSessionId = null;
  saveConversations();
  renderHistory();
  renderConversation();
}

async function stopCurrentTurn() {
  if (!currentRequestSessionId) {
    return;
  }
  await fetch("/api/web/stop", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ session_id: currentRequestSessionId }),
  });
  currentAbortController?.abort();
}

function openSidebar() {
  elements.sidebar.classList.add("open");
  elements.sidebarBackdrop.classList.add("open");
}

function closeSidebar() {
  elements.sidebar.classList.remove("open");
  elements.sidebarBackdrop.classList.remove("open");
}

elements.composerForm.addEventListener("submit", handleSubmit);
elements.chatInput.addEventListener("input", autoresizeInput);
if (elements.promptOButton) {
  elements.promptOButton.addEventListener("click", async () => {
    await openPromptModal("prompt_o");
  });
}
if (elements.promptEButton) {
  elements.promptEButton.addEventListener("click", async () => {
    await openPromptModal("prompt_e");
  });
}
elements.promptModalSaveButton.addEventListener("click", savePromptModal);
elements.promptModalCancelButton.addEventListener("click", closePromptModal);
elements.promptModalCloseButton.addEventListener("click", closePromptModal);
elements.promptModalBackdrop.addEventListener("click", (event) => {
  if (event.target === elements.promptModalBackdrop && !promptModalBusy) {
    closePromptModal();
  }
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !elements.promptModalBackdrop.hidden && !promptModalBusy) {
    closePromptModal();
  }
});
elements.messageStream.addEventListener("click", async (event) => {
  const csvButton = event.target.closest("[data-download-sql-csv]");
  if (csvButton && elements.messageStream.contains(csvButton)) {
    event.preventDefault();
    downloadSqlCsv(csvButton);
    return;
  }

  const codeDownloadButton = event.target.closest("[data-download-code]");
  if (codeDownloadButton && elements.messageStream.contains(codeDownloadButton)) {
    event.preventDefault();
    downloadCodeBlock(codeDownloadButton);
    return;
  }

  const button = event.target.closest("[data-card-action]");
  if (!button || !elements.messageStream.contains(button)) {
    return;
  }
  event.preventDefault();
  await handleCardAction(button);
});
elements.newChatButton.addEventListener("click", startNewChat);
elements.clearHistoryButton.addEventListener("click", clearAllHistory);
elements.stopButton.addEventListener("click", stopCurrentTurn);
elements.menuButton.addEventListener("click", () => {
  if (elements.sidebar.classList.contains("open")) {
    closeSidebar();
  } else {
    openSidebar();
  }
});
elements.sidebarBackdrop.addEventListener("click", closeSidebar);

(async function init() {
  if (!activeSessionId) {
    await startNewChat();
  } else {
    renderHistory();
    renderConversation();
  }
  autoresizeInput();
  startTimerLoop();
})();
