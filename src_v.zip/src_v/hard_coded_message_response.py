"""File containing hard-coded response strings."""


def get_hello_response_fr() -> str:
    """Return hard coded hello response in French."""
    return "Bonjour, comment puis-je vous aider aujourd'hui ?"


def get_hello_response_en() -> str:
    """Return hard coded hello response in English."""
    return "Hi, how can I assist you today?"
