"""Helpers for the browser-based chat interface."""

import asyncio
import json
import logging
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from aiohttp.client_exceptions import ClientConnectionResetError
from aiohttp.web import FileResponse, HTTPBadRequest, Request, StreamResponse, json_response

from app_code.skills_runtime.storage import (
    USE_SQLITE_STORAGE,
    append_messages_user,
    get_prompt_value,
    init_workflow_state,
    is_complex_task_request,
    load_root_onboarding_prompt,
    retrieve_last_input,
    save_root_onboarding_prompt,
    save_prompt_value,
)
from app_code.skills_runtime.structs import GLOBAL_DB_POOL, WORKFLOW_STATE_BY_USER, NodeNames

WEBUI_DIR = Path(__file__).resolve().parent / "webui"


@dataclass
class WebChatRuntime:
    """Tracks the currently running streamed turn for a browser chat session."""

    queue: asyncio.Queue = field(default_factory=asyncio.Queue)
    task: asyncio.Task | None = None


class WebActivityContext:
    """Minimal progress sink used by the HTML skill runtime."""

    def __init__(self, runtime: WebChatRuntime):
        self.runtime = runtime
        self.loop = asyncio.get_running_loop()

    async def send_activity(self, activity: Any) -> None:
        payload = _activity_to_event(activity)
        if payload is not None:
            await self.runtime.queue.put(payload)

    async def send_progress_event(
        self,
        message: str,
        kind: str = "agent_status",
        detail: dict[str, Any] | None = None,
    ) -> None:
        payload = {
            "type": "status",
            "content": message,
            "kind": kind,
        }
        if detail is not None:
            payload["detail"] = detail
        await self.runtime.queue.put(payload)

    def send_progress_event_sync(
        self,
        message: str,
        kind: str = "agent_status",
        detail: dict[str, Any] | None = None,
    ) -> None:
        payload = {
            "type": "status",
            "content": message,
            "kind": kind,
        }
        if detail is not None:
            payload["detail"] = detail
        self.loop.call_soon_threadsafe(self.runtime.queue.put_nowait, payload)

    async def update_activity(self, activity: Any) -> None:
        payload = _activity_to_event(activity)
        if payload is not None:
            payload["replace_last_card"] = True
            await self.runtime.queue.put(payload)


def _text_block_lines(card_content: dict[str, Any]) -> list[str]:
    lines: list[str] = []
    
    def walk_items(items: list[dict[str, Any]]) -> None:
        for item in items:
            if item.get("type") == "TextBlock" and item.get("text"):
                lines.append(str(item["text"]))
            if item.get("type") == "RichTextBlock":
                text = "".join(str(inline.get("text", "")) for inline in item.get("inlines", []))
                if text:
                    lines.append(text)
            if item.get("type") == "CodeBlock" and item.get("codeSnippet"):
                language = str(item.get("language", "")).strip().lower()
                snippet = str(item.get("codeSnippet", ""))
                fence = f"```{language}" if language else "```"
                lines.append(f"{fence}\n{snippet}\n```")
            nested_items = item.get("items", [])
            if nested_items:
                walk_items(nested_items)
            for column in item.get("columns", []):
                walk_items(column.get("items", []))

    walk_items(card_content.get("body", []))
    return lines


def _extract_card_action(action: dict[str, Any], fallback_title: str = "Select") -> dict[str, Any] | None:
    action_type = action.get("type")
    if action_type not in {"Action.Submit", "Action.Execute"}:
        return None
    return {
        "title": action.get("title", fallback_title),
        "data": dict(action.get("data", {})),
        "verb": action.get("verb"),
        "action_type": action_type,
    }


def _extract_card_layout(
    items: list[dict[str, Any]],
    inputs: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    layout: list[dict[str, Any]] = []
    for item in items:
        item_type = item.get("type", "")
        if item_type in {"TextBlock", "RichTextBlock", "CodeBlock"}:
            continue

        if item_type == "Input.Text":
            input_id = item.get("id")
            inputs.append(
                {
                    "id": input_id,
                    "kind": "textarea" if item.get("isMultiline") else "text",
                    "placeholder": item.get("placeholder", ""),
                    "label": item.get("label", ""),
                    "value": item.get("value", ""),
                    "enabled": item.get("isEnabled", True),
                    "liveRefresh": item.get("webRefreshOnChange", False),
                }
            )
            layout.append({"type": "input", "input_id": input_id})
            continue

        if item_type == "Input.ChoiceSet":
            input_id = item.get("id")
            inputs.append(
                {
                    "id": input_id,
                    "kind": "select",
                    "label": item.get("label", ""),
                    "value": item.get("value", ""),
                    "enabled": item.get("isEnabled", True),
                    "liveRefresh": item.get("webRefreshOnChange", False),
                    "choices": [
                        {
                            "title": choice.get("title", choice.get("value", "")),
                            "value": choice.get("value", ""),
                        }
                        for choice in item.get("choices", [])
                    ],
                }
            )
            layout.append({"type": "input", "input_id": input_id})
            continue

        if item_type == "Input.Toggle":
            input_id = item.get("id")
            inputs.append(
                {
                    "id": input_id,
                    "kind": "toggle",
                    "label": item.get("label") or item.get("title", ""),
                    "value": item.get("value", ""),
                    "valueOn": item.get("valueOn", "true"),
                    "valueOff": item.get("valueOff", "false"),
                    "enabled": item.get("isEnabled", True),
                    "liveRefresh": item.get("webRefreshOnChange", False),
                }
            )
            layout.append({"type": "input", "input_id": input_id})
            continue

        if item_type == "ActionSet":
            actions: list[dict[str, Any]] = []
            for action in item.get("actions", []):
                extracted = _extract_card_action(action, action.get("title", "Submit"))
                if extracted:
                    actions.append(extracted)
            if actions:
                layout.append({"type": "action_set", "actions": actions})
            continue

        nested_items = item.get("items", [])
        if nested_items:
            layout.extend(_extract_card_layout(nested_items, inputs))

        for column in item.get("columns", []):
            layout.extend(_extract_card_layout(column.get("items", []), inputs))

    return layout


def _infer_card_kind(actions: list[dict[str, Any]], lines: list[str]) -> str | None:
    verbs = {str(action.get("verb", "")).strip() for action in actions if action.get("verb")}
    title = lines[0].strip() if lines else ""
    if "select_rsc" in verbs or title == "Select GitLab project and branch":
        return "gitlab_rsc"
    return None


def _collect_card_controls(
    items: list[dict[str, Any]],
    inputs: list[dict[str, Any]],
    actions: list[dict[str, Any]],
) -> None:
    for item in items:
        item_type = item.get("type", "")
        if item_type == "Input.Text":
            inputs.append(
                {
                    "id": item.get("id"),
                    "kind": "textarea" if item.get("isMultiline") else "text",
                    "placeholder": item.get("placeholder", ""),
                    "label": item.get("label", ""),
                    "value": item.get("value", ""),
                    "enabled": item.get("isEnabled", True),
                    "liveRefresh": item.get("webRefreshOnChange", False),
                }
            )
        elif item_type == "Input.ChoiceSet":
            inputs.append(
                {
                    "id": item.get("id"),
                    "kind": "select",
                    "label": item.get("label", ""),
                    "value": item.get("value", ""),
                    "enabled": item.get("isEnabled", True),
                    "liveRefresh": item.get("webRefreshOnChange", False),
                    "choices": [
                        {
                            "title": choice.get("title", choice.get("value", "")),
                            "value": choice.get("value", ""),
                        }
                        for choice in item.get("choices", [])
                    ],
                }
            )
        elif item_type == "Input.Toggle":
            inputs.append(
                {
                    "id": item.get("id"),
                    "kind": "toggle",
                    "label": item.get("label") or item.get("title", ""),
                    "value": item.get("value", ""),
                    "valueOn": item.get("valueOn", "true"),
                    "valueOff": item.get("valueOff", "false"),
                    "enabled": item.get("isEnabled", True),
                    "liveRefresh": item.get("webRefreshOnChange", False),
                }
            )

        inline_action = item.get("inlineAction")
        if isinstance(inline_action, dict):
            extracted = _extract_card_action(inline_action, inline_action.get("title", "Submit"))
            if extracted:
                actions.append(extracted)

        select_action = item.get("selectAction")
        if isinstance(select_action, dict):
            extracted = _extract_card_action(select_action, "Select")
            if extracted:
                actions.append(extracted)

        nested_items = item.get("items", [])
        if nested_items:
            _collect_card_controls(nested_items, inputs, actions)

        columns = item.get("columns", [])
        for column in columns:
            _collect_card_controls(column.get("items", []), inputs, actions)

        if item_type == "ActionSet":
            for action in item.get("actions", []):
                extracted = _extract_card_action(action, action.get("title", "Submit"))
                if extracted:
                    actions.append(extracted)


def _extract_card_content(activity: Any) -> tuple[dict[str, Any] | None, bool]:
    return None, False


async def _handle_web_invoke_action(
    context: WebActivityContext,
    state: dict[str, Any],
    data: dict[str, Any],
) -> None:
    raise ValueError("Card actions are no longer part of the skill-only runtime.")


def _activity_to_event(activity: Any) -> dict[str, Any] | None:
    if activity is None:
        return None
    if isinstance(activity, str):
        return {"type": "status", "content": activity, "kind": "assistant_update"}

    content, replace_last_card = _extract_card_content(activity)
    if content is not None:
        lines = _text_block_lines(content)
        inputs: list[dict[str, Any]] = []
        actions: list[dict[str, Any]] = []
        _collect_card_controls(content.get("body", []), inputs, actions)
        for action in content.get("actions", []):
            extracted = _extract_card_action(action, action.get("title", "Submit"))
            if extracted:
                actions.append(extracted)
        metadata = content.get("smartteem", {}) if isinstance(content.get("smartteem", {}), dict) else {}
        card_kind = metadata.get("cardKind") or _infer_card_kind(actions, lines)
        return {
            "type": "card",
            "title": lines[0] if lines else "Assistant Action",
        "content": "\n\n".join(lines[1:]).strip(),
        "inputs": inputs,
        "actions": actions,
        "layout": _extract_card_layout(content.get("body", []), []),
        "card_kind": card_kind,
        "remove_card": bool(metadata.get("removeCard")),
        "replace_last_card": replace_last_card,
        }

    text = getattr(activity, "text", None)
    if text:
        return {"type": "status", "content": text, "kind": "assistant_update"}
    return None


def _json_line(payload: dict[str, Any]) -> bytes:
    return (json.dumps(payload, ensure_ascii=False) + "\n").encode("utf-8")


async def ensure_web_session(session_id: str, request: Request) -> dict[str, Any]:
    """Create and cache workflow state for the browser session if needed."""
    use_sqlite = request.app.get("use_sqlite_storage", USE_SQLITE_STORAGE)
    pool = None if request.app.get("use_in_memory_storage") or use_sqlite else GLOBAL_DB_POOL
    if pool is None and not request.app.get("use_in_memory_storage") and not use_sqlite:
        raise RuntimeError("Database pool is not available.")

    if session_id not in WORKFLOW_STATE_BY_USER:
        WORKFLOW_STATE_BY_USER[session_id] = await init_workflow_state(
            session_id=session_id,
            activity_context=None,
            pool=pool,
            local=False,
        )
    return WORKFLOW_STATE_BY_USER[session_id]


async def stream_chat_response(request: Request, state_graph) -> StreamResponse:
    """Handle a browser chat turn and stream progress events back to the client."""
    payload = await request.json()
    session_id = payload.get("session_id")
    user_message = payload.get("message")
    card_action = payload.get("card_action")

    if not session_id or not isinstance(session_id, str):
        raise HTTPBadRequest(text="session_id is required")
    if not user_message and not card_action:
        raise HTTPBadRequest(text="message or card_action is required")

    state = await ensure_web_session(session_id, request)
    runtime = WebChatRuntime()
    state["activity_context"] = WebActivityContext(runtime)

    existing_runtime = request.app["web_chat_runtimes"].get(session_id)
    if existing_runtime and existing_runtime.task and not existing_runtime.task.done():
        raise HTTPBadRequest(text="A response is already streaming for this session.")

    async def run_turn() -> None:
        try:
            if card_action:
                kwargs = dict(card_action)
                user_input = ""
                should_run_graph = False
                if kwargs.get("func_call"):
                    function = kwargs.pop("function")
                    module = kwargs.pop("module")
                    kwargs.pop("func_call", None)
                    func = getattr(importlib.import_module(module), function)
                    user_input = await func(state["activity_context"], state, session_id, **kwargs)
                    if user_input is None:
                        user_input = (
                            kwargs.get("resume_input") or kwargs.get("selected_option") or ""
                        )
                    should_run_graph = bool(user_input)
                elif kwargs.get("verb"):
                    await _handle_web_invoke_action(state["activity_context"], state, kwargs)
                    user_input = ""
                    should_run_graph = False
                else:
                    user_input = kwargs.get("selected_option", "")
                    should_run_graph = bool(user_input)
            else:
                user_input = str(user_message)
                should_run_graph = True

            if user_input:
                state["next_agent"] = NodeNames.CODE_AGENT
                state["active_skill"] = None
                state["caller_agent"] = NodeNames.USER_INPUT
                state["task_plan_enabled"] = is_complex_task_request(user_input)
                await append_messages_user(NodeNames.CODE_AGENT, state["pool"], session_id, user_input)

            if not should_run_graph:
                return

            async for state_update in state_graph.astream(
                state,
                config={
                    "configurable": {"thread_id": session_id},
                    "recursion_limit": int(request.app.get("graph_recursion_limit", 100)),
                },
            ):
                for value in state_update.values():
                    if isinstance(value, dict):
                        state.update(value)
                        WORKFLOW_STATE_BY_USER[session_id] = state
                        logging.info(
                            "LangGraph update: session=%s node=%s active_skill=%s caller=%s",
                            session_id,
                            value.get("next_agent"),
                            value.get("active_skill", state.get("active_skill")),
                            value.get("caller_agent", state.get("caller_agent")),
                        )
                    if not isinstance(value, dict) or value.get("next_agent") != NodeNames.USER_INPUT:
                        continue
                    last_input = await retrieve_last_input(state["pool"], session_id, NodeNames.USER_INPUT)
                    if last_input and "Card Skip" not in last_input:
                        await runtime.queue.put({"type": "assistant", "content": last_input})
                    break
                else:
                    continue
                break
        except asyncio.CancelledError:
            await runtime.queue.put({"type": "stopped"})
            raise
        except Exception as exc:
            await runtime.queue.put({"type": "error", "content": str(exc)})
        finally:
            await runtime.queue.put({"type": "done"})

    runtime.task = asyncio.create_task(run_turn())
    request.app["web_chat_runtimes"][session_id] = runtime

    response = StreamResponse(
        status=200,
        headers={
            "Content-Type": "application/x-ndjson; charset=utf-8",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )
    await response.prepare(request)

    try:
        while True:
            event = await runtime.queue.get()
            try:
                await response.write(_json_line(event))
            except (ClientConnectionResetError, ConnectionResetError):
                if runtime.task and not runtime.task.done():
                    runtime.task.cancel()
                break
            if event["type"] == "done":
                break
    finally:
        if request.app["web_chat_runtimes"].get(session_id) is runtime:
            request.app["web_chat_runtimes"].pop(session_id, None)

    return response


async def create_browser_session(_: Request) -> Any:
    """Create a fresh browser chat session id."""
    return json_response({"session_id": str(uuid.uuid4())})


async def stop_browser_session(request: Request) -> Any:
    """Cancel the currently running streamed turn for a browser session."""
    payload = await request.json()
    session_id = payload.get("session_id")
    runtime = request.app["web_chat_runtimes"].get(session_id)
    if runtime and runtime.task and not runtime.task.done():
        runtime.task.cancel()
        return json_response({"stopped": True})
    return json_response({"stopped": False})


PROMPT_CONFIGS = {
    "prompt_o": {
        "title": "Onbording",
        "subtitle": "Edit the runtime onbording.md prompt loaded by app.py.",
        "storage_key": "onboarding_current",
        "payload_field": "onboarding_prompt",
    },
    "prompt_e": {
        "title": "Personal",
        "subtitle": "Edit the personal prompt used by the skill runtime.",
        "storage_key": "environment_specific",
        "payload_field": "environment_specific",
    },
}


async def get_prompt_modal_payload(request: Request) -> Any:
    payload = await request.json()
    session_id = payload.get("session_id")
    prompt_kind = payload.get("prompt_kind")
    if not session_id or not isinstance(session_id, str):
        raise HTTPBadRequest(text="session_id is required")
    if prompt_kind not in PROMPT_CONFIGS:
        raise HTTPBadRequest(text="Unsupported prompt kind")

    state = await ensure_web_session(session_id, request)
    config = PROMPT_CONFIGS[prompt_kind]
    if prompt_kind == "prompt_o":
        current_value = load_root_onboarding_prompt()
        if current_value is None:
            current_value = await get_prompt_value(state, "prompts", config["storage_key"])
    else:
        current_value = await get_prompt_value(state, "prompts", config["storage_key"])
    return json_response(
        {
            "prompt_kind": prompt_kind,
            "title": config["title"],
            "subtitle": config["subtitle"],
            "value": current_value or "",
        }
    )


async def save_prompt_modal_payload(request: Request) -> Any:
    payload = await request.json()
    session_id = payload.get("session_id")
    prompt_kind = payload.get("prompt_kind")
    value = str(payload.get("value") or "")
    if not session_id or not isinstance(session_id, str):
        raise HTTPBadRequest(text="session_id is required")
    if prompt_kind not in PROMPT_CONFIGS:
        raise HTTPBadRequest(text="Unsupported prompt kind")

    state = await ensure_web_session(session_id, request)
    config = PROMPT_CONFIGS[prompt_kind]
    if prompt_kind == "prompt_o":
        save_root_onboarding_prompt(value)
    await save_prompt_value(state, "prompts", config["storage_key"], value)
    return json_response({"saved": True, "prompt_kind": prompt_kind})


async def serve_web_chat(_: Request) -> FileResponse:
    """Serve the browser chat interface shell."""
    return FileResponse(WEBUI_DIR / "index.html")
