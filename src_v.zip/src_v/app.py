"""HTML chat app for the single-agent skill runtime."""

from __future__ import annotations

import asyncio
import html
import logging
import mimetypes
import os
import sys
import uuid
from pathlib import Path
from urllib.parse import quote

from aiohttp.web import Application, Request, Response, json_response, run_app

from app_code.runtime_paths import load_runtime_env

load_runtime_env()

from app_code.graph_build import build_langgraph, get_openai_api_key, get_openai_base_url, get_openai_model
from app_code.skills_runtime.storage import (
    USE_IN_MEMORY_STORAGE,
    USE_SQLITE_STORAGE,
    append_messages_user,
    create_index,
    create_tables,
    init_workflow_state,
    is_complex_task_request,
    retrieve_last_input,
    list_session_downloadable_artifacts,
    session_artifact_path,
)
from app_code.skills_runtime.structs import GLOBAL_DB_POOL, WORKFLOW_STATE_BY_USER, NodeNames
from app_code.skills_runtime.trace_logging import log_dir, log_raw_event, raw_events_path
from app_code.skills_runtime.mcp_loader import (
    close_mcp_connections,
    ensure_mcp_connected,
    _mcp_enabled,
    get_mcp_tools_by_server,
    list_mcp_skill_names,
    get_mcp_skill_prompt,
)
from app_code.skills_runtime.loader import list_skills
from webui import (
    WEBUI_DIR,
    create_browser_session,
    get_prompt_modal_payload,
    save_prompt_modal_payload,
    serve_web_chat,
    stop_browser_session,
    stream_chat_response,
)

STATE_GRAPH = build_langgraph(
    should_pause_graph_when_user_input_required=True,
    openai_api_key=get_openai_api_key(),
    openai_base_url=get_openai_base_url(),
    openai_model=get_openai_model(),
).compile()


def _namespace_session_id(raw_session_id: str) -> str:
    namespace = uuid.UUID(os.getenv("CUSTOMCONNSTR_NAMESPACE_UUID", "12345678123456781234567812345678"))
    try:
        return str(uuid.UUID(raw_session_id))
    except (TypeError, ValueError):
        return str(uuid.uuid5(namespace, raw_session_id or "default-html-session"))


async def _ensure_state(session_id: str):
    pool = None if USE_IN_MEMORY_STORAGE or USE_SQLITE_STORAGE else GLOBAL_DB_POOL
    if session_id not in WORKFLOW_STATE_BY_USER:
        WORKFLOW_STATE_BY_USER[session_id] = await init_workflow_state(
            session_id=session_id,
            activity_context=None,
            pool=pool,
            local=False,
        )
    return WORKFLOW_STATE_BY_USER[session_id]


async def _run_message(session_id: str, message: str) -> str:
    state = await _ensure_state(session_id)
    pool = state["pool"]
    state["next_agent"] = NodeNames.CODE_AGENT
    state["active_skill"] = None
    state["caller_agent"] = NodeNames.USER_INPUT
    state["task_plan_enabled"] = is_complex_task_request(message)
    log_raw_event(
        "user_input",
        session_id,
        message=message,
        task_plan_enabled=state["task_plan_enabled"],
    )
    await append_messages_user(NodeNames.CODE_AGENT, pool, session_id, message)

    answer = ""
    async for state_update in STATE_GRAPH.astream(
        state,
        config={
            "configurable": {"thread_id": session_id},
            "recursion_limit": int(os.getenv("GRAPH_RECURSION_LIMIT", "100")),
        },
    ):
        for update in state_update.values():
            if isinstance(update, dict):
                state.update(update)
                WORKFLOW_STATE_BY_USER[session_id] = state
                logging.info(
                    "LangGraph update: session=%s node=%s active_skill=%s caller=%s",
                    session_id,
                    update.get("next_agent"),
                    update.get("active_skill", state.get("active_skill")),
                    update.get("caller_agent", state.get("caller_agent")),
                )
                log_raw_event(
                    "langgraph_update",
                    session_id,
                    update=update,
                    active_skill=state.get("active_skill"),
                    caller_agent=state.get("caller_agent"),
                )
                if update.get("next_agent") == NodeNames.USER_INPUT:
                    answer = await retrieve_last_input(pool, session_id, NodeNames.USER_INPUT) or ""
                    return answer
    return answer or "The agent stopped without producing a user-facing response."


async def health(_: Request) -> Response:
    storage = "memory" if USE_IN_MEMORY_STORAGE else "sqlite" if USE_SQLITE_STORAGE else "postgres"
    return json_response({"status": "ok", "storage": storage})


async def chat(req: Request) -> Response:
    try:
        body = await req.json()
    except Exception:
        return json_response({"error": "Expected JSON body."}, status=400)

    message = str(body.get("message", "")).strip()
    if not message:
        return json_response({"error": "Missing non-empty 'message'."}, status=400)

    session_id = _namespace_session_id(str(body.get("session_id") or "default-html-session"))
    try:
        response = await _run_message(session_id, message)
        return json_response({"session_id": session_id, "response": response})
    except Exception as exc:
        logging.exception("[HTML chat] Message failed")
        safe_error = html.escape(repr(exc))
        return json_response({"session_id": session_id, "error": safe_error}, status=500)


async def web_chat(req: Request):
    return await stream_chat_response(req, STATE_GRAPH)


async def _cleanup_mcp(_: Application) -> None:
    if _mcp_enabled():
        await close_mcp_connections()


async def get_app(_, local_tests: bool = False) -> Application:
    """Create the HTML aiohttp app."""
    if not USE_IN_MEMORY_STORAGE and not USE_SQLITE_STORAGE:
        try:
            await GLOBAL_DB_POOL.open(timeout=15)
            await create_tables(GLOBAL_DB_POOL)
            await create_index(GLOBAL_DB_POOL)
            await GLOBAL_DB_POOL.wait(timeout=30)
            logging.info("*** GLOBAL_DB_POOL initialized and opened successfully.")
        except Exception:
            if local_tests or os.getenv("ALLOW_DB_INIT_FAILURE", "false").lower() == "true":
                logging.exception("*** DB initialization failed; continuing for local test mode.")
            else:
                raise

    if _mcp_enabled():
        logging.info("MCP_ENABLED=true, connecting to MCP servers ...")
        await ensure_mcp_connected()
        mcp_skills = list_mcp_skill_names()
        if mcp_skills:
            mcp_tools_by_server = get_mcp_tools_by_server()
            logging.info("=== MCP Skill Prompts ===")
            for name in mcp_skills:
                prompt = get_mcp_skill_prompt(name)
                logging.info("--- [MCP Skill: %s] SKILL.md ---\n%s", name, prompt)
            logging.info("=== Loaded MCP servers ===")
            for name in mcp_skills:
                tool_count = len(mcp_tools_by_server.get(name, {}))
                logging.info("  [MCP] %s (%d tools)", name, tool_count)
        else:
            logging.info("=== No MCP servers loaded ===")
        logging.info("MCP initialization complete.")

    logging.info("=== Available Skills ===")
    for skill in list_skills():
        kind = skill.metadata.get("kind", "filesystem")
        logging.info("  [%s] %s: %s", kind, skill.name, skill.description)

    app = Application()
    app["web_chat_runtimes"] = {}
    app["use_in_memory_storage"] = USE_IN_MEMORY_STORAGE
    app["use_sqlite_storage"] = USE_SQLITE_STORAGE
    app["graph_recursion_limit"] = int(os.getenv("GRAPH_RECURSION_LIMIT", "100"))
    app.on_cleanup.append(_cleanup_mcp)

    app.router.add_get("/", serve_web_chat)
    app.router.add_get("/api/health", health)
    app.router.add_post("/api/chat", chat)
    app.router.add_post("/api/web/session", create_browser_session)
    app.router.add_post("/api/web/chat", web_chat)
    app.router.add_post("/api/web/stop", stop_browser_session)
    app.router.add_post("/api/web/prompt-modal", get_prompt_modal_payload)
    app.router.add_post("/api/web/prompt-modal/save", save_prompt_modal_payload)
    app.router.add_get("/api/web/artifacts", web_artifacts)
    app.router.add_get("/api/web/artifact", web_artifact_download)
    app.router.add_static("/webui/", WEBUI_DIR, show_index=False)
    return app


async def web_artifacts(req: Request) -> Response:
    session_id = str(req.query.get("session_id") or "")
    since_ms = float(req.query.get("since_ms") or "0")
    if not session_id:
        return json_response({"artifacts": []})
    return json_response({"artifacts": list_session_downloadable_artifacts(session_id, since_ms)})


async def web_artifact_download(req: Request) -> Response:
    session_id = str(req.query.get("session_id") or "")
    relative_path = str(req.query.get("path") or "")
    try:
        path = session_artifact_path(session_id, relative_path)
    except PermissionError:
        return json_response({"error": "Artifact path is outside this session."}, status=403)
    except FileNotFoundError:
        return json_response({"error": "Artifact not found."}, status=404)
    content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    ascii_name = path.name.encode("ascii", "ignore").decode("ascii") or "artifact"
    encoded_name = quote(path.name)
    return Response(
        body=path.read_bytes(),
        headers={
            "Content-Disposition": (
                f'attachment; filename="{ascii_name}"; filename*=UTF-8\'\'{encoded_name}'
            ),
            "Content-Type": content_type,
            "X-Content-Type-Options": "nosniff",
        },
    )


if __name__ == "__main__":
    daily_log_dir = log_dir()
    log_file = daily_log_dir / "agentic_log.log"
    logging.basicConfig(
        level=os.getenv("LOG_LEVEL", "INFO"),
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
        force=True,
    )
    logging.info("Starting HTML app. log_file=%s raw_events=%s", log_file, raw_events_path())
    asyncio.set_event_loop_policy(asyncio.DefaultEventLoopPolicy())
    run_app(
        get_app(None, local_tests=True),
        host=os.getenv("HOST", "localhost"),
        port=int(os.getenv("PORT", "3978")),
    )
